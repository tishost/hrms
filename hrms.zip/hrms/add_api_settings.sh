#!/bin/bash

# Add API settings to .env file
echo "" >> .env
echo "# API Settings" >> .env
echo "API_RATE_LIMIT=60" >> .env
echo "API_RATE_LIMIT_WINDOW=1" >> .env
echo "API_TOKEN_EXPIRY=365" >> .env
echo "API_RATE_LIMIT_PER_USER=1000" >> .env
echo "FEATURE_API_ACCESS=true" >> .env
echo "SANCTUM_STATEFUL_DOMAINS=barimanager.com" >> .env
echo "SESSION_DOMAIN=.barimanager.com" >> .env
echo "RATE_LIMIT_ENABLED=true" >> .env
echo "RATE_LIMIT_ATTEMPTS=5" >> .env
echo "RATE_LIMIT_DECAY_MINUTES=1" >> .env
echo "API_DOCUMENTATION_ENABLED=true" >> .env
echo "API_DOCUMENTATION_PATH=api/docs" >> .env
echo "API_DOCUMENTATION_TITLE=\"HRMS API Documentation\"" >> .env

echo "API settings added to .env file successfully!" 