<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(__('Refund Policy - Bari Manager')); ?></title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Noto+Sans+Bengali:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        body { 
            font-family: 'Inter', 'Noto Sans Bengali', sans-serif; 
        }
        
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .language-switch {
            transition: all 0.3s ease;
        }
        
        .language-switch:hover {
            transform: scale(1.1);
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <a href="<?php echo e(route('home')); ?>" class="cursor-pointer">
                            <img src="<?php echo e(asset('images/bari-manager-logo.svg')); ?>" alt="Bari Manager Logo" class="h-12 w-auto hover:opacity-80 transition-opacity">
                        </a>
                    </div>
                </div>
                <div class="hidden md:block">
                    <div class="ml-10 flex items-baseline space-x-4">
                        <a href="<?php echo e(route('home')); ?>" class="text-gray-700 hover:text-purple-600 px-3 py-2 rounded-md text-sm font-medium transition-colors"><?php echo e(__('Home')); ?></a>
                        <a href="<?php echo e(route('contact')); ?>" class="text-gray-700 hover:text-purple-600 px-3 py-2 rounded-md text-sm font-medium transition-colors"><?php echo e(__('Contact')); ?></a>
                        <a href="<?php echo e(route('terms')); ?>" class="text-gray-700 hover:text-purple-600 px-3 py-2 rounded-md text-sm font-medium transition-colors"><?php echo e(__('Terms')); ?></a>
                        <a href="<?php echo e(route('privacy')); ?>" class="text-gray-700 hover:text-purple-600 px-3 py-2 rounded-md text-sm font-medium transition-colors"><?php echo e(__('Privacy')); ?></a>
                        
                        <!-- Language Switcher -->
                        <div class="flex items-center space-x-2 ml-4">
                            <button onclick="changeLanguage('en')" class="language-switch px-2 py-1 rounded text-xs font-medium <?php echo e(app()->getLocale() == 'en' ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-700'); ?>">EN</button>
                            <button onclick="changeLanguage('bn')" class="language-switch px-2 py-1 rounded text-xs font-medium <?php echo e(app()->getLocale() == 'bn' ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-700'); ?>">বাং</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Refund Header -->
    <section class="pt-24 pb-12 bg-gradient-to-r from-purple-600 to-blue-600">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-4xl font-bold text-white mb-4">
                <?php echo e(__('Refund Policy')); ?>

            </h1>
            <p class="text-xl text-purple-100">
                <?php echo e(__('Our commitment to customer satisfaction')); ?>

            </p>
        </div>
    </section>

    <!-- Refund Content -->
    <section class="py-16 bg-white">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="prose prose-lg max-w-none">
                <div class="bg-white p-8 rounded-2xl shadow-lg">
                    
                    <h2 class="text-2xl font-bold text-gray-900 mb-6"><?php echo e(__('1. Overview')); ?></h2>
                    <p class="text-gray-600 mb-6">
                        <?php echo e(__('At Bari Manager, we strive to provide the best possible service to our customers. We understand that sometimes our service may not meet your expectations, and we want to ensure you have a clear understanding of our refund policy.')); ?>

                    </p>

                    <h2 class="text-2xl font-bold text-gray-900 mb-6"><?php echo e(__('2. Free Plan')); ?></h2>
                    <p class="text-gray-600 mb-6">
                        <?php echo e(__('Our free plan is available at no cost and does not require any payment. Therefore, no refund is applicable for the free plan.')); ?>

                    </p>

                    <h2 class="text-2xl font-bold text-gray-900 mb-6"><?php echo e(__('3. Paid Subscriptions')); ?></h2>
                    <p class="text-gray-600 mb-6">
                        <?php echo e(__('For paid subscriptions, we offer the following refund terms:')); ?>

                    </p>
                    
                    <div class="bg-green-50 border border-green-200 rounded-lg p-6 mb-6">
                        <h3 class="text-lg font-semibold text-green-800 mb-4"><?php echo e(__('30-Day Money-Back Guarantee')); ?></h3>
                        <p class="text-green-700 mb-4">
                            <?php echo e(__('We offer a 30-day money-back guarantee for all new paid subscriptions. If you are not satisfied with our service within the first 30 days of your subscription, you can request a full refund.')); ?>

                        </p>
                        <ul class="list-disc list-inside text-green-700 space-y-2">
                            <li><?php echo e(__('Full refund of your subscription payment')); ?></li>
                            <li><?php echo e(__('No questions asked within the first 30 days')); ?></li>
                            <li><?php echo e(__('Available for all paid plans (Pro and Enterprise)')); ?></li>
                            <li><?php echo e(__('Refund processed within 5-7 business days')); ?></li>
                        </ul>
                    </div>

                    <h2 class="text-2xl font-bold text-gray-900 mb-6"><?php echo e(__('4. Refund Eligibility')); ?></h2>
                    <p class="text-gray-600 mb-6">
                        <?php echo e(__('To be eligible for a refund, you must meet the following criteria:')); ?>

                    </p>
                    <ul class="list-disc list-inside text-gray-600 mb-6 space-y-2">
                        <li><?php echo e(__('Request made within 30 days of initial subscription')); ?></li>
                        <li><?php echo e(__('Valid payment method and transaction')); ?></li>
                        <li><?php echo e(__('No violation of our Terms of Service')); ?></li>
                        <li><?php echo e(__('Account in good standing')); ?></li>
                    </ul>

                    <h2 class="text-2xl font-bold text-gray-900 mb-6"><?php echo e(__('5. Non-Refundable Items')); ?></h2>
                    <p class="text-gray-600 mb-6">
                        <?php echo e(__('The following items are not eligible for refunds:')); ?>

                    </p>
                    <ul class="list-disc list-inside text-gray-600 mb-6 space-y-2">
                        <li><?php echo e(__('Subscriptions after the 30-day guarantee period')); ?></li>
                        <li><?php echo e(__('Add-on services and custom integrations')); ?></li>
                        <li><?php echo e(__('Training and consultation services')); ?></li>
                        <li><?php echo e(__('Accounts suspended for Terms of Service violations')); ?></li>
                        <li><?php echo e(__('Partial refunds for unused periods')); ?></li>
                    </ul>

                    <h2 class="text-2xl font-bold text-gray-900 mb-6"><?php echo e(__('6. How to Request a Refund')); ?></h2>
                    <p class="text-gray-600 mb-6">
                        <?php echo e(__('To request a refund, please follow these steps:')); ?>

                    </p>
                    <ol class="list-decimal list-inside text-gray-600 mb-6 space-y-2">
                        <li><?php echo e(__('Contact our support team at support@barimanager.com')); ?></li>
                        <li><?php echo e(__('Include your account email and subscription details')); ?></li>
                        <li><?php echo e(__('Provide a brief reason for your refund request')); ?></li>
                        <li><?php echo e(__('Our team will review and process your request within 2 business days')); ?></li>
                    </ol>

                    <h2 class="text-2xl font-bold text-gray-900 mb-6"><?php echo e(__('7. Refund Processing')); ?></h2>
                    <p class="text-gray-600 mb-6">
                        <?php echo e(__('Once your refund is approved:')); ?>

                    </p>
                    <ul class="list-disc list-inside text-gray-600 mb-6 space-y-2">
                        <li><?php echo e(__('Refund will be processed within 5-7 business days')); ?></li>
                        <li><?php echo e(__('You will receive an email confirmation')); ?></li>
                        <li><?php echo e(__('Your account access will be suspended immediately')); ?></li>
                        <li><?php echo e(__('All data will be permanently deleted after 30 days')); ?></li>
                    </ul>

                    <h2 class="text-2xl font-bold text-gray-900 mb-6"><?php echo e(__('8. Cancellation Policy')); ?></h2>
                    <p class="text-gray-600 mb-6">
                        <?php echo e(__('You can cancel your subscription at any time:')); ?>

                    </p>
                    <ul class="list-disc list-inside text-gray-600 mb-6 space-y-2">
                        <li><?php echo e(__('Cancel through your account dashboard')); ?></li>
                        <li><?php echo e(__('Contact our support team')); ?></li>
                        <li><?php echo e(__('No cancellation fees')); ?></li>
                        <li><?php echo e(__('Access continues until the end of your billing period')); ?></li>
                    </ul>

                    <h2 class="text-2xl font-bold text-gray-900 mb-6"><?php echo e(__('9. Dispute Resolution')); ?></h2>
                    <p class="text-gray-600 mb-6">
                        <?php echo e(__('If you disagree with our refund decision, you may:')); ?>

                    </p>
                    <ul class="list-disc list-inside text-gray-600 mb-6 space-y-2">
                        <li><?php echo e(__('Request a review by our management team')); ?></li>
                        <li><?php echo e(__('Provide additional documentation or evidence')); ?></li>
                        <li><?php echo e(__('Escalate to our customer relations department')); ?></li>
                        <li><?php echo e(__('Contact us through multiple channels for resolution')); ?></li>
                    </ul>

                    <h2 class="text-2xl font-bold text-gray-900 mb-6"><?php echo e(__('10. Contact Information')); ?></h2>
                    <p class="text-gray-600 mb-6">
                        <?php echo e(__('For refund requests and questions about this policy, please contact us:')); ?>

                    </p>
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <p class="text-gray-700">
                            <strong><?php echo e(__('Email:')); ?></strong> refunds@barimanager.com<br>
                            <strong><?php echo e(__('Phone:')); ?></strong> +880 1712-345-678<br>
                            <strong><?php echo e(__('Support Hours:')); ?></strong> <?php echo e(__('Monday - Friday, 9:00 AM - 6:00 PM (GMT+6)')); ?><br>
                            <strong><?php echo e(__('Address:')); ?></strong> House #123, Road #4, Block #A, Banani, Dhaka-1213, Bangladesh
                        </p>
                    </div>

                    <div class="mt-8 p-4 bg-blue-50 rounded-lg">
                        <p class="text-blue-800 text-sm">
                            <strong><?php echo e(__('Last Updated:')); ?></strong> <?php echo e(__('July 30, 2024')); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                    <a href="<?php echo e(route('home')); ?>" class="cursor-pointer">
                        <img src="<?php echo e(asset('images/bari-manager-logo.svg')); ?>" alt="Bari Manager Logo" class="h-10 w-auto mb-4 hover:opacity-80 transition-opacity">
                    </a>
                    <p class="text-gray-400 mb-4">
                        <?php echo e(__('The complete house rent management solution for property owners.')); ?>

                    </p>
                    <div class="flex space-x-4">
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-facebook text-xl"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-twitter text-xl"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-linkedin text-xl"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-instagram text-xl"></i>
                        </a>
                    </div>
                </div>
                
                <div>
                    <h4 class="text-lg font-semibold mb-4"><?php echo e(__('Product')); ?></h4>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors"><?php echo e(__('Features')); ?></a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors"><?php echo e(__('Pricing')); ?></a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors"><?php echo e(__('Mobile App')); ?></a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors"><?php echo e(__('API')); ?></a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="text-lg font-semibold mb-4"><?php echo e(__('Support')); ?></h4>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors"><?php echo e(__('Help Center')); ?></a></li>
                        <li><a href="<?php echo e(route('contact')); ?>" class="text-gray-400 hover:text-white transition-colors"><?php echo e(__('Contact Us')); ?></a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors"><?php echo e(__('Documentation')); ?></a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors"><?php echo e(__('Status')); ?></a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="text-lg font-semibold mb-4"><?php echo e(__('Company')); ?></h4>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors"><?php echo e(__('About')); ?></a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors"><?php echo e(__('Blog')); ?></a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors"><?php echo e(__('Careers')); ?></a></li>
                        <li><a href="<?php echo e(route('privacy')); ?>" class="text-gray-400 hover:text-white transition-colors"><?php echo e(__('Privacy')); ?></a></li>
                    </ul>
                </div>
            </div>
            
            <div class="border-t border-gray-800 mt-12 pt-8 text-center">
                <p class="text-gray-400">
                    © 2024 <?php echo e(__('Bari Manager')); ?>. <?php echo e(__('All rights reserved.')); ?> | <?php echo e(__('House Rent Management System')); ?>

                </p>
            </div>
        </div>
    </footer>

    <!-- Language Switcher Script -->
    <script>
        function changeLanguage(lang) {
            window.location.href = '<?php echo e(route("language.switch")); ?>?lang=' + lang;
        }
    </script>
</body>
</html> <?php /**PATH /home/barimanager/hrms/resources/views/refund.blade.php ENDPATH**/ ?>