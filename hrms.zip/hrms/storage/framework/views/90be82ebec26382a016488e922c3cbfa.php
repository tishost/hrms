<?php $__env->startSection('title', 'Current Subscription'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-container">
    <div class="dashboard-content">
        <div class="content-card">
                <div class="card-header">
                    <h4 class="card-title">📊 Current Subscription Plan</h4>
                </div>
                <div class="card-body">
                    <?php if($subscription && $plan): ?>
                        <div class="dashboard-grid">
                            <!-- Current Plan Details -->
                            <div class="dashboard-grid-item">
                                                                <div class="plan-card primary">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo e($plan->name); ?> Plan</h5>
                                        <p class="card-text"><?php echo e($plan->description); ?></p>
                                        <div class="plan-details">
                                            <div class="plan-detail-item">
                                                <strong>Status:</strong>
                                                <span class="badge bg-<?php echo e($subscription->status === 'active' ? 'success' : ($subscription->status === 'pending' ? 'warning' : 'danger')); ?>">
                                                    <?php echo e(ucfirst($subscription->status)); ?>

                                                </span>
                                            </div>
                                            <div class="plan-detail-item">
                                                <strong>Price:</strong> ৳<?php echo e(number_format($plan->price, 2)); ?>/year
                                            </div>
                                        </div>
                                        <?php if($subscription->start_date && $subscription->end_date): ?>
                                            <div class="plan-details">
                                                <div class="plan-detail-item">
                                                    <strong>Start Date:</strong> <?php echo e($subscription->start_date->format('M d, Y')); ?>

                                                </div>
                                                <div class="plan-detail-item">
                                                    <strong>End Date:</strong> <?php echo e($subscription->end_date->format('M d, Y')); ?>

                                                </div>
                                            </div>
                                            <?php if($subscription->daysUntilExpiry() !== null): ?>
                                                <div class="plan-details">
                                                    <div class="plan-detail-item">
                                                        <strong>Days Remaining:</strong>
                                                        <span class="badge bg-<?php echo e($subscription->daysUntilExpiry() > 30 ? 'success' : ($subscription->daysUntilExpiry() > 7 ? 'warning' : 'danger')); ?>">
                                                            <?php echo e($subscription->daysUntilExpiry()); ?> days
                                                        </span>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Plan Features -->
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <h6 class="mb-0">📋 Plan Features</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <ul class="list-unstyled">
                                                    <li><i class="fas fa-check text-success"></i> Properties: <?php echo e($plan->properties_limit == -1 ? 'Unlimited' : $plan->properties_limit); ?></li>
                                                    <li><i class="fas fa-check text-success"></i> Units: <?php echo e($plan->units_limit == -1 ? 'Unlimited' : $plan->units_limit); ?></li>
                                                    <li><i class="fas fa-check text-success"></i> Tenants: <?php echo e($plan->tenants_limit == -1 ? 'Unlimited' : $plan->tenants_limit); ?></li>
                                                </ul>
                                            </div>
                                            <div class="col-md-6">
                                                <ul class="list-unstyled">
                                                    <li><i class="fas fa-<?php echo e($plan->sms_notification ? 'check text-success' : 'times text-danger'); ?>"></i> SMS Notifications</li>
                                                    <li><i class="fas fa-check text-success"></i> Email Support</li>
                                                    <li><i class="fas fa-check text-success"></i> 24/7 Access</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Usage Statistics -->
                            <div class="dashboard-grid-item">
                                <div class="content-card">
                                    <div class="card-header">
                                        <h6 class="mb-0">📈 Usage Statistics</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <strong>Properties:</strong> <?php echo e($propertiesCount); ?>

                                            <?php if($plan->properties_limit != -1): ?>
                                                / <?php echo e($plan->properties_limit); ?>

                                                <div class="progress mt-1">
                                                    <div class="progress-bar" style="width: <?php echo e(min(100, ($propertiesCount / $plan->properties_limit) * 100)); ?>%"></div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="mb-3">
                                            <strong>Units:</strong> <?php echo e($unitsCount); ?>

                                            <?php if($plan->units_limit != -1): ?>
                                                / <?php echo e($plan->units_limit); ?>

                                                <div class="progress mt-1">
                                                    <div class="progress-bar" style="width: <?php echo e(min(100, ($unitsCount / $plan->units_limit) * 100)); ?>%"></div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="mb-3">
                                            <strong>Tenants:</strong> <?php echo e($tenantsCount); ?>

                                            <?php if($plan->tenants_limit != -1): ?>
                                                / <?php echo e($plan->tenants_limit); ?>

                                                <div class="progress mt-1">
                                                    <div class="progress-bar" style="width: <?php echo e(min(100, ($tenantsCount / $plan->tenants_limit) * 100)); ?>%"></div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Action Buttons -->
                                <div class="card mt-4">
                                    <div class="card-body">
                                        <h6 class="mb-3">Actions</h6>
                                        <a href="<?php echo e(route('owner.subscription.plans')); ?>" class="btn btn-primary btn-block mb-2">
                                            <i class="fas fa-shopping-cart"></i> Upgrade Plan
                                        </a>
                                        <a href="<?php echo e(route('owner.subscription.billing')); ?>" class="btn btn-info btn-block mb-2">
                                            <i class="fas fa-file-invoice"></i> Billing History
                                        </a>
                                        <?php if($subscription->status === 'pending'): ?>
                                            <a href="<?php echo e(route('owner.subscription.payment')); ?>" class="btn btn-warning btn-block">
                                                <i class="fas fa-credit-card"></i> Complete Payment
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-exclamation-triangle fa-3x text-warning mb-3"></i>
                            <h4>No Active Subscription</h4>
                            <p class="text-muted">You don't have an active subscription plan.</p>
                            <a href="<?php echo e(route('owner.subscription.plans')); ?>" class="btn btn-primary">
                                <i class="fas fa-shopping-cart"></i> Choose a Plan
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.owner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/barimanager/hrms/resources/views/owner/subscription/current.blade.php ENDPATH**/ ?>