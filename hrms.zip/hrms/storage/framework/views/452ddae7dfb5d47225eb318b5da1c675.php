<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(__('Bari Manager - House Rent Management System')); ?></title>
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <!-- Dynamic Favicon -->
    <?php if(\App\Helpers\SystemHelper::getCompanyFavicon()): ?>
        <link rel="icon" type="image/x-icon" href="<?php echo e(\App\Helpers\SystemHelper::getCompanyFavicon()); ?>">
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(\App\Helpers\SystemHelper::getCompanyFavicon()); ?>">
    <?php endif; ?>
    
    <?php echo \App\Services\SeoService::renderMetaTags('landing'); ?>


    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Noto+Sans+Bengali:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Inter', 'Noto Sans Bengali', sans-serif;
        }

        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .gradient-text {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .hero-gradient {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
        }

        .feature-card {
            transition: all 0.3s ease;
        }

        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }

        .package-card {
            transition: all 0.3s ease;
        }

        .package-card:hover {
            transform: scale(1.05);
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }

        .floating {
            animation: floating 3s ease-in-out infinite;
        }

        @keyframes floating {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
        }

        .pulse-glow {
            animation: pulse-glow 2s ease-in-out infinite alternate;
        }

        @keyframes pulse-glow {
            from { box-shadow: 0 0 20px rgba(102, 126, 234, 0.5); }
            to { box-shadow: 0 0 30px rgba(102, 126, 234, 0.8); }
        }

        .language-switch {
            transition: all 0.3s ease;
        }

        .language-switch:hover {
            transform: scale(1.1);
        }

        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            transition: all 0.3s ease;
        }

        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(102, 126, 234, 0.3);
        }

        .nav-link.active {
            color: #9333ea !important;
            background-color: rgba(147, 51, 234, 0.1);
            border-bottom: 2px solid #9333ea;
        }

        .nav-link.active:hover {
            color: #7c3aed !important;
        }

        /* Mobile menu transitions */
        #mobile-menu {
            transition: all 0.3s ease-in-out;
        }

        #mobile-menu.hidden {
            opacity: 0;
            transform: translateY(-10px);
        }

        #mobile-menu:not(.hidden) {
            opacity: 1;
            transform: translateY(0);
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <a href="#home" class="cursor-pointer">
                            <img src="<?php echo e(asset('images/bari-manager-logo.svg')); ?>" alt="Bari Manager Logo" class="h-8 sm:h-12 w-auto hover:opacity-80 transition-opacity">
                        </a>
                    </div>
                </div>
                <div class="hidden md:block">
                    <div class="ml-10 flex items-baseline space-x-4">
                        <a href="#home" class="nav-link text-gray-700 hover:text-purple-600 px-3 py-2 rounded-md text-sm font-medium transition-colors" data-section="home"><?php echo e(__('Home')); ?></a>
                        <a href="#features" class="nav-link text-gray-700 hover:text-purple-600 px-3 py-2 rounded-md text-sm font-medium transition-colors" data-section="features"><?php echo e(__('Features')); ?></a>
                        <a href="#packages" class="nav-link text-gray-700 hover:text-purple-600 px-3 py-2 rounded-md text-sm font-medium transition-colors" data-section="packages"><?php echo e(__('Packages')); ?></a>
                        <a href="#support" class="nav-link text-gray-700 hover:text-purple-600 px-3 py-2 rounded-md text-sm font-medium transition-colors" data-section="support"><?php echo e(__('Support')); ?></a>
                        <a href="<?php echo e(route('login')); ?>" class="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"><?php echo e(__('Login')); ?></a>

                        <!-- Language Switcher -->
                        <div class="flex items-center space-x-2 ml-4">
                            <button onclick="changeLanguage('en')" class="language-switch px-2 py-1 rounded text-xs font-medium <?php echo e(app()->getLocale() == 'en' ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-700'); ?>">EN</button>
                            <button onclick="changeLanguage('bn')" class="language-switch px-2 py-1 rounded text-xs font-medium <?php echo e(app()->getLocale() == 'bn' ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-700'); ?>">বাং</button>
                        </div>
                    </div>
                </div>

                <!-- Mobile menu button -->
                <div class="md:hidden">
                    <button id="mobile-menu-button" class="text-gray-700 hover:text-purple-600 focus:outline-none focus:text-purple-600 p-3 touch-manipulation">
                        <i class="fas fa-bars text-lg lg:text-xl"></i>
                    </button>
                </div>
            </div>

                        <!-- Mobile menu -->
            <div id="mobile-menu" class="hidden md:hidden">
                <div class="px-4 pt-4 pb-6 space-y-2 bg-white border-t border-gray-200">
                    <a href="#home" class="nav-link block text-gray-700 hover:text-purple-600 px-4 py-3 rounded-md text-base font-medium transition-colors" data-section="home"><?php echo e(__('Home')); ?></a>
                    <a href="#features" class="nav-link block text-gray-700 hover:text-purple-600 px-4 py-3 rounded-md text-base font-medium transition-colors" data-section="features"><?php echo e(__('Features')); ?></a>
                    <a href="#packages" class="nav-link block text-gray-700 hover:text-purple-600 px-4 py-3 rounded-md text-base font-medium transition-colors" data-section="packages"><?php echo e(__('Packages')); ?></a>
                    <a href="#support" class="nav-link block text-gray-700 hover:text-purple-600 px-4 py-3 rounded-md text-base font-medium transition-colors" data-section="support"><?php echo e(__('Support')); ?></a>
                    <a href="<?php echo e(route('login')); ?>" class="block bg-purple-600 hover:bg-purple-700 text-white px-4 py-3 rounded-md text-base font-medium transition-colors text-center"><?php echo e(__('Login')); ?></a>

                    <!-- Mobile Language Switcher -->
                    <div class="flex items-center justify-center space-x-3 pt-4">
                        <button onclick="changeLanguage('en')" class="language-switch px-4 py-2 rounded text-sm font-medium <?php echo e(app()->getLocale() == 'en' ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-700'); ?>">EN</button>
                        <button onclick="changeLanguage('bn')" class="language-switch px-4 py-2 rounded text-sm font-medium <?php echo e(app()->getLocale() == 'bn' ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-700'); ?>">বাং</button>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Breadcrumb -->
    <?php echo \App\Services\SeoService::renderBreadcrumbs(); ?>


    <!-- Hero Section -->
    <section id="home" class="hero-gradient min-h-screen flex items-center justify-center relative overflow-hidden"
             <?php if(\App\Models\SystemSetting::getValue('hero_image')): ?>
             style="background-image: url('<?php echo e(asset('storage/' . \App\Models\SystemSetting::getValue('hero_image'))); ?>'); background-size: cover; background-position: center;"
             <?php endif; ?>>
        <div class="absolute inset-0 bg-black opacity-10"></div>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
                <div class="text-white text-center lg:text-left">
                    <h1 class="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-bold mb-4 lg:mb-6">
                        <?php echo e(\App\Models\SystemSetting::getValue('hero_title', 'Bari Manager')); ?>

                    </h1>
                    <p class="text-lg sm:text-xl lg:text-2xl mb-4 lg:mb-6 text-gray-100">
                        <?php echo e(\App\Models\SystemSetting::getValue('hero_subtitle', 'Property Management System')); ?>

                    </p>
                    <p class="text-base sm:text-lg lg:text-xl mb-6 lg:mb-8 text-gray-100">
                        <?php echo e(\App\Models\SystemSetting::getValue('hero_description', 'Streamline your property management with our comprehensive Bari Manager solution. Manage tenants, track rent, and grow your business effortlessly.')); ?>

                    </p>
                    <div class="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                        <a href="<?php echo e(\App\Models\SystemSetting::getValue('hero_button_url', '#register')); ?>" class="btn-primary text-white px-6 sm:px-8 py-3 sm:py-4 rounded-lg text-base sm:text-lg font-semibold inline-block text-center">
                            <i class="fas fa-rocket mr-2"></i>
                            <?php echo e(\App\Models\SystemSetting::getValue('hero_button_text', 'Get Started Free')); ?>

                        </a>
                        <a href="#features" class="bg-white bg-opacity-20 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-lg text-base sm:text-lg font-semibold inline-block text-center hover:bg-opacity-30 transition-all">
                            <i class="fas fa-play mr-2"></i>
                            <?php echo e(__('Watch Demo')); ?>

                        </a>
                    </div>
                </div>
                <div class="floating hidden lg:block">
                    <img src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
                         alt="Modern House" class="rounded-2xl shadow-2xl">
                </div>
            </div>
        </div>
    </section>

    <!-- Mobile Apps Section -->
    <section class="py-12 lg:py-20 bg-gradient-to-br from-purple-50 to-blue-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
                <div class="text-center lg:text-left">
                    <h2 class="text-3xl lg:text-4xl font-bold text-gray-900 mb-4 lg:mb-6">
                        <?php echo e(__('Get Our Mobile App')); ?>

                    </h2>
                    <p class="text-base lg:text-lg text-gray-600 mb-6 lg:mb-8">
                        <?php echo e(__('Download Bari Manager mobile app and manage your properties on the go. Available for both Android and iOS devices with full feature access.')); ?>

                    </p>

                    <div class="space-y-4 lg:space-y-6">
                        <div class="flex items-center justify-center lg:justify-start">
                            <div class="bg-green-100 p-3 rounded-full mr-4">
                                <i class="fas fa-mobile-alt text-green-600 text-lg lg:text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-semibold text-gray-900 text-sm lg:text-base"><?php echo e(__('Mobile Management')); ?></h4>
                                <p class="text-xs lg:text-sm text-gray-600"><?php echo e(__('Manage properties from anywhere')); ?></p>
                            </div>
                        </div>

                        <div class="flex items-center justify-center lg:justify-start">
                            <div class="bg-blue-100 p-3 rounded-full mr-4">
                                <i class="fas fa-bell text-blue-600 text-lg lg:text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-semibold text-gray-900 text-sm lg:text-base"><?php echo e(__('Real-time Notifications')); ?></h4>
                                <p class="text-xs lg:text-sm text-gray-600"><?php echo e(__('Get instant updates and alerts')); ?></p>
                            </div>
                        </div>

                        <div class="flex items-center justify-center lg:justify-start">
                            <div class="bg-purple-100 p-3 rounded-full mr-4">
                                <i class="fas fa-chart-line text-purple-600 text-lg lg:text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-semibold text-gray-900 text-sm lg:text-base"><?php echo e(__('Offline Access')); ?></h4>
                                <p class="text-xs lg:text-sm text-gray-600"><?php echo e(__('Work without internet connection')); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="mt-6 lg:mt-8 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                        <a href="#" class="flex items-center justify-center bg-black text-white px-4 lg:px-6 py-3 rounded-lg font-semibold hover:bg-gray-800 transition-colors">
                            <i class="fab fa-apple text-xl lg:text-2xl mr-3"></i>
                            <div class="text-left">
                                <div class="text-xs"><?php echo e(__('Download on the')); ?></div>
                                <div class="text-sm font-bold"><?php echo e(__('App Store')); ?></div>
                            </div>
                        </a>

                        <a href="#" class="flex items-center justify-center bg-green-600 text-white px-4 lg:px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                            <i class="fab fa-google-play text-xl lg:text-2xl mr-3"></i>
                            <div class="text-left">
                                <div class="text-xs"><?php echo e(__('Get it on')); ?></div>
                                <div class="text-sm font-bold"><?php echo e(__('Google Play')); ?></div>
                            </div>
                        </a>
                    </div>

                    <div class="mt-4 lg:mt-6 text-center lg:text-left">
                        <p class="text-xs lg:text-sm text-gray-500">
                            <?php echo e(__('Free download • No hidden charges • Full feature access')); ?>

                        </p>
                    </div>
                </div>

                <div class="relative hidden lg:block">
                    <div class="relative z-10">
                        <img src="https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
                             alt="Mobile App Screenshot" class="rounded-2xl shadow-2xl">
                    </div>

                    <!-- Floating Elements -->
                    <div class="absolute -top-4 -right-4 bg-white p-4 rounded-xl shadow-lg">
                        <div class="flex items-center">
                            <div class="bg-green-100 p-2 rounded-full mr-3">
                                <i class="fas fa-star text-green-600"></i>
                            </div>
                            <div>
                                <div class="text-sm font-semibold text-gray-900">4.8/5</div>
                                <div class="text-xs text-gray-600"><?php echo e(__('App Store Rating')); ?></div>
                            </div>
                        </div>
                    </div>

                    <div class="absolute -bottom-4 -left-4 bg-white p-4 rounded-xl shadow-lg">
                        <div class="flex items-center">
                            <div class="bg-blue-100 p-2 rounded-full mr-3">
                                <i class="fas fa-download text-blue-600"></i>
                            </div>
                            <div>
                                <div class="text-sm font-semibold text-gray-900">10K+</div>
                                <div class="text-xs text-gray-600"><?php echo e(__('Downloads')); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Statistics Section -->
    <section class="py-12 lg:py-16 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 lg:gap-8">
                <div class="stats-card text-white p-4 lg:p-6 rounded-2xl text-center">
                    <div class="text-2xl lg:text-3xl font-bold mb-2"><?php echo e(number_format($totalOwners)); ?>+</div>
                    <div class="text-xs lg:text-sm opacity-90"><?php echo e(__('Happy Customers')); ?></div>
                </div>
                <div class="stats-card text-white p-4 lg:p-6 rounded-2xl text-center">
                    <div class="text-2xl lg:text-3xl font-bold mb-2"><?php echo e(number_format($totalProperties)); ?>+</div>
                    <div class="text-xs lg:text-sm opacity-90"><?php echo e(__('Properties Managed')); ?></div>
                </div>
                <div class="stats-card text-white p-4 lg:p-6 rounded-2xl text-center">
                    <div class="text-2xl lg:text-3xl font-bold mb-2"><?php echo e(number_format($totalTenants)); ?>+</div>
                    <div class="text-xs lg:text-sm opacity-90"><?php echo e(__('Tenants Served')); ?></div>
                </div>
                <div class="stats-card text-white p-4 lg:p-6 rounded-2xl text-center">
                    <div class="text-2xl lg:text-3xl font-bold mb-2">24/7</div>
                    <div class="text-xs lg:text-sm opacity-90"><?php echo e(__('Support Available')); ?></div>
                </div>
            </div>
        </div>
    </section>

    <!-- HRMS Details Section -->
    <section class="py-12 lg:py-20 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
                <div class="text-center lg:text-left">
                    <h2 class="text-3xl lg:text-4xl font-bold text-gray-900 mb-4 lg:mb-6">
                        <?php echo e(__('What is')); ?> <span class="gradient-text"><?php echo e(__('Bari Manager')); ?></span>?
                    </h2>
                    <p class="text-base lg:text-lg text-gray-600 mb-4 lg:mb-6">
                        <?php echo e(__('Bari Manager is a comprehensive digital solution designed to revolutionize property management. Our platform combines powerful web applications with intuitive mobile apps to provide property owners with complete control over their rental business.')); ?>

                    </p>
                    <div class="space-y-3 lg:space-y-4">
                        <div class="flex items-center justify-center lg:justify-start">
                            <i class="fas fa-check-circle text-green-500 text-lg lg:text-xl mr-3"></i>
                            <span class="text-gray-700 text-sm lg:text-base"><?php echo e(__('Complete tenant management system')); ?></span>
                        </div>
                        <div class="flex items-center justify-center lg:justify-start">
                            <i class="fas fa-check-circle text-green-500 text-lg lg:text-xl mr-3"></i>
                            <span class="text-gray-700 text-sm lg:text-base"><?php echo e(__('Automated rent collection and tracking')); ?></span>
                        </div>
                        <div class="flex items-center justify-center lg:justify-start">
                            <i class="fas fa-check-circle text-green-500 text-lg lg:text-xl mr-3"></i>
                            <span class="text-gray-700 text-sm lg:text-base"><?php echo e(__('Maintenance request management')); ?></span>
                        </div>
                        <div class="flex items-center justify-center lg:justify-start">
                            <i class="fas fa-check-circle text-green-500 text-lg lg:text-xl mr-3"></i>
                            <span class="text-gray-700 text-sm lg:text-base"><?php echo e(__('Financial reporting and analytics')); ?></span>
                        </div>
                    </div>
                    <div class="mt-6 lg:mt-8 text-center lg:text-left">
                        <a href="#register" class="btn-primary text-white px-6 py-3 rounded-lg font-semibold inline-block">
                            <i class="fas fa-user-plus mr-2"></i>
                            <?php echo e(__('Free Registration')); ?>

                        </a>
                    </div>
                </div>
                <div class="relative hidden lg:block">
                    <img src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
                         alt="Property Management" class="rounded-2xl shadow-xl">
                    <div class="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-lg">
                        <div class="flex items-center">
                            <div class="bg-purple-100 p-3 rounded-full mr-4">
                                <i class="fas fa-chart-line text-purple-600 text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-semibold text-gray-900"><?php echo e(__('Growth Analytics')); ?></h4>
                                <p class="text-sm text-gray-600"><?php echo e(__('Track your rental income')); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="py-12 lg:py-20 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12 lg:mb-16">
                <h2 class="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                    <?php echo e(\App\Models\SystemSetting::getValue('features_title', 'Powerful Features')); ?>

                </h2>
                <p class="text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
                    <?php echo e(\App\Models\SystemSetting::getValue('features_subtitle', 'Everything you need to manage your rental properties efficiently and grow your business with Bari Manager')); ?>

                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
                <!-- Feature 1 -->
                <div class="feature-card bg-white p-6 lg:p-8 rounded-2xl shadow-lg border border-gray-100">
                    <div class="bg-purple-100 p-3 lg:p-4 rounded-full w-12 h-12 lg:w-16 lg:h-16 flex items-center justify-center mb-4 lg:mb-6">
                        <i class="<?php echo e(\App\Models\SystemSetting::getValue('feature1_icon', 'fas fa-home')); ?> text-purple-600 text-lg lg:text-2xl"></i>
                    </div>
                    <h3 class="text-lg lg:text-xl font-semibold text-gray-900 mb-3 lg:mb-4"><?php echo e(\App\Models\SystemSetting::getValue('feature1_title', 'Property Management')); ?></h3>
                    <p class="text-gray-600 text-sm lg:text-base"><?php echo e(\App\Models\SystemSetting::getValue('feature1_description', 'Easily manage multiple properties, units, and their details in one centralized platform.')); ?></p>
                </div>

                <!-- Feature 2 -->
                <div class="feature-card bg-white p-6 lg:p-8 rounded-2xl shadow-lg border border-gray-100">
                    <div class="bg-blue-100 p-3 lg:p-4 rounded-full w-12 h-12 lg:w-16 lg:h-16 flex items-center justify-center mb-4 lg:mb-6">
                        <i class="<?php echo e(\App\Models\SystemSetting::getValue('feature2_icon', 'fas fa-users')); ?> text-blue-600 text-lg lg:text-2xl"></i>
                    </div>
                    <h3 class="text-lg lg:text-xl font-semibold text-gray-900 mb-3 lg:mb-4"><?php echo e(\App\Models\SystemSetting::getValue('feature2_title', 'Tenant Management')); ?></h3>
                    <p class="text-gray-600 text-sm lg:text-base"><?php echo e(\App\Models\SystemSetting::getValue('feature2_description', 'Complete tenant profiles, rent history, and communication tools all in one place.')); ?></p>
                </div>

                <!-- Feature 3 -->
                <div class="feature-card bg-white p-6 lg:p-8 rounded-2xl shadow-lg border border-gray-100">
                    <div class="bg-green-100 p-3 lg:p-4 rounded-full w-12 h-12 lg:w-16 lg:h-16 flex items-center justify-center mb-4 lg:mb-6">
                        <i class="<?php echo e(\App\Models\SystemSetting::getValue('feature3_icon', 'fas fa-chart-line')); ?> text-green-600 text-lg lg:text-2xl"></i>
                    </div>
                    <h3 class="text-lg lg:text-xl font-semibold text-gray-900 mb-3 lg:mb-4"><?php echo e(\App\Models\SystemSetting::getValue('feature3_title', 'Financial Tracking')); ?></h3>
                    <p class="text-gray-600 text-sm lg:text-base"><?php echo e(\App\Models\SystemSetting::getValue('feature3_description', 'Track income, expenses, and generate detailed financial reports.')); ?></p>
                </div>

                <!-- Feature 4 -->
                <div class="feature-card bg-white p-6 lg:p-8 rounded-2xl shadow-lg border border-gray-100">
                    <div class="bg-yellow-100 p-3 lg:p-4 rounded-full w-12 h-12 lg:w-16 lg:h-16 flex items-center justify-center mb-4 lg:mb-6">
                        <i class="fas fa-tools text-yellow-600 text-lg lg:text-2xl"></i>
                    </div>
                    <h3 class="text-lg lg:text-xl font-semibold text-gray-900 mb-3 lg:mb-4"><?php echo e(__('Maintenance')); ?></h3>
                    <p class="text-gray-600 text-sm lg:text-base"><?php echo e(__('Track maintenance requests, assign tasks, and monitor completion status.')); ?></p>
                </div>

                <!-- Feature 5 -->
                <div class="feature-card bg-white p-6 lg:p-8 rounded-2xl shadow-lg border border-gray-100">
                    <div class="bg-red-100 p-3 lg:p-4 rounded-full w-12 h-12 lg:w-16 lg:h-16 flex items-center justify-center mb-4 lg:mb-6">
                        <i class="fas fa-chart-bar text-red-600 text-lg lg:text-2xl"></i>
                    </div>
                    <h3 class="text-lg lg:text-xl font-semibold text-gray-900 mb-3 lg:mb-4"><?php echo e(__('Analytics')); ?></h3>
                    <p class="text-gray-600 text-sm lg:text-base"><?php echo e(__('Comprehensive reports and analytics to track your rental business performance.')); ?></p>
                </div>

                <!-- Feature 6 -->
                <div class="feature-card bg-white p-6 lg:p-8 rounded-2xl shadow-lg border border-gray-100">
                    <div class="bg-indigo-100 p-3 lg:p-4 rounded-full w-12 h-12 lg:w-16 lg:h-16 flex items-center justify-center mb-4 lg:mb-6">
                        <i class="fas fa-mobile-alt text-indigo-600 text-lg lg:text-2xl"></i>
                    </div>
                    <h3 class="text-lg lg:text-xl font-semibold text-gray-900 mb-3 lg:mb-4"><?php echo e(__('Mobile App')); ?></h3>
                    <p class="text-gray-600 text-sm lg:text-base"><?php echo e(__('Access your property management system anywhere with our mobile application.')); ?></p>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works Section -->
    <section class="py-12 lg:py-20 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12 lg:mb-16">
                <h2 class="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                    <?php echo e(__('How It Works')); ?>

                </h2>
                <p class="text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
                    <?php echo e(__('Get started with Bari Manager in just 3 simple steps')); ?>

                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
                <div class="text-center">
                    <div class="bg-purple-100 p-4 lg:p-6 rounded-full w-16 h-16 lg:w-20 lg:h-20 flex items-center justify-center mx-auto mb-4 lg:mb-6">
                        <span class="text-2xl lg:text-3xl font-bold text-purple-600">1</span>
                    </div>
                    <h3 class="text-lg lg:text-xl font-semibold text-gray-900 mb-3 lg:mb-4"><?php echo e(__('Sign Up')); ?></h3>
                    <p class="text-gray-600 text-sm lg:text-base"><?php echo e(__('Create your free account and set up your profile in minutes.')); ?></p>
                </div>

                <div class="text-center">
                    <div class="bg-blue-100 p-4 lg:p-6 rounded-full w-16 h-16 lg:w-20 lg:h-20 flex items-center justify-center mx-auto mb-4 lg:mb-6">
                        <span class="text-2xl lg:text-3xl font-bold text-blue-600">2</span>
                    </div>
                    <h3 class="text-lg lg:text-xl font-semibold text-gray-900 mb-3 lg:mb-4"><?php echo e(__('Add Properties')); ?></h3>
                    <p class="text-gray-600 text-sm lg:text-base"><?php echo e(__('Add your properties and units to start managing them.')); ?></p>
                </div>

                <div class="text-center">
                    <div class="bg-green-100 p-4 lg:p-6 rounded-full w-16 h-16 lg:w-20 lg:h-20 flex items-center justify-center mx-auto mb-4 lg:mb-6">
                        <span class="text-2xl lg:text-3xl font-bold text-green-600">3</span>
                    </div>
                    <h3 class="text-lg lg:text-xl font-semibold text-gray-900 mb-3 lg:mb-4"><?php echo e(__('Start Managing')); ?></h3>
                    <p class="text-gray-600 text-sm lg:text-base"><?php echo e(__('Begin managing tenants, collecting rent, and growing your business.')); ?></p>
                </div>
            </div>
        </div>
    </section>

    <!-- Packages Section -->
    <section id="packages" class="py-12 lg:py-20 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12 lg:mb-16">
                <h2 class="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                    <?php echo e(__('Choose Your Plan')); ?>

                </h2>
                <p class="text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
                    <?php echo e(__('Start with our free plan and upgrade as your business grows with Bari Manager')); ?>

                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-<?php echo e(count($plans) > 3 ? '4' : count($plans)); ?> gap-6 lg:gap-8">
                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="package-card bg-white p-6 lg:p-8 rounded-2xl shadow-lg border-2 <?php echo e($plan->is_popular ? 'border-purple-500 relative' : 'border-gray-200'); ?>">
                    <?php if($plan->is_popular): ?>
                    <div class="absolute -top-4 left-1/2 transform -translate-x-1/2">
                        <span class="bg-purple-600 text-white px-3 lg:px-4 py-1 lg:py-2 rounded-full text-xs lg:text-sm font-semibold"><?php echo e(__('Most Popular')); ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="text-center mb-6 lg:mb-8">
                        <h3 class="text-xl lg:text-2xl font-bold text-gray-900 mb-2"><?php echo e($plan->name); ?></h3>
                        <div class="text-3xl lg:text-4xl font-bold text-purple-600 mb-2">
                            <?php if($plan->price == 0): ?>
                                ৳0
                            <?php else: ?>
                                ৳<?php echo e(number_format($plan->price)); ?>

                            <?php endif; ?>
                        </div>
                        <p class="text-gray-600 text-sm lg:text-base">
                            <?php if($plan->price == 0): ?>
                                <?php echo e(__('Perfect for getting started')); ?>

                            <?php else: ?>
                                <?php echo e(__('Per month')); ?>

                            <?php endif; ?>
                        </p>
                    </div>
                    <ul class="space-y-3 lg:space-y-4 mb-6 lg:mb-8">
                        <?php if($plan->properties_limit > 0): ?>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 mr-3 text-sm lg:text-base"></i>
                            <span class="text-sm lg:text-base"><?php echo e(__('Up to :limit properties/buildings', ['limit' => $plan->properties_limit])); ?></span>
                        </li>
                        <?php else: ?>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 mr-3 text-sm lg:text-base"></i>
                            <span class="text-sm lg:text-base"><?php echo e(__('Unlimited properties/buildings')); ?></span>
                        </li>
                        <?php endif; ?>

                        <?php if($plan->tenants_limit > 0): ?>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 mr-3 text-sm lg:text-base"></i>
                            <span class="text-sm lg:text-base"><?php echo e(__('Up to :limit tenants', ['limit' => $plan->tenants_limit])); ?></span>
                        </li>
                        <?php else: ?>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 mr-3 text-sm lg:text-base"></i>
                            <span class="text-sm lg:text-base"><?php echo e(__('Unlimited tenants')); ?></span>
                        </li>
                        <?php endif; ?>

                        <?php if($plan->units_limit > 0): ?>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 mr-3 text-sm lg:text-base"></i>
                            <span class="text-sm lg:text-base"><?php echo e(__('Up to :limit units/flats', ['limit' => $plan->units_limit])); ?></span>
                        </li>
                        <?php else: ?>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 mr-3 text-sm lg:text-base"></i>
                            <span class="text-sm lg:text-base"><?php echo e(__('Unlimited units/flats')); ?></span>
                        </li>
                        <?php endif; ?>

                        <?php if($plan->features): ?>
                        <?php $__currentLoopData = $plan->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="flex items-center">
                                                                                    <?php if(isset($plan->features_css[$index])): ?>
                                <?php
                                    $cssString = $plan->features_css[$index];
                                    $iconClass = 'mr-3 text-sm lg:text-base ';
                                    $textClass = 'text-sm lg:text-base ';

                                    // Simple logic: if contains 'fa-times', it's unavailable
                                    if(str_contains($cssString, 'fa-times')) {
                                        $iconClass .= 'fas fa-times text-red-500';
                                        $textClass .= 'text-gray-500';
                                    } else {
                                        $iconClass .= 'fas fa-check text-green-500';
                                        $textClass .= 'text-gray-900';
                                    }
                                ?>
                                <i class="<?php echo e($iconClass); ?>"></i>
                                <span class="<?php echo e($textClass); ?>"><?php echo e($feature); ?></span>
                            <?php else: ?>
                                <i class="fas fa-check text-green-500 mr-3 text-sm lg:text-base"></i>
                                <span class="text-gray-900 text-sm lg:text-base"><?php echo e($feature); ?></span>
                            <?php endif; ?>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <?php if($plan->price == 0): ?>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 mr-3 text-sm lg:text-base"></i>
                            <span class="text-sm lg:text-base"><?php echo e(__('Email support')); ?></span>
                        </li>
                        <?php elseif($plan->price >= 99): ?>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 mr-3 text-sm lg:text-base"></i>
                            <span class="text-sm lg:text-base"><?php echo e(__('24/7 support')); ?></span>
                        </li>
                        <?php else: ?>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 mr-3 text-sm lg:text-base"></i>
                            <span class="text-sm lg:text-base"><?php echo e(__('Priority support')); ?></span>
                        </li>
                        <?php endif; ?>
                    </ul>
                    <a href="<?php echo e($plan->price >= 99 ? route('owner.register.with.plan.subscribe', $plan->id) : route('owner.register.form')); ?>" class="w-full <?php echo e($plan->is_popular ? 'btn-primary text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'); ?> py-3 rounded-lg font-semibold text-center block transition-colors text-sm lg:text-base">
                        <?php if($plan->price == 0): ?>
                            <?php echo e(__('Get Started Free')); ?>

                        <?php elseif($plan->price >= 99): ?>
                            <?php echo e(__('Contact Sales')); ?>

                        <?php else: ?>
                            <?php echo e(__('Start :plan Trial', ['plan' => $plan->name])); ?>

                        <?php endif; ?>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="py-12 lg:py-20 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12 lg:mb-16">
                <h2 class="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                    <?php echo e(__('What Our Customers Say')); ?>

                </h2>
                <p class="text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
                    <?php echo e(__('Join thousands of satisfied property owners')); ?>

                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
                <div class="bg-white p-6 lg:p-8 rounded-2xl shadow-lg">
                    <div class="flex items-center mb-4">
                        <div class="text-yellow-400 text-lg lg:text-xl">★★★★★</div>
                    </div>
                    <p class="text-gray-600 mb-6 text-sm lg:text-base"><?php echo e(__('"Bari Manager has completely transformed how I manage my properties. The automated rent collection feature alone has saved me hours every month."')); ?></p>
                    <div class="flex items-center">
                        <div class="w-10 h-10 lg:w-12 lg:h-12 bg-purple-100 rounded-full flex items-center justify-center mr-4">
                            <span class="text-purple-600 font-semibold text-sm lg:text-base">AM</span>
                        </div>
                        <div>
                            <h4 class="font-semibold text-gray-900 text-sm lg:text-base"><?php echo e(__('Ahmed Mahmud')); ?></h4>
                            <p class="text-xs lg:text-sm text-gray-600"><?php echo e(__('Property Owner')); ?></p>
                        </div>
                    </div>
                </div>

                <div class="bg-white p-6 lg:p-8 rounded-2xl shadow-lg">
                    <div class="flex items-center mb-4">
                        <div class="text-yellow-400 text-lg lg:text-xl">★★★★★</div>
                    </div>
                    <p class="text-gray-600 mb-6 text-sm lg:text-base"><?php echo e(__('"The mobile app is fantastic! I can check my rental income and manage tenants from anywhere. Highly recommended!"')); ?></p>
                    <div class="flex items-center">
                        <div class="w-10 h-10 lg:w-12 lg:h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                            <span class="text-blue-600 font-semibold text-sm lg:text-base">SK</span>
                        </div>
                        <div>
                            <h4 class="font-semibold text-gray-900 text-sm lg:text-base"><?php echo e(__('Sara Khan')); ?></h4>
                            <p class="text-xs lg:text-sm text-gray-600"><?php echo e(__('Real Estate Investor')); ?></p>
                        </div>
                    </div>
                </div>

                <div class="bg-white p-6 lg:p-8 rounded-2xl shadow-lg">
                    <div class="flex items-center mb-4">
                        <div class="text-yellow-400 text-lg lg:text-xl">★★★★★</div>
                    </div>
                    <p class="text-gray-600 mb-6 text-sm lg:text-base"><?php echo e(__('"Excellent customer support and easy to use interface. My rental business has grown 200% since using Bari Manager."')); ?></p>
                    <div class="flex items-center">
                        <div class="w-10 h-10 lg:w-12 lg:h-12 bg-green-100 rounded-full flex items-center justify-center mr-4">
                            <span class="text-green-600 font-semibold text-sm lg:text-base">MR</span>
                        </div>
                        <div>
                            <h4 class="font-semibold text-gray-900 text-sm lg:text-base"><?php echo e(__('Mohammad Rahman')); ?></h4>
                            <p class="text-xs lg:text-sm text-gray-600"><?php echo e(__('Property Manager')); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Login/Registration Section -->
    <section id="register" class="py-12 lg:py-20 bg-white">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-8 lg:mb-12">
                <h2 class="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                    <?php echo e(__('Get Started Today')); ?>

                </h2>
                <p class="text-lg lg:text-xl text-gray-600">
                    <?php echo e(__('Join thousands of property owners who trust Bari Manager')); ?>

                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
                <!-- Registration -->
                <div class="bg-white p-6 lg:p-8 rounded-2xl shadow-lg border border-gray-100">
                    <h3 class="text-xl lg:text-2xl font-bold text-gray-900 mb-4 lg:mb-6"><?php echo e(__('Create Account')); ?></h3>
                    <form class="space-y-3 lg:space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2"><?php echo e(__('Full Name')); ?></label>
                            <input type="text" class="w-full px-3 lg:px-4 py-2 lg:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm lg:text-base">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2"><?php echo e(__('Email')); ?></label>
                            <input type="email" class="w-full px-3 lg:px-4 py-2 lg:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm lg:text-base">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2"><?php echo e(__('Password')); ?></label>
                            <input type="password" class="w-full px-3 lg:px-4 py-2 lg:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm lg:text-base">
                        </div>
                        <button type="submit" class="w-full btn-primary text-white py-2 lg:py-3 rounded-lg font-semibold text-sm lg:text-base">
                            <?php echo e(__('Create Free Account')); ?>

                        </button>
                    </form>
                </div>

                <!-- Login -->
                <div class="bg-white p-6 lg:p-8 rounded-2xl shadow-lg border border-gray-100">
                    <h3 class="text-xl lg:text-2xl font-bold text-gray-900 mb-4 lg:mb-6"><?php echo e(__('Sign In')); ?></h3>
                    <form class="space-y-3 lg:space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2"><?php echo e(__('Email')); ?></label>
                            <input type="email" class="w-full px-3 lg:px-4 py-2 lg:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm lg:text-base">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2"><?php echo e(__('Password')); ?></label>
                            <input type="password" class="w-full px-3 lg:px-4 py-2 lg:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm lg:text-base">
                        </div>
                        <button type="submit" class="w-full btn-primary text-white py-2 lg:py-3 rounded-lg font-semibold text-sm lg:text-base">
                            <?php echo e(__('Sign In')); ?>

                        </button>
                    </form>
                    <div class="mt-4 lg:mt-6 text-center">
                        <a href="#" class="text-purple-600 hover:text-purple-700 font-medium text-sm lg:text-base"><?php echo e(__('Forgot password?')); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Support Section -->
    <section id="support" class="py-12 lg:py-20 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12 lg:mb-16">
                <h2 class="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                    <?php echo e(__('We\'re Here to Help')); ?>

                </h2>
                <p class="text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
                    <?php echo e(__('Get the support you need to succeed with Bari Manager')); ?>

                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
                <div class="text-center">
                    <div class="bg-purple-100 p-4 lg:p-6 rounded-full w-16 h-16 lg:w-20 lg:h-20 flex items-center justify-center mx-auto mb-4 lg:mb-6">
                        <i class="fas fa-headset text-purple-600 text-2xl lg:text-3xl"></i>
                    </div>
                    <h3 class="text-lg lg:text-xl font-semibold text-gray-900 mb-3 lg:mb-4"><?php echo e(__('24/7 Support')); ?></h3>
                    <p class="text-gray-600 text-sm lg:text-base"><?php echo e(__('Our support team is available around the clock to help you with any questions.')); ?></p>
                </div>

                <div class="text-center">
                    <div class="bg-blue-100 p-4 lg:p-6 rounded-full w-16 h-16 lg:w-20 lg:h-20 flex items-center justify-center mx-auto mb-4 lg:mb-6">
                        <i class="fas fa-book text-blue-600 text-2xl lg:text-3xl"></i>
                    </div>
                    <h3 class="text-lg lg:text-xl font-semibold text-gray-900 mb-3 lg:mb-4"><?php echo e(__('Documentation')); ?></h3>
                    <p class="text-gray-600 text-sm lg:text-base"><?php echo e(__('Comprehensive guides and tutorials to help you get the most out of Bari Manager.')); ?></p>
                </div>

                <div class="text-center">
                    <div class="bg-green-100 p-4 lg:p-6 rounded-full w-16 h-16 lg:w-20 lg:h-20 flex items-center justify-center mx-auto mb-4 lg:mb-6">
                        <i class="fas fa-video text-green-600 text-2xl lg:text-3xl"></i>
                    </div>
                    <h3 class="text-lg lg:text-xl font-semibold text-gray-900 mb-3 lg:mb-4"><?php echo e(__('Video Tutorials')); ?></h3>
                    <p class="text-gray-600 text-sm lg:text-base"><?php echo e(__('Step-by-step video guides to help you master every feature of Bari Manager.')); ?></p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-12 lg:py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                <div class="text-center sm:text-left">
                    <a href="#home" class="cursor-pointer">
                        <img src="<?php echo e(asset('images/bari-manager-logo.svg')); ?>" alt="Bari Manager Logo" class="h-8 lg:h-10 w-auto mb-4 hover:opacity-80 transition-opacity mx-auto sm:mx-0">
                    </a>
                    <p class="text-gray-400 mb-4 text-sm lg:text-base">
                        <?php echo e(__('The complete house rent management solution for property owners.')); ?>

                    </p>
                    <div class="flex space-x-4 justify-center sm:justify-start">
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-facebook text-lg lg:text-xl"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-twitter text-lg lg:text-xl"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-linkedin text-lg lg:text-xl"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-instagram text-lg lg:text-xl"></i>
                        </a>
                    </div>
                </div>

                <div class="text-center sm:text-left">
                    <h4 class="text-base lg:text-lg font-semibold mb-4"><?php echo e(__('Product')); ?></h4>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors text-sm lg:text-base"><?php echo e(__('Features')); ?></a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors text-sm lg:text-base"><?php echo e(__('Pricing')); ?></a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors text-sm lg:text-base"><?php echo e(__('Mobile App')); ?></a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors text-sm lg:text-base"><?php echo e(__('API')); ?></a></li>
                    </ul>
                </div>

                <div class="text-center sm:text-left">
                    <h4 class="text-base lg:text-lg font-semibold mb-4"><?php echo e(__('Support')); ?></h4>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors text-sm lg:text-base"><?php echo e(__('Help Center')); ?></a></li>
                        <li><a href="<?php echo e(route('contact')); ?>" class="text-gray-400 hover:text-white transition-colors text-sm lg:text-base"><?php echo e(__('Contact Us')); ?></a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors text-sm lg:text-base"><?php echo e(__('Documentation')); ?></a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors text-sm lg:text-base"><?php echo e(__('Status')); ?></a></li>
                    </ul>
                </div>

                <div class="text-center sm:text-left">
                    <h4 class="text-base lg:text-lg font-semibold mb-4"><?php echo e(__('Legal')); ?></h4>
                    <ul class="space-y-2">
                        <li><a href="<?php echo e(route('terms')); ?>" class="text-gray-400 hover:text-white transition-colors text-sm lg:text-base"><?php echo e(__('Terms & Conditions')); ?></a></li>
                        <li><a href="<?php echo e(route('privacy')); ?>" class="text-gray-400 hover:text-white transition-colors text-sm lg:text-base"><?php echo e(__('Privacy Policy')); ?></a></li>
                        <li><a href="<?php echo e(route('refund')); ?>" class="text-gray-400 hover:text-white transition-colors text-sm lg:text-base"><?php echo e(__('Refund Policy')); ?></a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors text-sm lg:text-base"><?php echo e(__('About')); ?></a></li>
                    </ul>
                </div>
            </div>

            <div class="border-t border-gray-800 mt-8 lg:mt-12 pt-6 lg:pt-8 text-center">
                <p class="text-gray-400 text-sm lg:text-base">
                    © 2024 <?php echo e(__('Bari Manager')); ?>. <?php echo e(__('All rights reserved.')); ?> | <?php echo e(__('House Rent Management System')); ?>

                </p>
            </div>
        </div>
    </footer>

    <!-- Language Switcher Script -->
    <script>
        function changeLanguage(lang) {
            window.location.href = '<?php echo e(route("language.switch")); ?>?lang=' + lang;
        }

        // Mobile Menu Toggle
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuButton = document.getElementById('mobile-menu-button');
            const mobileMenu = document.getElementById('mobile-menu');

            if (mobileMenuButton && mobileMenu) {
                mobileMenuButton.addEventListener('click', function() {
                    mobileMenu.classList.toggle('hidden');
                });

                // Close mobile menu when clicking on a link
                const mobileMenuLinks = mobileMenu.querySelectorAll('a');
                mobileMenuLinks.forEach(link => {
                    link.addEventListener('click', function() {
                        mobileMenu.classList.add('hidden');
                    });
                });
            }
        });

        // Smooth Scrolling
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Active Navigation Highlighting
        function updateActiveNav() {
            const sections = document.querySelectorAll('section[id]');
            const navLinks = document.querySelectorAll('.nav-link');

            let current = '';

            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                if (window.pageYOffset >= (sectionTop - 200)) {
                    current = section.getAttribute('id');
                }
            });

            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('data-section') === current) {
                    link.classList.add('active');
                }
            });
        }

        // Update active nav on scroll
        window.addEventListener('scroll', updateActiveNav);

        // Update active nav on page load
        document.addEventListener('DOMContentLoaded', updateActiveNav);

        // Update active nav when clicking nav links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', function() {
                // Remove active class from all links
                document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
                // Add active class to clicked link
                this.classList.add('active');
            });
        });
    </script>

    <!-- Live Chat Widget -->
    <?php
        $chatSettings = \App\Models\SystemSetting::where('key', 'like', 'chat_%')->pluck('value', 'key');
        $chatEnabled = $chatSettings['chat_enabled'] ?? '1';
    ?>
    
    <?php if($chatEnabled == '1'): ?>
    <div id="live-chat-widget" class="fixed bottom-4 right-4 z-50">
        <!-- Chat Button -->
        <div id="chat-button" class="bg-purple-600 hover:bg-purple-700 text-white rounded-full p-4 shadow-lg cursor-pointer transition-all duration-300 transform hover:scale-110">
            <i class="fas fa-comments text-xl"></i>
        </div>
        
        <!-- Chat Window -->
        <div id="chat-window" class="hidden bg-white rounded-lg shadow-2xl w-80 h-96 mb-4 border border-gray-200">
            <!-- Chat Header -->
            <div class="bg-purple-600 text-white p-4 rounded-t-lg flex justify-between items-center">
                <div class="flex items-center">
                    <div class="w-3 h-3 bg-green-400 rounded-full mr-2"></div>
                    <span class="font-semibold"><?php echo e($chatSettings['chat_bot_name'] ?? 'Bari Manager Support'); ?></span>
                </div>
                <button id="close-chat" class="text-white hover:text-gray-200">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <!-- Chat Messages -->
            <div id="chat-messages" class="h-64 overflow-y-auto p-4 space-y-3">
                <!-- Welcome Message -->
                <div class="flex items-start space-x-2">
                    <div class="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
                        <i class="fas fa-headset text-white text-sm"></i>
                    </div>
                    <div class="bg-gray-100 rounded-lg p-3 max-w-xs">
                        <p class="text-sm text-gray-800"><?php echo e($chatSettings['chat_welcome_message'] ?? 'Hello! 👋 Welcome to Bari Manager. How can I help you today?'); ?></p>
                    </div>
                </div>
                
                <!-- Quick Options -->
                <div class="flex items-start space-x-2">
                    <div class="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
                        <i class="fas fa-headset text-white text-sm"></i>
                    </div>
                    <div class="bg-gray-100 rounded-lg p-3 max-w-xs">
                        <p class="text-sm text-gray-800 mb-2">Quick options:</p>
                        <div class="space-y-1">
                            <button class="quick-option text-xs bg-white px-2 py-1 rounded border hover:bg-gray-50" data-option="pricing">💰 Pricing & Plans</button>
                            <button class="quick-option text-xs bg-white px-2 py-1 rounded border hover:bg-gray-50" data-option="demo">🎥 Request Demo</button>
                            <button class="quick-option text-xs bg-white px-2 py-1 rounded border hover:bg-gray-50" data-option="support">🛠️ Technical Support</button>
                            <button class="quick-option text-xs bg-white px-2 py-1 rounded border hover:bg-gray-50" data-option="features">✨ Features</button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Chat Input -->
            <div class="p-4 border-t border-gray-200">
                <div class="flex space-x-2">
                    <input type="text" id="chat-input" placeholder="Type your message..." class="flex-1 border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                    <button id="send-message" class="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors">
                        <i class="fas fa-paper-plane text-sm"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Live Chat JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const chatButton = document.getElementById('chat-button');
            const chatWindow = document.getElementById('chat-window');
            const closeChat = document.getElementById('close-chat');
            const chatMessages = document.getElementById('chat-messages');
            const chatInput = document.getElementById('chat-input');
            const sendMessage = document.getElementById('send-message');
            
            // Generate session ID
            const sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            
            // Track last message timestamp for polling
            let lastMessageTimestamp = Date.now();
            
            // Advanced Chatbot System
            class AdvancedChatbot {
                constructor() {
                    this.conversationHistory = [];
                    this.userContext = {
                        name: null,
                        email: null,
                        propertyCount: null,
                        interests: [],
                        stage: 'greeting'
                    };
                    this.knowledgeBase = {
                        pricing: {
                            free: {
                                price: 'Free',
                                properties: 'Up to 5',
                                features: ['Basic property management', 'Tenant profiles', 'Rent tracking', 'Email support'],
                                limitations: ['No advanced analytics', 'No mobile app', 'Limited storage']
                            },
                            basic: {
                                price: '$9/month',
                                properties: 'Up to 20',
                                features: ['Everything in Free', 'Advanced analytics', 'Maintenance tracking', 'Priority support'],
                                limitations: ['No custom branding', 'Limited integrations']
                            },
                            pro: {
                                price: '$19/month',
                                properties: 'Unlimited',
                                features: ['Everything in Basic', 'Custom branding', 'API access', 'White-label solution', 'Dedicated support'],
                                limitations: []
                            }
                        },
                        features: {
                            property_management: {
                                name: 'Property Management',
                                description: 'Manage multiple properties, units, and their details',
                                benefits: ['Centralized property database', 'Unit tracking', 'Property photos', 'Document storage']
                            },
                            tenant_management: {
                                name: 'Tenant Management',
                                description: 'Complete tenant profiles and communication tools',
                                benefits: ['Tenant profiles', 'Rent history', 'Communication logs', 'Document sharing']
                            },
                            rent_collection: {
                                name: 'Rent Collection',
                                description: 'Automated rent tracking and payment reminders',
                                benefits: ['Payment tracking', 'Automated reminders', 'Financial reports', 'Online payments']
                            },
                            maintenance: {
                                name: 'Maintenance Tracking',
                                description: 'Track maintenance requests and completion status',
                                benefits: ['Request tracking', 'Photo attachments', 'Status updates', 'Cost tracking']
                            },
                            analytics: {
                                name: 'Analytics & Reports',
                                description: 'Comprehensive reports and business insights',
                                benefits: ['Revenue reports', 'Occupancy rates', 'Expense tracking', 'Performance metrics']
                            },
                            mobile: {
                                name: 'Mobile App',
                                description: 'Access your system anywhere with mobile app',
                                benefits: ['iOS & Android apps', 'Real-time notifications', 'Photo capture', 'Offline access']
                            }
                        },
                        support: {
                            email: 'support@barimanager.com',
                            phone: '+880-1234-567890',
                            hours: '9 AM - 6 PM (GMT+6)',
                            response_time: 'Within 2 hours'
                        }
                    };
                }

                // Process user message and generate intelligent response
                processMessage(message) {
                    const lowerMessage = message.toLowerCase();
                    this.conversationHistory.push({ role: 'user', message: message });

                    // Update user context based on message
                    this.updateContext(message);

                    // Generate response based on context and message
                    const response = this.generateResponse(lowerMessage);
                    
                    this.conversationHistory.push({ role: 'bot', message: response.message });
                    return response;
                }

                // Update user context
                updateContext(message) {
                    const lowerMessage = message.toLowerCase();
                    
                    // Extract name
                    if (lowerMessage.includes('my name is') || lowerMessage.includes('i am') || lowerMessage.includes('call me')) {
                        const nameMatch = message.match(/(?:my name is|i am|call me)\s+([a-zA-Z\s]+)/i);
                        if (nameMatch) {
                            this.userContext.name = nameMatch[1].trim();
                        }
                    }

                    // Extract email
                    const emailMatch = message.match(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/);
                    if (emailMatch) {
                        this.userContext.email = emailMatch[0];
                    }

                    // Extract property count
                    const propertyMatch = message.match(/(\d+)\s+(?:properties?|houses?|units?)/i);
                    if (propertyMatch) {
                        this.userContext.propertyCount = parseInt(propertyMatch[1]);
                    }

                    // Track interests
                    if (lowerMessage.includes('pricing') || lowerMessage.includes('cost') || lowerMessage.includes('price')) {
                        this.userContext.interests.push('pricing');
                    }
                    if (lowerMessage.includes('feature') || lowerMessage.includes('what can') || lowerMessage.includes('capabilities')) {
                        this.userContext.interests.push('features');
                    }
                    if (lowerMessage.includes('demo') || lowerMessage.includes('show me') || lowerMessage.includes('tour')) {
                        this.userContext.interests.push('demo');
                    }
                }

                // Generate intelligent response
                generateResponse(message) {
                    // Greeting stage
                    if (this.userContext.stage === 'greeting') {
                        if (this.userContext.name) {
                            this.userContext.stage = 'main';
                            return {
                                message: `Nice to meet you, ${this.userContext.name}! 👋 I'm here to help you with Bari Manager. What would you like to know about?\n\n💡 Quick options:\n• Pricing & Plans\n• Features & Capabilities\n• Request Demo\n• Technical Support`,
                                intent: 'greeting',
                                suggestions: ['Pricing & Plans', 'Features & Capabilities', 'Request Demo', 'Technical Support']
                            };
                        } else {
                            return {
                                message: `Hello! 👋 I'm your Bari Manager assistant. I can help you with pricing, features, demos, and support.\n\nWhat's your name?`,
                                intent: 'greeting',
                                suggestions: ['My name is...', 'I prefer to remain anonymous']
                            };
                        }
                    }

                    // Main conversation stage
                    if (this.userContext.stage === 'main') {
                        // Pricing queries
                        if (message.includes('pricing') || message.includes('cost') || message.includes('price') || message.includes('plan')) {
                            return this.handlePricingQuery(message);
                        }

                        // Feature queries
                        if (message.includes('feature') || message.includes('what can') || message.includes('capabilities')) {
                            return this.handleFeatureQuery(message);
                        }

                        // Demo requests
                        if (message.includes('demo') || message.includes('show me') || message.includes('tour')) {
                            return this.handleDemoRequest(message);
                        }

                        // Support queries
                        if (message.includes('support') || message.includes('help') || message.includes('issue')) {
                            return this.handleSupportQuery(message);
                        }

                        // Agent transfer
                        if (message.includes('agent') || message.includes('human') || message.includes('person')) {
                            return {
                                message: 'I understand you\'d like to speak with a human agent. Let me transfer you to one of our support specialists.',
                                intent: 'agent_transfer',
                                transfer: true
                            };
                        }

                        // Default response
                        return {
                            message: `I'm here to help you with Bari Manager! What would you like to know?\n\n💡 Quick options:\n• Pricing & Plans\n• Features & Capabilities\n• Request Demo\n• Technical Support`,
                            intent: 'general',
                            suggestions: ['Pricing & Plans', 'Features & Capabilities', 'Request Demo', 'Technical Support']
                        };
                    }

                    return {
                        message: 'I\'m here to help! What would you like to know about Bari Manager?',
                        intent: 'general'
                    };
                }

                // Handle pricing queries
                handlePricingQuery(message) {
                    const plans = this.knowledgeBase.pricing;
                    
                    if (message.includes('free') || message.includes('basic') || message.includes('pro')) {
                        if (message.includes('free')) {
                            return {
                                message: `🆓 **Free Plan** (${plans.free.price})\n\n📊 Properties: ${plans.free.properties}\n✅ Features:\n${plans.free.features.map(f => `• ${f}`).join('\n')}\n\n${plans.free.limitations.length > 0 ? `⚠️ Limitations:\n${plans.free.limitations.map(l => `• ${l}`).join('\n')}` : ''}\n\nWould you like to know about our paid plans?`,
                                intent: 'pricing_detail',
                                suggestions: ['Tell me about Basic Plan', 'Tell me about Pro Plan', 'How do I sign up?']
                            };
                        } else if (message.includes('basic')) {
                            return {
                                message: `💰 **Basic Plan** (${plans.basic.price})\n\n📊 Properties: ${plans.basic.properties}\n✅ Features:\n${plans.basic.features.map(f => `• ${f}`).join('\n')}\n\n${plans.basic.limitations.length > 0 ? `⚠️ Limitations:\n${plans.basic.limitations.map(l => `• ${l}`).join('\n')}` : ''}\n\nPerfect for growing property managers!`,
                                intent: 'pricing_detail',
                                suggestions: ['Tell me about Pro Plan', 'How do I upgrade?', 'Request Demo']
                            };
                        } else if (message.includes('pro')) {
                            return {
                                message: `🚀 **Pro Plan** (${plans.pro.price})\n\n📊 Properties: ${plans.pro.properties}\n✅ Features:\n${plans.pro.features.map(f => `• ${f}`).join('\n')}\n\nPerfect for professional property management companies!`,
                                intent: 'pricing_detail',
                                suggestions: ['How do I sign up?', 'Request Demo', 'Contact Sales']
                            };
                        }
                    }

                    // General pricing overview
                    return {
                        message: `Here are our pricing plans:\n\n🆓 **Free Plan** (${plans.free.price})\n• ${plans.free.properties} properties\n• Basic features\n\n💰 **Basic Plan** (${plans.basic.price})\n• ${plans.basic.properties} properties\n• Advanced features\n\n🚀 **Pro Plan** (${plans.pro.price})\n• ${plans.pro.properties} properties\n• All features + custom branding\n\nWhich plan interests you most?`,
                        intent: 'pricing_overview',
                        suggestions: ['Tell me about Free Plan', 'Tell me about Basic Plan', 'Tell me about Pro Plan', 'Request Demo']
                    };
                }

                // Handle feature queries
                handleFeatureQuery(message) {
                    const features = this.knowledgeBase.features;
                    
                    // Check for specific feature mentions
                    for (const [key, feature] of Object.entries(features)) {
                        if (message.includes(key.replace('_', ' ')) || message.includes(feature.name.toLowerCase())) {
                            return {
                                message: `✨ **${feature.name}**\n\n${feature.description}\n\n✅ Benefits:\n${feature.benefits.map(b => `• ${b}`).join('\n')}\n\nWould you like to know about other features or see pricing?`,
                                intent: 'feature_detail',
                                suggestions: ['Tell me about other features', 'Show me pricing', 'Request Demo']
                            };
                        }
                    }

                    // General features overview
                    const featureList = Object.values(features).map(f => `• ${f.name}`).join('\n');
                    return {
                        message: `Bari Manager includes these powerful features:\n\n${featureList}\n\nWhich feature would you like to learn more about?`,
                        intent: 'features_overview',
                        suggestions: ['Property Management', 'Tenant Management', 'Rent Collection', 'Maintenance Tracking', 'Analytics & Reports', 'Mobile App']
                    };
                }

                // Handle demo requests
                handleDemoRequest(message) {
                    if (this.userContext.email) {
                        return {
                            message: `Perfect! I'll arrange a personalized demo for you. Since I have your email (${this.userContext.email}), I'll send you a calendar link.\n\n📅 **Demo Details:**\n• Duration: 30 minutes\n• Format: Video call\n• What we'll cover: Your specific use case\n\nI'm sending you an email with scheduling options. Check your inbox!`,
                            intent: 'demo_scheduled'
                        };
                    } else {
                        return {
                            message: `I'd be happy to arrange a personalized demo for you!\n\n📅 **Demo Details:**\n• Duration: 30 minutes\n• Format: Video call\n• What we'll cover: Your specific needs\n\nCould you please provide your email address so I can send you the scheduling link?`,
                            intent: 'demo_request',
                            suggestions: ['My email is...', 'I prefer to schedule later']
                        };
                    }
                }

                // Handle support queries
                handleSupportQuery(message) {
                    const support = this.knowledgeBase.support;
                    return {
                        message: `🛠️ **Technical Support**\n\n📧 Email: ${support.email}\n📞 Phone: ${support.phone}\n🕒 Hours: ${support.hours}\n⏱️ Response Time: ${support.response_time}\n\nWhat specific issue are you facing? I can help guide you or connect you with our support team.`,
                        intent: 'support_info',
                        suggestions: ['I have a technical issue', 'I need help with setup', 'Contact support team']
                    };
                }
            }

            // Initialize advanced chatbot
            const chatbot = new AdvancedChatbot();
            
            // Store message in database
            async function storeMessage(message, messageType, intent = null) {
                try {
                    const response = await fetch('<?php echo e(route("chat.store")); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                        },
                        body: JSON.stringify({
                            session_id: sessionId,
                            message: message,
                            message_type: messageType,
                            intent: intent
                        })
                    });
                    
                    if (!response.ok) {
                        console.error('Failed to store chat message');
                    } else {
                        // Update timestamp for user messages
                        if (messageType === 'user') {
                            lastMessageTimestamp = Date.now();
                        }
                    }
                } catch (error) {
                    console.error('Error storing chat message:', error);
                }
            }
            
            // Toggle chat window
            chatButton.addEventListener('click', function() {
                chatWindow.classList.toggle('hidden');
                chatButton.classList.toggle('hidden');
            });
            
            closeChat.addEventListener('click', function() {
                chatWindow.classList.add('hidden');
                chatButton.classList.remove('hidden');
            });
            
            // Send message
            function sendUserMessage(message) {
                const messageDiv = document.createElement('div');
                messageDiv.className = 'flex items-start space-x-2 justify-end';
                messageDiv.innerHTML = `
                    <div class="bg-purple-600 text-white rounded-lg p-3 max-w-xs">
                        <p class="text-sm">${message}</p>
                    </div>
                    <div class="w-8 h-8 bg-gray-400 rounded-full flex items-center justify-center">
                        <i class="fas fa-user text-white text-sm"></i>
                    </div>
                `;
                chatMessages.appendChild(messageDiv);
                chatMessages.scrollTop = chatMessages.scrollHeight;
                
                // Store user message
                storeMessage(message, 'user');
            }
            
            function sendBotMessage(message, intent = null) {
                const messageDiv = document.createElement('div');
                messageDiv.className = 'flex items-start space-x-2';
                messageDiv.innerHTML = `
                    <div class="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
                        <i class="fas fa-headset text-white text-sm"></i>
                    </div>
                    <div class="bg-gray-100 rounded-lg p-3 max-w-xs">
                        <p class="text-sm text-gray-800 whitespace-pre-line">${message}</p>
                    </div>
                `;
                chatMessages.appendChild(messageDiv);
                chatMessages.scrollTop = chatMessages.scrollHeight;
                
                // Store bot message
                storeMessage(message, 'bot', intent);
                
                // Update timestamp for bot messages
                lastMessageTimestamp = Date.now();
            }
            
            // Handle send button
            sendMessage.addEventListener('click', function() {
                const message = chatInput.value.trim();
                if (message) {
                    sendUserMessage(message);
                    chatInput.value = '';
                    
                    // Process with advanced chatbot
                    setTimeout(() => {
                        const botResponse = chatbot.processMessage(message);
                        sendBotMessage(botResponse.message, botResponse.intent);
                        
                        // Add suggestion buttons if available
                        if (botResponse.suggestions) {
                            addSuggestionButtons(botResponse.suggestions);
                        }
                        
                        // Handle agent transfer
                        if (botResponse.transfer) {
                            requestAgentTransfer();
                        }
                    }, 1000);
                }
            });
            
            // Handle enter key
            chatInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    sendMessage.click();
                }
            });
            
            // Quick option buttons
            document.querySelectorAll('.quick-option').forEach(button => {
                button.addEventListener('click', function() {
                    const option = this.dataset.option;
                    sendUserMessage(this.textContent);
                    setTimeout(() => {
                        const botResponse = chatbot.processMessage(this.textContent);
                        sendBotMessage(botResponse.message, botResponse.intent);
                        
                        if (botResponse.suggestions) {
                            addSuggestionButtons(botResponse.suggestions);
                        }
                    }, 500);
                });
            });
            
            // Add suggestion buttons
            function addSuggestionButtons(suggestions) {
                // Remove existing suggestion buttons
                document.querySelectorAll('.suggestion-btn').forEach(btn => btn.remove());
                
                const suggestionDiv = document.createElement('div');
                suggestionDiv.className = 'flex items-start space-x-2 mt-2';
                suggestionDiv.innerHTML = `
                    <div class="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
                        <i class="fas fa-lightbulb text-white text-sm"></i>
                    </div>
                    <div class="bg-blue-50 rounded-lg p-3 max-w-xs">
                        <p class="text-xs text-blue-800 mb-2">💡 Quick options:</p>
                        <div class="flex flex-wrap gap-1">
                            ${suggestions.map(suggestion => 
                                `<button class="suggestion-btn text-xs bg-blue-600 text-white px-2 py-1 rounded hover:bg-blue-700 transition-colors">${suggestion}</button>`
                            ).join('')}
                        </div>
                    </div>
                `;
                chatMessages.appendChild(suggestionDiv);
                chatMessages.scrollTop = chatMessages.scrollHeight;
                
                // Add event listeners to suggestion buttons
                document.querySelectorAll('.suggestion-btn').forEach(button => {
                    button.addEventListener('click', function() {
                        const suggestion = this.textContent;
                        sendUserMessage(suggestion);
                        chatInput.value = '';
                        
                        setTimeout(() => {
                            const botResponse = chatbot.processMessage(suggestion);
                            sendBotMessage(botResponse.message, botResponse.intent);
                            
                            if (botResponse.suggestions) {
                                addSuggestionButtons(botResponse.suggestions);
                            }
                        }, 500);
                    });
                });
            }
            
            // Request agent transfer
            async function requestAgentTransfer() {
                try {
                    const response = await fetch('<?php echo e(route("chat.request-agent")); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                        },
                        body: JSON.stringify({
                            session_id: sessionId,
                            reason: 'User requested human agent'
                        })
                    });
                    
                    if (response.ok) {
                        sendBotMessage('I\'m transferring you to a human agent. Please wait a moment...', 'agent_transfer');
                        
                        // Add a button to check agent availability
                        const checkAgentDiv = document.createElement('div');
                        checkAgentDiv.className = 'flex items-start space-x-2';
                        checkAgentDiv.innerHTML = `
                            <div class="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
                                <i class="fas fa-headset text-white text-sm"></i>
                            </div>
                            <div class="bg-gray-100 rounded-lg p-3 max-w-xs">
                                <p class="text-sm text-gray-800 mb-2">Checking agent availability...</p>
                                <button id="check-agent-btn" class="text-xs bg-purple-600 text-white px-3 py-1 rounded hover:bg-purple-700">
                                    Check Status
                                </button>
                            </div>
                        `;
                        chatMessages.appendChild(checkAgentDiv);
                        
                        // Add event listener to check agent button
                        document.getElementById('check-agent-btn').addEventListener('click', checkAgentStatus);
                    }
                } catch (error) {
                    console.error('Error requesting agent transfer:', error);
                }
            }
            
            // Check agent status
            async function checkAgentStatus() {
                try {
                    const response = await fetch('<?php echo e(route("chat.agent-availability")); ?>');
                    const data = await response.json();
                    
                    if (data.success) {
                        if (data.data.agent_available) {
                            sendBotMessage('Great! An agent is available and will join the conversation shortly.', 'agent_status');
                        } else {
                            sendBotMessage('Agents are currently busy. Please wait or try again later.', 'agent_status');
                        }
                    }
                } catch (error) {
                    console.error('Error checking agent status:', error);
                }
            }
            
            // Check for new messages from agents
            async function checkForNewMessages() {
                try {
                    const response = await fetch(`<?php echo e(route('chat.session', 'SESSION_ID')); ?>`.replace('SESSION_ID', sessionId));
                    const data = await response.json();
                    
                    if (data.success && data.data.messages) {
                        const messages = data.data.messages;
                        const newMessages = messages.filter(msg => 
                            new Date(msg.created_at).getTime() > lastMessageTimestamp && 
                            msg.message_type === 'agent'
                        );
                        
                        if (newMessages.length > 0) {
                            // Update timestamp
                            lastMessageTimestamp = Math.max(...newMessages.map(msg => new Date(msg.created_at).getTime()));
                            
                            // Display new agent messages
                            newMessages.forEach(message => {
                                const messageDiv = document.createElement('div');
                                messageDiv.className = 'flex items-start space-x-2';
                                messageDiv.innerHTML = `
                                    <div class="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                                        <i class="fas fa-user-tie text-white text-sm"></i>
                                    </div>
                                    <div class="bg-green-100 rounded-lg p-3 max-w-xs">
                                        <p class="text-sm text-gray-800 mb-1"><strong>Agent:</strong></p>
                                        <p class="text-sm text-gray-800">${message.message}</p>
                                        <small class="text-xs text-gray-500">${new Date(message.created_at).toLocaleTimeString()}</small>
                                    </div>
                                `;
                                chatMessages.appendChild(messageDiv);
                                chatMessages.scrollTop = chatMessages.scrollHeight;
                                
                                // Play notification sound for agent messages
                                const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmGgU7k9n1unEiBC13yO/eizEIHWq+8+OWT');
                                audio.play().catch(e => console.log('Audio play failed:', e));
                            });
                            
                            // Show agent joined notification
                            if (newMessages.length === 1) {
                                const notificationDiv = document.createElement('div');
                                notificationDiv.className = 'flex items-start space-x-2';
                                notificationDiv.innerHTML = `
                                    <div class="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                                        <i class="fas fa-user-tie text-white text-sm"></i>
                                    </div>
                                    <div class="bg-green-100 rounded-lg p-3 max-w-xs">
                                        <p class="text-sm text-green-800"><strong>🎉 Agent joined the conversation!</strong></p>
                                    </div>
                                `;
                                chatMessages.appendChild(notificationDiv);
                                chatMessages.scrollTop = chatMessages.scrollHeight;
                            }
                        }
                    }
                } catch (error) {
                    console.error('Error checking for new messages:', error);
                }
            }
            
            // Auto-hide chat after 30 seconds of inactivity
            let chatTimeout;
            function resetChatTimeout() {
                clearTimeout(chatTimeout);
                chatTimeout = setTimeout(() => {
                    if (!chatWindow.classList.contains('hidden')) {
                        chatWindow.classList.add('hidden');
                        chatButton.classList.remove('hidden');
                    }
                }, 30000);
            }
            
            // Reset timeout on any interaction
            chatButton.addEventListener('click', resetChatTimeout);
            chatInput.addEventListener('input', resetChatTimeout);
            sendMessage.addEventListener('click', resetChatTimeout);
            
            // Start polling for new messages from agents
            setInterval(checkForNewMessages, 3000); // Check every 3 seconds
        });
    </script>
    <?php endif; ?>

</body>
</html>
<?php /**PATH /home/barimanager/hrms/resources/views/landing.blade.php ENDPATH**/ ?>