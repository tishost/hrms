<div class="toast align-items-center text-white bg-<?php echo e($type); ?> border-0 mb-2" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex">
        <div class="toast-body">
            <?php echo e($type === 'success' ? '✅' : ($type === 'danger' ? '⚠️' : 'ℹ️')); ?> <?php echo e($message); ?>

        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
</div><?php /**PATH /home/barimanager/hrms/resources/views/components/toast.blade.php ENDPATH**/ ?>