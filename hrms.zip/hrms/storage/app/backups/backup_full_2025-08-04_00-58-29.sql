-- MySQL dump 10.13  Distrib 8.0.43, for Linux (x86_64)
--
-- Host: localhost    Database: barimanager_mrc
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backups`
--

DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backups` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('full','owner','system') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'full',
  `owner_id` bigint unsigned DEFAULT NULL,
  `size` bigint NOT NULL DEFAULT '0',
  `status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_by` bigint unsigned NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `restored_at` timestamp NULL DEFAULT NULL,
  `restored_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backups_type_status_index` (`type`,`status`),
  KEY `backups_owner_id_created_at_index` (`owner_id`,`created_at`),
  KEY `backups_created_at_index` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups`
--

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
INSERT INTO `backups` VALUES (1,'test_backup.sql','full',NULL,1024,'completed',1,NULL,NULL,NULL,'2025-08-03 12:40:40','2025-08-03 12:40:40',NULL),(2,'test_backup_2.sql','full',NULL,2048,'completed',1,NULL,NULL,NULL,'2025-08-03 12:44:22','2025-08-03 12:44:22',NULL);
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing`
--

DROP TABLE IF EXISTS `billing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `billing` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` bigint unsigned NOT NULL,
  `subscription_id` bigint unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('paid','unpaid','cancel','fail','refund') COLLATE utf8mb4_unicode_ci DEFAULT 'unpaid',
  `due_date` date NOT NULL,
  `paid_date` date DEFAULT NULL,
  `invoice_number` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verification_details` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `payment_method_id` bigint unsigned DEFAULT NULL,
  `transaction_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `net_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `billing_invoice_number_unique` (`invoice_number`),
  KEY `billing_owner_id_foreign` (`owner_id`),
  KEY `billing_subscription_id_foreign` (`subscription_id`),
  KEY `billing_payment_method_id_foreign` (`payment_method_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing`
--

LOCK TABLES `billing` WRITE;
/*!40000 ALTER TABLE `billing` DISABLE KEYS */;
INSERT INTO `billing` VALUES (20,17,25,999.00,'cancel','2025-08-07','2025-07-31','INV-2025-000025',NULL,'TR0011hUv0sG91753986306095',NULL,'2025-07-31 11:58:21','2025-07-31 12:29:47',1,14.99,1013.99);
/*!40000 ALTER TABLE `billing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('hrms_seo_settings','O:29:\"Illuminate\\Support\\Collection\":2:{s:8:\"\0*\0items\";a:186:{s:14:\"otp_send_limit\";s:1:\"5\";s:22:\"default_building_limit\";s:1:\"1\";s:18:\"default_unit_limit\";s:2:\"10\";s:14:\"seo_meta_title\";s:52:\"Bari Manager - Complete Property Management Solution\";s:20:\"seo_meta_description\";s:151:\"Manage your properties, tenants, and rentals with our comprehensive property management system. Features include tenant management and rent collection.\";s:17:\"seo_meta_keywords\";s:99:\"property management, tenant management, rent collection, maintenance tracking, real estate software\";s:12:\"seo_og_title\";s:52:\"Bari Manager - Complete Property Management Solution\";s:18:\"seo_og_description\";s:127:\"Streamline your property management with our comprehensive solution. Manage tenants, collect rent, track maintenance, and more.\";s:12:\"seo_og_image\";s:43:\"https://barimanager.com/images/og-image.jpg\";s:17:\"seo_twitter_title\";s:44:\"Bari Manager - Property Management Made Easy\";s:23:\"seo_twitter_description\";s:74:\"Complete property management solution for landlords and property managers.\";s:17:\"seo_twitter_image\";s:48:\"https://barimanager.com/images/twitter-image.jpg\";s:17:\"seo_canonical_url\";s:23:\"https://barimanager.com\";s:14:\"seo_schema_org\";s:268:\"{\"@context\":\"https://schema.org\",\"@type\":\"SoftwareApplication\",\"name\":\"Bari Manager\",\"description\":\"Complete property management solution\",\"applicationCategory\":\"BusinessApplication\",\"operatingSystem\":\"Web\",\"offers\":{\"@type\":\"Offer\",\"price\":\"0\",\"priceCurrency\":\"USD\"}}\";s:22:\"seo_breadcrumb_enabled\";s:1:\"1\";s:19:\"seo_sitemap_enabled\";s:1:\"1\";s:20:\"seo_hreflang_enabled\";s:1:\"1\";s:24:\"seo_lazy_loading_enabled\";s:1:\"1\";s:18:\"seo_minify_enabled\";s:1:\"0\";s:23:\"seo_compression_enabled\";s:1:\"1\";s:14:\"seo_robots_txt\";s:101:\"User-agent: * Allow: / Disallow: /admin/ Disallow: /api/ Sitemap: https://barimanager.com/sitemap.xml\";s:13:\"chat_bot_name\";s:20:\"Bari Manager Support\";s:20:\"chat_welcome_message\";s:62:\"Hello! 👋 Welcome to Bari Manager. How can I help you today?\";s:26:\"chat_auto_response_enabled\";s:1:\"1\";s:27:\"chat_agent_transfer_enabled\";s:1:\"1\";s:23:\"chat_notification_sound\";s:1:\"1\";s:21:\"chat_typing_indicator\";s:1:\"1\";s:13:\"chat_position\";s:12:\"bottom-right\";s:16:\"chat_theme_color\";s:6:\"purple\";s:18:\"chat_working_hours\";s:19:\"9 AM - 6 PM (GMT+6)\";s:20:\"chat_offline_message\";s:80:\"We are currently offline. Please leave a message and we\'ll get back to you soon.\";s:18:\"chat_max_file_size\";s:1:\"5\";s:23:\"chat_allowed_file_types\";s:25:\"jpg,jpeg,png,pdf,doc,docx\";s:12:\"chat_enabled\";s:1:\"0\";s:24:\"chat_file_upload_enabled\";s:1:\"0\";s:13:\"sms_api_token\";s:40:\"lJp4X9JWUFZ0tB2aivJc0OeC9zSQUhIZTnHRBGyl\";s:13:\"sms_sender_id\";s:13:\"8809617628822\";s:15:\"sms_test_number\";s:11:\"01718262530\";s:24:\"sms_reminder_days_before\";s:1:\"3\";s:23:\"sms_working_hours_start\";s:5:\"09:00\";s:21:\"sms_working_hours_end\";s:5:\"18:00\";s:15:\"sms_max_retries\";s:1:\"3\";s:15:\"sms_retry_delay\";s:1:\"5\";s:11:\"sms_enabled\";s:1:\"1\";s:25:\"sms_rent_reminder_enabled\";s:1:\"0\";s:30:\"sms_maintenance_update_enabled\";s:1:\"0\";s:27:\"sms_welcome_message_enabled\";s:1:\"0\";s:32:\"sms_payment_confirmation_enabled\";s:1:\"0\";s:29:\"sms_checkout_reminder_enabled\";s:1:\"0\";s:13:\"email_enabled\";s:1:\"1\";s:9:\"mail_host\";s:20:\"sg-vnth.clouddns.one\";s:9:\"mail_port\";s:3:\"587\";s:13:\"mail_username\";s:23:\"noreply@barimanager.com\";s:13:\"mail_password\";s:15:\"Samiul28101988!\";s:15:\"mail_encryption\";s:3:\"ssl\";s:17:\"mail_from_address\";s:23:\"noreply@barimanager.com\";s:34:\"template_account_setup_guide_email\";s:121:\"{\"subject\":\"Account Setup Guide\",\"content\":\"<h2>Account Setup Guide<\\/h2><p>Here\'s how to get started with HRMS...<\\/p>\"}\";s:17:\"template_test_sms\";s:30:\"{\"content\":\"Test SMS content\"}\";s:21:\"template_test_session\";s:26:\"{\"content\":\"Test content\"}\";s:32:\"template_features_overview_email\";s:130:\"{\"subject\":\"HRMS Features Overview\",\"content\":\"<h2>Features Overview<\\/h2><p>Discover all the features available in HRMS...<\\/p>\"}\";s:12:\"sms_provider\";s:7:\"smsinbd\";s:11:\"sms_api_key\";s:40:\"lJp4X9JWUFZ0tB2aivJc0OeC9zSQUhIZTnHRBGyl\";s:14:\"sms_api_secret\";s:0:\"\";s:17:\"sms_monthly_limit\";s:4:\"1000\";s:17:\"sms_monthly_count\";s:2:\"25\";s:32:\"template_subscription_info_email\";s:270:\"{\"subject\":\"Welcome to HRMS - Subscription Details\",\"content\":\"Dear {name},\\n\\nYour subscription details:\\n\\nPlan: {plan_name}\\nPrice: ${plan_price}\\nExpiry Date: {expiry_date}\\nSMS Credits: {sms_credits}\\n\\nThank you for choosing HRMS!\\n\\nBest regards,\\nThe HRMS Team\"}\";s:35:\"template_payment_confirmation_email\";s:284:\"{\"subject\":\"Payment Confirmation - HRMS\",\"content\":\"Dear {name},\\n\\nYour payment of \\u09f3{amount} has been received successfully.\\n\\nInvoice Number: {invoice_number}\\nPayment Method: {payment_method}\\nDate: {payment_date}\\n\\nThank you for your business!\\n\\nBest regards,\\nHRMS Team\"}\";s:22:\"template_welcome_email\";s:226:\"{\"subject\":\"Welcome to HRMS!\",\"content\":\"Dear {name},\\n\\nWelcome to HRMS! Your account has been created successfully.\\n\\nYou can now access all our services and manage your properties efficiently.\\n\\nBest regards,\\nHRMS Team\"}\";s:11:\"test_simple\";s:10:\"test_value\";s:9:\"template_\";s:31:\"{\"subject\":null,\"content\":null}\";s:42:\"template_owner_subscription_activation_sms\";s:99:\"{\"content\":\"Dear {name}, subscription activated! Plan: {plan_name}, Expiry: {expiry_date}. - HRMS\"}\";s:40:\"template_owner_subscription_reminder_sms\";s:114:\"{\"content\":\"Dear {name}, your subscription expires on {expiry_date}. Please renew to continue services. - HRMS..\"}\";s:35:\"template_invoice_notification_email\";s:293:\"{\"subject\":\"New Invoice Generated - HRMS\",\"content\":\"Dear {name},\\n\\nA new invoice has been generated for your account.\\n\\nInvoice Number: {invoice_number}\\nAmount: \\u09f3{amount}\\nDue Date: {due_date}\\n\\nPlease log in to your account to view and pay the invoice.\\n\\nBest regards,\\nHRMS Team\"}\";s:36:\"template_subscription_reminder_email\";s:236:\"{\"subject\":\"Subscription Reminder - HRMS\",\"content\":\"Dear {name},\\n\\nYour subscription will expire on {expiry_date}.\\n\\nPlease renew your subscription to continue enjoying our services without interruption.\\n\\nBest regards,\\nHRMS Team\"}\";s:38:\"template_subscription_activation_email\";s:254:\"{\"subject\":\"Subscription Activated - HRMS\",\"content\":\"Dear {name},\\n\\nYour subscription has been activated successfully!\\n\\nPlan: {plan_name}\\nPrice: \\u09f3{plan_price}\\nExpiry Date: {expiry_date}\\nSMS Credits: {sms_credits}\\n\\nBest regards,\\nHRMS Team\"}\";s:35:\"template_account_verification_email\";s:225:\"{\"subject\":\"Verify Your Account - HRMS\",\"content\":\"Dear {{name}},\\n\\nPlease verify your email address by clicking the link below:\\n\\n{{verification_url}}\\n\\nThis link will expire in 24 hours.\\n\\nBest regards,\\nThe HRMS Team\"}\";s:29:\"template_password_reset_email\";s:296:\"{\"subject\":\"Password Reset Request - HRMS\",\"content\":\"Dear {{name}},\\n\\nYou have requested to reset your password. Click the link below to reset it:\\n\\n{{reset_url}}\\n\\nThis link will expire in 60 minutes.\\n\\nIf you didn\'t request this, please ignore this email.\\n\\nBest regards,\\nThe HRMS Team\"}\";s:29:\"template_security_alert_email\";s:277:\"{\"subject\":\"Security Alert - HRMS\",\"content\":\"Dear {{name}},\\n\\nWe detected unusual activity on your account:\\n\\nActivity: {{activity}}\\nTime: {{timestamp}}\\nIP Address: {{ip_address}}\\n\\nIf this wasn\'t you, please contact support immediately.\\n\\nBest regards,\\nThe HRMS Team\"}\";s:43:\"template_subscription_expiry_reminder_email\";s:280:\"{\"subject\":\"Subscription Expiring Soon - HRMS\",\"content\":\"Dear {{name}},\\n\\nYour subscription will expire in {{days_left}} days.\\n\\nPlan: {{plan_name}}\\nExpiry Date: {{expiry_date}}\\n\\nPlease renew your subscription to avoid service interruption.\\n\\nBest regards,\\nThe HRMS Team\"}\";s:30:\"template_payment_success_email\";s:315:\"{\"subject\":\"Payment Successful - HRMS\",\"content\":\"Dear {{name}},\\n\\nYour payment has been processed successfully!\\n\\nPayment Details:\\nAmount: ${{amount}}\\nTransaction ID: {{transaction_id}}\\nPayment Method: {{payment_method}}\\nDate: {{payment_date}}\\n\\nThank you for your payment!\\n\\nBest regards,\\nThe HRMS Team\"}\";s:31:\"template_invoice_reminder_email\";s:308:\"{\"subject\":\"Invoice Reminder - HRMS\",\"content\":\"Dear {{name}},\\n\\nThis is a reminder for your pending invoice:\\n\\nInvoice Number: {{invoice_number}}\\nAmount: ${{amount}}\\nDue Date: {{due_date}}\\n\\nPayment Link: {{payment_url}}\\n\\nPlease make the payment before the due date.\\n\\nBest regards,\\nThe HRMS Team\"}\";s:20:\"template_welcome_sms\";s:113:\"{\"subject\":\"HRMS Notification\",\"content\":\"Welcome {{name}} to HRMS! Your account has been successfully created.\"}\";s:33:\"template_payment_confirmation_sms\";s:116:\"{\"subject\":\"HRMS Notification\",\"content\":\"Payment of ${{amount}} received. Invoice: {{invoice_number}}. Thank you!\"}\";s:30:\"template_due_date_reminder_sms\";s:130:\"{\"subject\":\"Due Date Reminder\",\"content\":\"Invoice {{invoice_number}} for ${{amount}} is due on {{due_date}}. Please pay on time.\"}\";s:36:\"template_subscription_activation_sms\";s:132:\"{\"subject\":\"Subscription Activated\",\"content\":\"Your {{plan_name}} subscription is now active. Expires: {{expiry_date}}. Thank you!\"}\";s:29:\"template_otp_verification_sms\";s:109:\"{\"subject\":\"HRMS Notification\",\"content\":\"Your OTP is {{otp}}. Please use this code to verify your account.\"}\";s:29:\"template_invoice_reminder_sms\";s:130:\"{\"subject\":\"HRMS Notification\",\"content\":\"Invoice {{invoice_number}} for ${{amount}} is due on {{due_date}}. Please pay on time.\"}\";s:26:\"template_owner_welcome_sms\";s:95:\"{\"content\":\"Welcome {name}! Your HRMS account has been created successfully. Welcome to HRMS!\"}\";s:8:\"test_key\";s:10:\"test_value\";s:18:\"system_welcome_sms\";s:1:\"1\";s:14:\"system_otp_sms\";s:1:\"1\";s:25:\"system_password_reset_sms\";s:1:\"1\";s:25:\"system_security_alert_sms\";s:1:\"1\";s:17:\"owner_welcome_sms\";s:1:\"1\";s:26:\"owner_package_purchase_sms\";s:1:\"1\";s:30:\"owner_payment_confirmation_sms\";s:1:\"1\";s:26:\"owner_invoice_reminder_sms\";s:1:\"1\";s:29:\"owner_subscription_expiry_sms\";s:1:\"1\";s:30:\"owner_subscription_renewal_sms\";s:1:\"1\";s:18:\"tenant_welcome_sms\";s:1:\"1\";s:24:\"tenant_rent_reminder_sms\";s:1:\"1\";s:31:\"tenant_payment_confirmation_sms\";s:1:\"1\";s:29:\"tenant_maintenance_update_sms\";s:1:\"1\";s:28:\"tenant_checkout_reminder_sms\";s:1:\"1\";s:23:\"tenant_lease_expiry_sms\";s:1:\"1\";s:39:\"template_owner_payment_confirmation_sms\";s:107:\"{\"content\":\"Dear {name}, payment of \\u09f3{amount} received. Invoice: {invoice_number}. Thank you! - HRMS\"}\";s:9:\"test_save\";s:10:\"test_value\";s:27:\"template_tenant_welcome_sms\";s:106:\"{\"content\":\"Welcome {tenant_name}! Your tenancy at {property_name} has been registered. Welcome to HRMS!\"}\";s:40:\"template_tenant_payment_confirmation_sms\";s:108:\"{\"content\":\"Dear {tenant_name}, rent payment of \\u09f3{amount} received. Property: {property_name}. - HRMS\"}\";s:22:\"template_test_ajax_sms\";s:31:\"{\"content\":\"Test AJAX content\"}\";s:19:\"template_test_debug\";s:62:\"{\"subject\":\"HRMS Notification\",\"content\":\"Test debug content\"}\";s:39:\"template_owner_invoice_notification_sms\";s:125:\"{\"content\":\"Dear {name}, new invoice generated. Amount: \\u09f3{amount}, Due: {due_date}. Invoice: {invoice_number} - HRMS,,\"}\";s:23:\"template_final_test_sms\";s:32:\"{\"content\":\"Final test content\"}\";s:17:\"template_test_now\";s:55:\"{\"subject\":\"HRMS Notification\",\"content\":\"Testing now\"}\";s:21:\"template_test_working\";s:64:\"{\"subject\":\"HRMS Notification\",\"content\":\"Test working content\"}\";s:22:\"template_test_complete\";s:62:\"{\"subject\":\"HRMS Notification\",\"content\":\"Test complete flow\"}\";s:12:\"company_name\";s:12:\"Bari Manager\";s:19:\"template_test_email\";s:94:\"{\"subject\":\"Test Email Subject\",\"content\":\"Test email content with variables name and amount\"}\";s:25:\"template_final_email_test\";s:80:\"{\"subject\":\"Final Email Test\",\"content\":\"This is a test email content for name\"}\";s:22:\"template_test_both_sms\";s:30:\"{\"content\":\"Test SMS content\"}\";s:24:\"template_test_both_email\";s:57:\"{\"subject\":\"Test Subject\",\"content\":\"Test email content\"}\";s:15:\"company_tagline\";s:26:\"Property Management System\";s:13:\"company_email\";s:13:\"info@hrms.com\";s:13:\"company_phone\";s:16:\"+880 1234-567890\";s:15:\"company_website\";s:23:\"https://barimanager.com\";s:15:\"company_address\";s:17:\"Dhaka, Bangladesh\";s:12:\"company_city\";s:5:\"Dhaka\";s:13:\"company_state\";s:5:\"Dhaka\";s:15:\"company_country\";s:10:\"Bangladesh\";s:19:\"company_postal_code\";s:4:\"1000\";s:16:\"company_facebook\";N;s:15:\"company_twitter\";N;s:16:\"company_linkedin\";N;s:17:\"company_instagram\";N;s:27:\"company_registration_number\";N;s:14:\"company_tax_id\";N;s:19:\"company_established\";s:4:\"2024\";s:19:\"company_description\";s:170:\"HRMS is a comprehensive property management system designed to help property owners and managers efficiently manage their properties, tenants, and financial transactions.\";s:21:\"company_support_email\";s:16:\"support@hrms.com\";s:21:\"company_support_phone\";s:16:\"+880 1234-567890\";s:21:\"company_working_hours\";s:34:\"Monday - Friday: 9:00 AM - 6:00 PM\";s:16:\"company_timezone\";s:10:\"Asia/Dhaka\";s:10:\"hero_title\";s:23:\"Welcome to Bari Manager\";s:13:\"hero_subtitle\";s:26:\"Property Management System\";s:16:\"hero_description\";s:122:\"Manage your properties, tenants, and financial transactions efficiently with our comprehensive property management system.\";s:16:\"hero_button_text\";s:11:\"Get Started\";s:15:\"hero_button_url\";s:38:\"https://barimanager.com/register/owner\";s:14:\"features_title\";s:23:\"Why Choose BariManager?\";s:17:\"features_subtitle\";s:89:\"Discover the features that make Bari Manager the perfect solution for property management\";s:14:\"feature1_title\";s:19:\"Property Management\";s:13:\"feature1_icon\";s:15:\"fas fa-building\";s:20:\"feature1_description\";s:76:\"Efficiently manage multiple properties with detailed tracking and reporting.\";s:14:\"feature2_title\";s:17:\"Tenant Management\";s:13:\"feature2_icon\";s:12:\"fas fa-users\";s:20:\"feature2_description\";s:74:\"Manage tenant information, rent collection, and communication efficiently.\";s:14:\"feature3_title\";s:18:\"Financial Tracking\";s:13:\"feature3_icon\";s:17:\"fas fa-chart-line\";s:20:\"feature3_description\";s:64:\"Track income, expenses, and generate detailed financial reports.\";s:11:\"about_title\";s:18:\"About Bari Manager\";s:14:\"about_subtitle\";s:40:\"Your Trusted Property Management Partner\";s:13:\"about_content\";s:307:\"Bari Manager is a comprehensive property management system designed to help property owners and managers efficiently manage their properties, tenants, and financial transactions. Our platform provides powerful tools for tracking rent payments, managing maintenance requests, and generating detailed reports.\";s:13:\"contact_title\";s:10:\"Contact Us\";s:19:\"contact_description\";s:111:\"Get in touch with us for any questions or support. We are here to help you with your property management needs.\";s:13:\"contact_email\";s:20:\"info@barimanager.com\";s:13:\"contact_phone\";s:16:\"+880 1234-567890\";s:15:\"contact_address\";s:17:\"Dhaka, Bangladesh\";s:16:\"footer_copyright\";s:42:\"© 2024 Bari Manager. All rights reserved.\";s:18:\"footer_description\";s:85:\"Bari Manager is your trusted partner for comprehensive property management solutions.\";s:15:\"system_currency\";s:3:\"BDT\";s:22:\"system_currency_symbol\";s:3:\"৳\";s:24:\"system_currency_position\";s:4:\"left\";s:21:\"system_decimal_places\";s:1:\"2\";s:25:\"system_thousand_separator\";s:1:\",\";s:15:\"system_timezone\";s:10:\"Asia/Dhaka\";s:18:\"system_date_format\";s:5:\"Y-m-d\";s:18:\"system_time_format\";s:3:\"H:i\";s:22:\"system_datetime_format\";s:9:\"Y-m-d H:i\";s:17:\"system_week_start\";s:6:\"sunday\";s:15:\"system_language\";s:2:\"en\";s:17:\"system_pagination\";s:2:\"20\";s:23:\"system_maintenance_mode\";s:1:\"0\";s:17:\"system_debug_mode\";s:1:\"0\";s:26:\"system_email_notifications\";s:1:\"1\";s:24:\"system_sms_notifications\";s:1:\"1\";s:25:\"system_push_notifications\";s:1:\"1\";s:25:\"system_notification_sound\";s:1:\"1\";}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}',1754250909);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charges`
--

DROP TABLE IF EXISTS `charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `charges` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charges`
--

LOCK TABLES `charges` WRITE;
/*!40000 ALTER TABLE `charges` DISABLE KEYS */;
INSERT INTO `charges` VALUES (1,'Gas Bill',500.00,NULL,NULL),(2,'Water Bill',300.00,NULL,NULL),(3,'Electricity Bill',1000.00,NULL,NULL),(4,'Service Charge',200.00,NULL,NULL),(5,'Security',150.00,NULL,NULL),(6,'Left Fees',150.00,NULL,NULL),(7,'Gas Bill',500.00,NULL,NULL),(8,'Water Bill',300.00,NULL,NULL),(9,'Electricity Bill',1000.00,NULL,NULL),(10,'Service Charge',200.00,NULL,NULL),(11,'Security',150.00,NULL,NULL),(12,'Left Fees',150.00,NULL,NULL),(13,'Gas Bill',500.00,NULL,NULL),(14,'Water Bill',300.00,NULL,NULL),(15,'Electricity Bill',1000.00,NULL,NULL),(16,'Service Charge',200.00,NULL,NULL),(17,'Security',150.00,NULL,NULL),(18,'Left Fees',150.00,NULL,NULL),(19,'Gas Bill',500.00,NULL,NULL),(20,'Water Bill',300.00,NULL,NULL),(21,'Electricity Bill',1000.00,NULL,NULL),(22,'Service Charge',200.00,NULL,NULL),(23,'Security',150.00,NULL,NULL),(24,'Left Fees',150.00,NULL,NULL),(25,'Gas Bill',500.00,NULL,NULL),(26,'Water Bill',300.00,NULL,NULL),(27,'Electricity Bill',1000.00,NULL,NULL),(28,'Service Charge',200.00,NULL,NULL),(29,'Security',150.00,NULL,NULL),(30,'Left Fees',150.00,NULL,NULL),(31,'Gas Bill',500.00,NULL,NULL),(32,'Water Bill',300.00,NULL,NULL),(33,'Electricity Bill',1000.00,NULL,NULL),(34,'Service Charge',200.00,NULL,NULL),(35,'Security',150.00,NULL,NULL),(36,'Left Fees',150.00,NULL,NULL);
/*!40000 ALTER TABLE `charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_messages`
--

DROP TABLE IF EXISTS `chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `session_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visitor_ip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visitor_user_agent` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message_type` enum('user','bot','agent') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `intent` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agent_id` bigint unsigned DEFAULT NULL,
  `status` enum('active','waiting','resolved','transferred') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chat_messages_session_id_index` (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_messages`
--

LOCK TABLES `chat_messages` WRITE;
/*!40000 ALTER TABLE `chat_messages` DISABLE KEYS */;
INSERT INTO `chat_messages` VALUES (1,'test_session_1754032520','127.0.0.1','Test Agent','user','Test message from landing page','test',3,'resolved',NULL,'2025-08-01 01:15:20','2025-08-01 01:52:19'),(2,'session_1754034647114_kdxzp092n','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','user','hello',NULL,NULL,'active',NULL,'2025-08-01 01:50:51','2025-08-01 01:50:51'),(3,'session_1754034647114_kdxzp092n','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','bot','Thank you for your message! Our team will get back to you soon. In the meantime, you can check our pricing plans or request a demo. How else can I help you?','general',NULL,'active',NULL,'2025-08-01 01:50:52','2025-08-01 01:50:52'),(4,'test_session_1754032520','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hi',NULL,3,'resolved',NULL,'2025-08-01 01:51:03','2025-08-01 01:52:19'),(5,'session_1754034647114_kdxzp092n','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','user','u',NULL,NULL,'active',NULL,'2025-08-01 01:51:28','2025-08-01 01:51:28'),(6,'session_1754034647114_kdxzp092n','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','bot','Thank you for your message! Our team will get back to you soon. In the meantime, you can check our pricing plans or request a demo. How else can I help you?','general',NULL,'active',NULL,'2025-08-01 01:51:29','2025-08-01 01:51:29'),(7,'test_session_1754032520','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hhh',NULL,3,'resolved',NULL,'2025-08-01 01:51:38','2025-08-01 01:52:19'),(8,'test_session_1754032520','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hhh',NULL,3,'resolved',NULL,'2025-08-01 01:51:38','2025-08-01 01:52:19'),(9,'test_session_1754032520','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hhh',NULL,3,'resolved',NULL,'2025-08-01 01:51:38','2025-08-01 01:52:19'),(10,'test_session_1754032520','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hhh',NULL,3,'resolved',NULL,'2025-08-01 01:51:38','2025-08-01 01:52:19'),(11,'test_session_1754032520','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hhh',NULL,3,'resolved',NULL,'2025-08-01 01:51:38','2025-08-01 01:52:19'),(12,'test_session_1754032520','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hhh',NULL,3,'resolved',NULL,'2025-08-01 01:51:38','2025-08-01 01:52:19'),(13,'session_1754034647114_kdxzp092n','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','user','hhh',NULL,NULL,'active',NULL,'2025-08-01 01:52:39','2025-08-01 01:52:39'),(14,'session_1754034647114_kdxzp092n','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','bot','Thank you for your message! Our team will get back to you soon. In the meantime, you can check our pricing plans or request a demo. How else can I help you?','general',NULL,'active',NULL,'2025-08-01 01:52:40','2025-08-01 01:52:40'),(15,'session_1754034806389_5dbeath04','103.98.76.254','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1','user','Hi',NULL,3,'active',NULL,'2025-08-01 01:53:32','2025-08-01 02:04:54'),(16,'session_1754034806389_5dbeath04','103.98.76.254','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1','bot','Thank you for your message! Our team will get back to you soon. In the meantime, you can check our pricing plans or request a demo. How else can I help you?','general',3,'active',NULL,'2025-08-01 01:53:33','2025-08-01 02:04:54'),(17,'session_1754034647114_kdxzp092n','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','user','I need help',NULL,NULL,'active',NULL,'2025-08-01 01:54:49','2025-08-01 01:54:49'),(18,'session_1754034647114_kdxzp092n','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','bot','For technical support, you can:\n\n📧 Email: support@barimanager.com\n📞 Phone: +880-1234-567890\n🕒 Hours: 9 AM - 6 PM (GMT+6)\n\nWhat specific issue are you facing?','support',NULL,'active',NULL,'2025-08-01 01:54:50','2025-08-01 01:54:50'),(19,'session_1754034806389_5dbeath04','103.98.76.254','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1','user','Agent',NULL,3,'active',NULL,'2025-08-01 01:55:21','2025-08-01 02:04:54'),(20,'session_1754034806389_5dbeath04','103.98.76.254','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1','bot','I\'m transferring you to a human agent. Please wait a moment...','agent_transfer',3,'active',NULL,'2025-08-01 01:55:21','2025-08-01 02:04:54'),(21,'session_1754034806389_5dbeath04','103.98.76.254','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1','bot','I\'m transferring you to a human agent. Please wait a moment...','agent_transfer',3,'active',NULL,'2025-08-01 01:55:21','2025-08-01 02:04:54'),(22,'session_1754034806389_5dbeath04','103.98.76.254','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1','bot','I\'m transferring you to a human agent. Please wait a moment...','agent_transfer',3,'active',NULL,'2025-08-01 01:55:22','2025-08-01 02:04:54'),(23,'session_1754034806389_5dbeath04',NULL,NULL,'agent','Hello! I\'m Super Admin, your dedicated support agent. How can I help you today?',NULL,3,'active',NULL,'2025-08-01 01:55:32','2025-08-01 02:04:54'),(24,'session_1754034806389_5dbeath04','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hi',NULL,3,'active',NULL,'2025-08-01 01:55:50','2025-08-01 02:04:54'),(25,'session_1754034806389_5dbeath04','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hi',NULL,3,'active',NULL,'2025-08-01 01:55:50','2025-08-01 02:04:54'),(26,'session_1754034806389_5dbeath04','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hi',NULL,3,'active',NULL,'2025-08-01 01:55:50','2025-08-01 02:04:54'),(27,'session_1754034806389_5dbeath04','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hi',NULL,3,'active',NULL,'2025-08-01 01:55:50','2025-08-01 02:04:54'),(28,'session_1754034806389_5dbeath04','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hi',NULL,3,'active',NULL,'2025-08-01 01:55:50','2025-08-01 02:04:54'),(29,'session_1754034806389_5dbeath04','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hi',NULL,3,'active',NULL,'2025-08-01 01:55:50','2025-08-01 02:04:54'),(30,'session_1754034806389_5dbeath04','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hi',NULL,3,'active',NULL,'2025-08-01 01:58:26','2025-08-01 02:04:54'),(31,'session_1754034806389_5dbeath04','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hi',NULL,3,'active',NULL,'2025-08-01 01:58:26','2025-08-01 02:04:54'),(32,'session_1754034806389_5dbeath04','103.98.76.254','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1','user','Yuh',NULL,3,'active',NULL,'2025-08-01 01:58:38','2025-08-01 02:04:54'),(33,'session_1754034806389_5dbeath04','103.98.76.254','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1','bot','Thank you for your message! Our team will get back to you soon. In the meantime, you can check our pricing plans or request a demo. How else can I help you?','general',3,'active',NULL,'2025-08-01 01:58:39','2025-08-01 02:04:54'),(34,'session_1754034806389_5dbeath04','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hi',NULL,3,'active',NULL,'2025-08-01 01:59:24','2025-08-01 02:04:54'),(35,'session_1754034806389_5dbeath04','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hi',NULL,3,'active',NULL,'2025-08-01 01:59:24','2025-08-01 02:04:54'),(36,'session_1754035437228_otftbfcs0','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','user','agent',NULL,NULL,'active',NULL,'2025-08-01 02:04:04','2025-08-01 02:04:04'),(37,'session_1754035437228_otftbfcs0','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','bot','Hello! 👋 I\'m your Bari Manager assistant. I can help you with pricing, features, demos, and support.\n\nWhat\'s your name?','greeting',NULL,'active',NULL,'2025-08-01 02:04:05','2025-08-01 02:04:05'),(38,'session_1754035437228_otftbfcs0','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','user','My name is...',NULL,NULL,'active',NULL,'2025-08-01 02:04:10','2025-08-01 02:04:10'),(39,'session_1754035437228_otftbfcs0','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','bot','Hello! 👋 I\'m your Bari Manager assistant. I can help you with pricing, features, demos, and support.\n\nWhat\'s your name?','greeting',NULL,'active',NULL,'2025-08-01 02:04:10','2025-08-01 02:04:10'),(40,'session_1754034806389_5dbeath04','103.98.76.254','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1','user','Hi',NULL,3,'active',NULL,'2025-08-01 02:04:46','2025-08-01 02:04:54'),(41,'session_1754034806389_5dbeath04','103.98.76.254','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1','bot','Thank you for your message! Our team will get back to you soon. In the meantime, you can check our pricing plans or request a demo. How else can I help you?','general',3,'active',NULL,'2025-08-01 02:04:46','2025-08-01 02:04:54'),(42,'session_1754034806389_5dbeath04','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hiu',NULL,3,'active',NULL,'2025-08-01 02:04:54','2025-08-01 02:04:54'),(43,'session_1754034806389_5dbeath04','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hiu',NULL,3,'active',NULL,'2025-08-01 02:04:54','2025-08-01 02:04:54'),(44,'session_1754034806389_5dbeath04','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','agent','hiu',NULL,3,'active',NULL,'2025-08-01 02:04:54','2025-08-01 02:04:54');
/*!40000 ALTER TABLE `chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkout_records`
--

DROP TABLE IF EXISTS `checkout_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkout_records` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned NOT NULL,
  `owner_id` bigint unsigned NOT NULL,
  `check_out_date` date NOT NULL,
  `security_deposit` decimal(10,2) NOT NULL DEFAULT '0.00',
  `deposit_returned` decimal(10,2) NOT NULL DEFAULT '0.00',
  `outstanding_dues` decimal(10,2) NOT NULL DEFAULT '0.00',
  `utility_bills` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cleaning_charges` decimal(10,2) NOT NULL DEFAULT '0.00',
  `other_charges` decimal(10,2) NOT NULL DEFAULT '0.00',
  `final_settlement_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `settlement_status` enum('pending','completed','partial') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `check_out_reason` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `handover_date` date DEFAULT NULL,
  `handover_condition` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `property_image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_reference` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `checkout_records_tenant_id_foreign` (`tenant_id`),
  KEY `checkout_records_unit_id_foreign` (`unit_id`),
  KEY `checkout_records_owner_id_foreign` (`owner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkout_records`
--

LOCK TABLES `checkout_records` WRITE;
/*!40000 ALTER TABLE `checkout_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `checkout_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_tickets`
--

DROP TABLE IF EXISTS `contact_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_tickets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','in_progress','resolved','closed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `admin_notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `ticket_number` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_response` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `responded_at` timestamp NULL DEFAULT NULL,
  `responded_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `contact_tickets_ticket_number_unique` (`ticket_number`),
  KEY `contact_tickets_responded_by_foreign` (`responded_by`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_tickets`
--

LOCK TABLES `contact_tickets` WRITE;
/*!40000 ALTER TABLE `contact_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` bigint unsigned NOT NULL,
  `invoice_number` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenant_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned NOT NULL,
  `type` enum('advance','rent') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'rent',
  `invoice_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rent_month` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `paid_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unpaid',
  `issue_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `paid_date` date DEFAULT NULL,
  `payment_method` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `breakdown` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoices_invoice_number_unique` (`invoice_number`),
  KEY `invoices_tenant_id_foreign` (`tenant_id`),
  KEY `invoices_unit_id_foreign` (`unit_id`),
  KEY `invoices_owner_id_foreign` (`owner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_logs`
--

DROP TABLE IF EXISTS `login_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'web',
  `platform` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser_version` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os_version` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_model` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `failure_reason` text COLLATE utf8mb4_unicode_ci,
  `login_method` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'email',
  `app_version` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_version` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_data` json DEFAULT NULL,
  `login_at` timestamp NOT NULL,
  `logout_at` timestamp NULL DEFAULT NULL,
  `session_duration` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `login_logs_user_id_login_at_index` (`user_id`,`login_at`),
  KEY `login_logs_ip_address_login_at_index` (`ip_address`,`login_at`),
  KEY `login_logs_status_login_at_index` (`status`,`login_at`),
  KEY `login_logs_device_type_login_at_index` (`device_type`,`login_at`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_logs`
--

LOCK TABLES `login_logs` WRITE;
/*!40000 ALTER TABLE `login_logs` DISABLE KEYS */;
INSERT INTO `login_logs` VALUES (1,1,'test@example.com','127.0.0.1',NULL,'web','desktop','Chrome',NULL,'Windows',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'success',NULL,'email',NULL,NULL,NULL,'2025-08-03 12:03:58',NULL,NULL,'2025-08-03 12:03:58','2025-08-03 12:03:58',NULL),(2,NULL,'test@example.com','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36','web','desktop','Unknown',NULL,'Windows',NULL,NULL,'Local Development','Local','Development','Local','UTC','success',NULL,'email',NULL,NULL,'{\"request_data\": {\"email\": \"test@example.com\"}}','2025-08-03 12:21:06',NULL,NULL,'2025-08-03 12:21:06','2025-08-03 12:21:06',NULL),(3,NULL,'test@example.com','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36','web','desktop','Unknown',NULL,'Windows',NULL,NULL,'Local Development','Local','Development','Local','UTC','failed','Test failure reason','email',NULL,NULL,'{\"request_data\": {\"email\": \"test@example.com\"}}','2025-08-03 12:21:06',NULL,NULL,'2025-08-03 12:21:06','2025-08-03 12:21:06',NULL),(4,3,'admin@hrms.com','103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','web','desktop','Chrome',NULL,'Windows',NULL,NULL,'Unknown',NULL,NULL,NULL,'UTC','success',NULL,'email',NULL,NULL,'{\"Accept\": \"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8\", \"request_data\": {\"email\": \"admin@hrms.com\"}, \"Accept-Encoding\": \"gzip, br\", \"Accept-Language\": \"en-US,en;q=0.6\"}','2025-08-03 18:21:30',NULL,NULL,'2025-08-03 18:21:30','2025-08-03 18:21:30',NULL),(5,3,'admin@hrms.com','43.231.20.203','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','mobile','desktop','Chrome',NULL,'Linux',NULL,'Android Device','Unknown',NULL,NULL,NULL,'UTC','success',NULL,'email',NULL,NULL,'{\"Accept\": \"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7\", \"request_data\": {\"email\": \"admin@hrms.com\"}, \"Accept-Encoding\": \"gzip, br\", \"Accept-Language\": \"en-GB,en;q=0.9,bn-BD;q=0.8,bn;q=0.7,en-US;q=0.6\"}','2025-08-03 18:23:33',NULL,NULL,'2025-08-03 18:23:33','2025-08-03 18:23:33',NULL);
/*!40000 ALTER TABLE `login_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2025_07_12_183805_create_owners_table',1),(5,'2025_07_12_184426_add_password_to_owners_table',1),(6,'2025_07_13_063008_add_password_to_owners_table_new',1),(7,'2025_07_13_110606_create_permission_tables',1),(8,'2025_07_13_122823_add_user_id_to_owners_table',1),(9,'2025_07_14_153909_create_properties_table',1),(10,'2025_07_14_154202_create_units_table',1),(11,'2025_07_14_154305_create_unit_charges_table',1),(12,'2025_07_15_073044_create_system_settings_table',1),(13,'2025_07_15_103856_create_tenants_table',1),(14,'2025_07_15_161242_create_tenant_rents_table',1),(15,'2025_07_16_000000_create_rent_payments_table',1),(16,'2025_07_16_000000_create_temp_data_table',1),(17,'2025_07_17_151201_make_unit_id_nullable_in_tenants_table',1),(18,'2025_07_17_161221_add_owner_id_to_tenants_table',1),(19,'2025_07_19_000000_add_owner_id_to_tenant_rents_table',1),(20,'2025_07_19_010000_add_status_and_tenant_id_to_units_table',1),(21,'2025_07_19_031427_add_checkout_fields_to_tenants_table',1),(22,'2025_07_19_042604_create_checkout_records_table',1),(23,'2025_07_19_044018_update_units_status_enum',1),(24,'2025_07_19_044545_create_tenant_ledgers_table',1),(25,'2025_07_19_082445_create_personal_access_tokens_table',1),(26,'2025_07_20_000000_create_invoices_table',1),(27,'2025_07_20_010000_add_owner_id_and_rent_month_to_invoices_table',1),(28,'2025_07_20_062014_add_unique_phone_to_owners_table',1),(29,'2025_07_20_062132_create_otps_table',1),(30,'2025_07_20_074922_add_phone_to_users_table',1),(31,'2025_07_20_110610_add_gender_and_profile_pic_to_owners_table',1),(32,'2025_07_20_115345_alter_type_length_in_otps_table',1),(33,'2025_07_20_120855_add_otp_send_limit_to_system_settings_table',1),(34,'2025_07_20_152450_add_phone_verified_to_owners_table',1),(35,'2025_07_20_170215_add_soft_deletes_to_properties_owners_units_tenants_tables',1),(36,'2025_07_20_181635_create_charges_table',1),(37,'2025_07_21_000000_add_building_id_to_tenants_table',1),(38,'2025_07_21_173424_add_missing_fields_to_tenants_table',1),(39,'2025_07_21_174457_add_missing_fields_to_invoices_table',1),(40,'2025_07_21_175353_update_units_status_enum_values',1),(41,'2025_07_21_180122_add_unique_constraints_to_tenants_table',1),(42,'2025_07_21_195917_add_paid_amount_to_invoices_table',1),(43,'2025_07_21_200259_add_invoice_id_to_rent_payments_table',1),(44,'2025_07_21_200801_add_amount_to_rent_payments_table',1),(45,'2025_07_22_052541_create_otp_settings_table',2),(46,'2025_07_22_054312_add_super_admin_fields_to_owners_table',3),(47,'2025_07_22_create_tenant_otps_table',4),(48,'2025_07_22_add_tenant_owner_to_users_table',5),(49,'2025_07_24_193630_update_unit_status_enum_values',6),(50,'2025_01_27_000000_add_nid_front_back_pictures_to_tenants_table',7),(51,'2025_07_26_052021_make_last_name_nullable_in_tenants_table',7),(52,'2025_07_26_101420_make_cleaning_charges_nullable_in_tenants_table',8),(53,'2025_01_28_000000_add_property_image_to_checkout_records_table',9),(55,'2025_07_26_183708_add_payment_fields_to_checkout_records_table',10),(56,'2025_07_27_051801_add_invoice_payment_to_tenant_ledgers_table',11),(57,'2025_07_27_055013_add_missing_transaction_types_to_tenant_ledgers_table',12),(67,'2024_01_01_000000_create_subscription_plans_table',13),(68,'2024_01_01_000001_create_owner_subscriptions_table',13),(69,'2024_01_01_000002_create_billing_table',13),(70,'2025_07_27_181743_add_email_mobile_to_properties_table',13),(71,'2025_07_28_173300_add_expired_status_to_owner_subscriptions_table',13),(72,'2025_07_28_173926_create_payment_methods_table',14),(73,'2025_07_28_173946_add_payment_method_id_to_billing_table',14),(75,'2025_01_29_000000_update_bkash_payment_method_settings',15),(76,'2025_07_29_114622_create_notification_logs_table',16),(77,'2025_07_29_114932_create_settings_table',17),(78,'2025_07_29_120000_create_package_limits_table',18),(79,'2025_07_29_180050_add_features_to_properties_table',19),(80,'2025_07_30_131455_create_contact_tickets_table',20),(81,'2025_07_30_154635_add_admin_notes_to_contact_tickets_table',21),(82,'2025_07_30_154637_add_admin_notes_to_contact_tickets_table',21),(83,'2025_07_30_161041_update_contact_tickets_status_enum',22),(84,'2025_07_30_171456_add_sms_credit_to_subscription_plans_table',23),(85,'2025_07_30_180950_add_unavailable_features_to_subscription_plans_table',24),(86,'2025_07_30_181120_add_features_css_to_subscription_plans_table',24),(87,'2025_07_31_174318_add_pending_upgrade_to_owner_subscriptions_status_enum',25),(88,'2025_07_31_180821_update_billing_status_enum_values',26),(89,'2025_07_31_183301_add_verification_details_to_billing_table',27),(90,'2025_08_01_063250_modify_system_settings_value_column_allow_null',28),(91,'2025_08_01_063502_modify_system_settings_value_column_to_text',29),(92,'2025_08_01_064956_create_chat_messages_table',30),(93,'2025_08_01_164013_add_owner_and_source_to_notification_logs_table',31),(94,'2025_08_02_090000_add_billing_cycle_to_subscription_plans_table',32),(95,'2025_08_03_174911_create_login_logs_table',33),(96,'2025_08_03_180015_add_deleted_at_to_login_logs_table',34),(97,'2025_08_02_074850_create_sms_logs_table',35),(99,'2025_08_02_085501_add_billing_cycle_to_subscription_plans_table',36),(100,'2025_08_03_183108_create_backups_table',37);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',3),(2,'App\\Models\\User',37),(2,'App\\Models\\User',46),(2,'App\\Models\\User',51),(2,'App\\Models\\User',55),(2,'App\\Models\\User',62);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_logs`
--

DROP TABLE IF EXISTS `notification_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `type` enum('email','sms') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'email',
  `recipient` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('sent','failed','pending') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `owner_id` bigint unsigned DEFAULT NULL,
  `template_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source` enum('owner','tenant','system') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'system',
  PRIMARY KEY (`id`),
  KEY `notification_logs_user_id_foreign` (`user_id`),
  KEY `notification_logs_type_status_index` (`type`,`status`),
  KEY `notification_logs_created_at_index` (`created_at`),
  KEY `notification_logs_owner_id_type_created_at_index` (`owner_id`,`type`,`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=158 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_logs`
--

LOCK TABLES `notification_logs` WRITE;
/*!40000 ALTER TABLE `notification_logs` DISABLE KEYS */;
INSERT INTO `notification_logs` VALUES (2,3,'email','noreply@barimanager.com','This is a test email from HRMS notification system.','failed',NULL,'2025-08-01 11:42:57','2025-08-01 11:42:57',NULL,NULL,'system'),(3,3,'email','noreply@barimanager.com','This is a test email from HRMS notification system.','failed',NULL,'2025-08-01 11:52:28','2025-08-01 11:52:28',NULL,NULL,'system'),(4,3,'email','noreply@barimanager.com','This is a test email from HRMS notification system.','sent','2025-08-01 11:58:39','2025-08-01 11:58:39','2025-08-01 11:58:39',NULL,NULL,'system'),(5,3,'email','samiul42@gmail.com','This is a test email from HRMS notification system.','sent','2025-08-01 12:07:50','2025-08-01 12:07:50','2025-08-01 12:07:50',NULL,NULL,'system'),(6,3,'email','samiul42@gmail.com','This is a test email from HRMS notification system.','sent','2025-08-01 12:15:03','2025-08-01 12:15:03','2025-08-01 12:15:03',NULL,NULL,'system'),(7,3,'email','samiul42@gmail.com','This is a test email from HRMS notification system.','sent','2025-08-01 12:54:40','2025-08-01 12:54:40','2025-08-01 12:54:40',NULL,NULL,'system'),(8,3,'email','samiul42@gmail.com','This is a test email from HRMS notification system.','sent','2025-08-01 12:58:53','2025-08-01 12:58:53','2025-08-01 12:58:53',NULL,NULL,'system'),(9,3,'email','samiul42@gmail.com','This is a test email from HRMS notification system.','sent','2025-08-01 12:59:06','2025-08-01 12:59:06','2025-08-01 12:59:06',NULL,NULL,'system'),(10,3,'email','samiul42@gmail.com','This is a test email from HRMS notification system.','sent','2025-08-01 12:59:41','2025-08-01 12:59:41','2025-08-01 12:59:41',NULL,NULL,'system'),(11,3,'email','samiul42@gmail.com','This is a test email from HRMS notification system.','sent','2025-08-01 13:00:42','2025-08-01 13:00:42','2025-08-01 13:00:42',NULL,NULL,'system'),(12,3,'email','samiul42@gmail.com','This is a test email from HRMS notification system.','sent','2025-08-01 13:05:43','2025-08-01 13:05:43','2025-08-01 13:05:43',NULL,NULL,'system'),(13,3,'email','samiul42@gmail.com','This is a test email from HRMS notification system.','sent','2025-08-01 13:06:00','2025-08-01 13:06:00','2025-08-01 13:06:00',NULL,NULL,'system'),(14,3,'email','noreply@barimanager.com','This is a test email from HRMS notification system.','sent','2025-08-01 14:00:40','2025-08-01 14:00:40','2025-08-01 14:00:40',NULL,NULL,'system'),(15,3,'email','samiul42@gmail.com','This is a test email from HRMS notification system.','sent','2025-08-01 14:00:55','2025-08-01 14:00:55','2025-08-01 14:00:55',NULL,NULL,'system'),(16,1,'email','samiul42@gmail.com','This is a test email to verify the notification system is working.','sent','2025-08-01 23:52:23','2025-08-01 23:52:23','2025-08-01 23:52:23',NULL,NULL,'system'),(17,1,'email','samiul42@gmail.com','Dear {Md Samiul Alam},\n\nWelcome to HRMS! Your account has been successfully created.\n\nYour login details:\nEmail: {samiul42@gmail.com}\n\nWe are excited to have you on board. If you have any questions, please don\'t hesitate to contact our support team.\n\nBest regards,\nThe HRMS Team','sent','2025-08-01 23:52:23','2025-08-01 23:52:23','2025-08-01 23:52:23',NULL,NULL,'system'),(18,1,'email','samiul42@gmail.com','Dear {Md Samiul Alam},\n\nWelcome to HRMS! Your account has been successfully created.\n\nYour login details:\nEmail: {samiul42@gmail.com}\n\nWe are excited to have you on board. If you have any questions, please don\'t hesitate to contact our support team.\n\nBest regards,\nThe HRMS Team','sent','2025-08-01 23:52:23','2025-08-01 23:52:23','2025-08-01 23:52:23',NULL,NULL,'system'),(19,1,'email','samiul42@gmail.com','Dear {Md Samiul Alam},\n\nThank you for joining HRMS! Here\'s your quick setup guide:\n\n1. Complete your profile\n2. Add your properties\n3. Invite tenants\n4. Set up billing\n\nFor detailed instructions, visit our help center.\n\nBest regards,\nThe HRMS Team','sent','2025-08-01 23:52:23','2025-08-01 23:52:23','2025-08-01 23:52:23',NULL,NULL,'system'),(20,1,'email','samiul42@gmail.com','Dear {Md Samiul Alam},\n\nHere are the key features available in your HRMS account:\n\n• Property Management\n• Tenant Management\n• Rent Collection\n• Financial Reports\n• SMS Notifications\n• Document Management\n\nExplore these features to maximize your property management efficiency.\n\nBest regards,\nThe HRMS Team','sent','2025-08-01 23:52:23','2025-08-01 23:52:23','2025-08-01 23:52:23',NULL,NULL,'system'),(21,1,'email','samiul42@gmail.com','Dear {Md Samiul Alam},\n\nYour subscription details:\n\nPlan: {Free}\nPrice: ${0.00}\nExpiry Date: {2026-08-02 00:00:00}\nSMS Credits: {0}\n\nThank you for choosing HRMS!\n\nBest regards,\nThe HRMS Team','sent','2025-08-01 23:52:23','2025-08-01 23:52:23','2025-08-01 23:52:23',NULL,NULL,'system'),(22,1,'email','samiul42@gmail.com','Dear {Md Samiul Alam},\n\nWelcome to HRMS! Your account has been successfully created.\n\nYour login details:\nEmail: {samiul42@gmail.com}\n\nWe are excited to have you on board. If you have any questions, please don\'t hesitate to contact our support team.\n\nBest regards,\nThe HRMS Team','sent','2025-08-02 00:08:35','2025-08-02 00:08:35','2025-08-02 00:08:35',NULL,NULL,'system'),(23,1,'email','samiul42@gmail.com','Dear {Md Samiul Alam},\n\nThank you for joining HRMS! Here\'s your quick setup guide:\n\n1. Complete your profile\n2. Add your properties\n3. Invite tenants\n4. Set up billing\n\nFor detailed instructions, visit our help center.\n\nBest regards,\nThe HRMS Team','sent','2025-08-02 00:08:35','2025-08-02 00:08:35','2025-08-02 00:08:35',NULL,NULL,'system'),(24,1,'email','samiul42@gmail.com','Dear {Md Samiul Alam},\n\nHere are the key features available in your HRMS account:\n\n• Property Management\n• Tenant Management\n• Rent Collection\n• Financial Reports\n• SMS Notifications\n• Document Management\n\nExplore these features to maximize your property management efficiency.\n\nBest regards,\nThe HRMS Team','sent','2025-08-02 00:08:35','2025-08-02 00:08:35','2025-08-02 00:08:35',NULL,NULL,'system'),(25,1,'email','testsms3@example.com','Dear {Test Owner SMS},\n\nWelcome to HRMS! Your account has been successfully created.\n\nYour login details:\nEmail: {testsms3@example.com}\n\nWe are excited to have you on board. If you have any questions, please don\'t hesitate to contact our support team.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 01:57:01','2025-08-02 01:57:01',NULL,NULL,'system'),(26,1,'email','testsms3@example.com','Dear {Test Owner SMS},\n\nThank you for joining HRMS! Here\'s your quick setup guide:\n\n1. Complete your profile\n2. Add your properties\n3. Invite tenants\n4. Set up billing\n\nFor detailed instructions, visit our help center.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 01:57:01','2025-08-02 01:57:01',NULL,NULL,'system'),(27,1,'email','testsms3@example.com','Dear {Test Owner SMS},\n\nHere are the key features available in your HRMS account:\n\n• Property Management\n• Tenant Management\n• Rent Collection\n• Financial Reports\n• SMS Notifications\n• Document Management\n\nExplore these features to maximize your property management efficiency.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 01:57:01','2025-08-02 01:57:01',NULL,NULL,'system'),(28,27,'email','samiul42@gmail.com','Dear {Md Samiul},\n\nWelcome to HRMS! Your account has been successfully created.\n\nYour login details:\nEmail: {samiul42@gmail.com}\n\nWe are excited to have you on board. If you have any questions, please don\'t hesitate to contact our support team.\n\nBest regards,\nThe HRMS Team','sent','2025-08-02 01:58:36','2025-08-02 01:58:36','2025-08-02 01:58:36',NULL,NULL,'system'),(29,27,'email','samiul42@gmail.com','Dear {Md Samiul},\n\nThank you for joining HRMS! Here\'s your quick setup guide:\n\n1. Complete your profile\n2. Add your properties\n3. Invite tenants\n4. Set up billing\n\nFor detailed instructions, visit our help center.\n\nBest regards,\nThe HRMS Team','sent','2025-08-02 01:58:36','2025-08-02 01:58:36','2025-08-02 01:58:36',NULL,NULL,'system'),(30,27,'email','samiul42@gmail.com','Dear {Md Samiul},\n\nHere are the key features available in your HRMS account:\n\n• Property Management\n• Tenant Management\n• Rent Collection\n• Financial Reports\n• SMS Notifications\n• Document Management\n\nExplore these features to maximize your property management efficiency.\n\nBest regards,\nThe HRMS Team','sent','2025-08-02 01:58:36','2025-08-02 01:58:36','2025-08-02 01:58:36',NULL,NULL,'system'),(31,1,'email','testsms@example.com','Dear {Test Owner SMS},\n\nWelcome to HRMS! Your account has been successfully created.\n\nYour login details:\nEmail: {testsms@example.com}\n\nWe are excited to have you on board. If you have any questions, please don\'t hesitate to contact our support team.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:02:54','2025-08-02 02:02:54',NULL,NULL,'system'),(32,1,'email','testsms@example.com','Dear {Test Owner SMS},\n\nThank you for joining HRMS! Here\'s your quick setup guide:\n\n1. Complete your profile\n2. Add your properties\n3. Invite tenants\n4. Set up billing\n\nFor detailed instructions, visit our help center.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:02:54','2025-08-02 02:02:54',NULL,NULL,'system'),(33,1,'email','testsms@example.com','Dear {Test Owner SMS},\n\nHere are the key features available in your HRMS account:\n\n• Property Management\n• Tenant Management\n• Rent Collection\n• Financial Reports\n• SMS Notifications\n• Document Management\n\nExplore these features to maximize your property management efficiency.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:02:54','2025-08-02 02:02:54',NULL,NULL,'system'),(34,1,'email','testsms@example.com','Dear {Test Owner SMS},\n\nYour subscription details:\n\nPlan: {Free}\nPrice: ${0.00}\nExpiry Date: {2025-09-01 00:00:00}\nSMS Credits: {100}\n\nThank you for choosing HRMS!\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:02:54','2025-08-02 02:02:54',NULL,NULL,'system'),(35,1,'email','testsms@example.com','Dear {Test Owner SMS},\n\nWelcome to HRMS! Your account has been successfully created.\n\nYour login details:\nEmail: {testsms@example.com}\n\nWe are excited to have you on board. If you have any questions, please don\'t hesitate to contact our support team.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:04:21','2025-08-02 02:04:21',NULL,NULL,'system'),(36,1,'email','testsms@example.com','Dear {Test Owner SMS},\n\nThank you for joining HRMS! Here\'s your quick setup guide:\n\n1. Complete your profile\n2. Add your properties\n3. Invite tenants\n4. Set up billing\n\nFor detailed instructions, visit our help center.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:04:21','2025-08-02 02:04:21',NULL,NULL,'system'),(37,1,'email','testsms@example.com','Dear {Test Owner SMS},\n\nHere are the key features available in your HRMS account:\n\n• Property Management\n• Tenant Management\n• Rent Collection\n• Financial Reports\n• SMS Notifications\n• Document Management\n\nExplore these features to maximize your property management efficiency.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:04:21','2025-08-02 02:04:21',NULL,NULL,'system'),(38,1,'email','testsms@example.com','Dear {Test Owner SMS},\n\nYour subscription details:\n\nPlan: {Free}\nPrice: ${0.00}\nExpiry Date: {2025-09-01 00:00:00}\nSMS Credits: {100}\n\nThank you for choosing HRMS!\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:04:21','2025-08-02 02:04:21',NULL,NULL,'system'),(39,1,'sms','8801700000002','Welcome {Test Owner SMS} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','failed',NULL,'2025-08-02 02:04:31','2025-08-02 02:04:31',NULL,NULL,'system'),(40,1,'email','samiul42@gmail.com','Dear {sam},\n\nWelcome to HRMS! Your account has been successfully created.\n\nYour login details:\nEmail: {samiul42@gmail.com}\n\nWe are excited to have you on board. If you have any questions, please don\'t hesitate to contact our support team.\n\nBest regards,\nThe HRMS Team','sent','2025-08-02 02:11:10','2025-08-02 02:11:10','2025-08-02 02:11:10',NULL,NULL,'system'),(41,1,'email','samiul42@gmail.com','Dear {sam},\n\nThank you for joining HRMS! Here\'s your quick setup guide:\n\n1. Complete your profile\n2. Add your properties\n3. Invite tenants\n4. Set up billing\n\nFor detailed instructions, visit our help center.\n\nBest regards,\nThe HRMS Team','sent','2025-08-02 02:11:10','2025-08-02 02:11:10','2025-08-02 02:11:10',NULL,NULL,'system'),(42,1,'email','samiul42@gmail.com','Dear {sam},\n\nHere are the key features available in your HRMS account:\n\n• Property Management\n• Tenant Management\n• Rent Collection\n• Financial Reports\n• SMS Notifications\n• Document Management\n\nExplore these features to maximize your property management efficiency.\n\nBest regards,\nThe HRMS Team','sent','2025-08-02 02:11:10','2025-08-02 02:11:10','2025-08-02 02:11:10',NULL,NULL,'system'),(43,1,'email','testowner@example.com','Dear {Test Owner},\n\nWelcome to HRMS! Your account has been successfully created.\n\nYour login details:\nEmail: {testowner@example.com}\n\nWe are excited to have you on board. If you have any questions, please don\'t hesitate to contact our support team.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:15:34','2025-08-02 02:15:34',NULL,NULL,'system'),(44,1,'email','testowner@example.com','Dear {Test Owner},\n\nThank you for joining HRMS! Here\'s your quick setup guide:\n\n1. Complete your profile\n2. Add your properties\n3. Invite tenants\n4. Set up billing\n\nFor detailed instructions, visit our help center.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:15:34','2025-08-02 02:15:34',NULL,NULL,'system'),(45,1,'email','testowner@example.com','Dear {Test Owner},\n\nHere are the key features available in your HRMS account:\n\n• Property Management\n• Tenant Management\n• Rent Collection\n• Financial Reports\n• SMS Notifications\n• Document Management\n\nExplore these features to maximize your property management efficiency.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:15:34','2025-08-02 02:15:34',NULL,NULL,'system'),(46,1,'email','testowner@example.com','Dear {Test Owner},\n\nYour subscription details:\n\nPlan: {Free}\nPrice: ${0.00}\nExpiry Date: {2025-09-01 00:00:00}\nSMS Credits: {100}\n\nThank you for choosing HRMS!\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:15:34','2025-08-02 02:15:34',NULL,NULL,'system'),(47,1,'sms','8801700000000','Welcome {Test Owner} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','failed',NULL,'2025-08-02 02:15:44','2025-08-02 02:15:44',NULL,NULL,'system'),(48,1,'email','testowner@example.com','Dear {Test Owner},\n\nWelcome to HRMS! Your account has been successfully created.\n\nYour login details:\nEmail: {testowner@example.com}\n\nWe are excited to have you on board. If you have any questions, please don\'t hesitate to contact our support team.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:42:40','2025-08-02 02:42:40',NULL,NULL,'system'),(49,1,'email','testowner@example.com','Dear {Test Owner},\n\nThank you for joining HRMS! Here\'s your quick setup guide:\n\n1. Complete your profile\n2. Add your properties\n3. Invite tenants\n4. Set up billing\n\nFor detailed instructions, visit our help center.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:42:40','2025-08-02 02:42:40',NULL,NULL,'system'),(50,1,'email','testowner@example.com','Dear {Test Owner},\n\nHere are the key features available in your HRMS account:\n\n• Property Management\n• Tenant Management\n• Rent Collection\n• Financial Reports\n• SMS Notifications\n• Document Management\n\nExplore these features to maximize your property management efficiency.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:42:40','2025-08-02 02:42:40',NULL,NULL,'system'),(51,1,'email','testowner@example.com','Dear {Test Owner},\n\nYour subscription details:\n\nPlan: {Free}\nPrice: ${0.00}\nExpiry Date: {2025-09-01 00:00:00}\nSMS Credits: {100}\n\nThank you for choosing HRMS!\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:42:40','2025-08-02 02:42:40',NULL,NULL,'system'),(52,1,'sms','8801700000000','Welcome {Test Owner} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','failed',NULL,'2025-08-02 02:42:50','2025-08-02 02:42:50',NULL,NULL,'system'),(53,1,'email','testowner@example.com','Dear {Test Owner},\n\nWelcome to HRMS! Your account has been successfully created.\n\nYour login details:\nEmail: {testowner@example.com}\n\nWe are excited to have you on board. If you have any questions, please don\'t hesitate to contact our support team.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:44:46','2025-08-02 02:44:46',NULL,NULL,'system'),(54,1,'email','testowner@example.com','Dear {Test Owner},\n\nThank you for joining HRMS! Here\'s your quick setup guide:\n\n1. Complete your profile\n2. Add your properties\n3. Invite tenants\n4. Set up billing\n\nFor detailed instructions, visit our help center.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:44:46','2025-08-02 02:44:46',NULL,NULL,'system'),(55,1,'email','testowner@example.com','Dear {Test Owner},\n\nHere are the key features available in your HRMS account:\n\n• Property Management\n• Tenant Management\n• Rent Collection\n• Financial Reports\n• SMS Notifications\n• Document Management\n\nExplore these features to maximize your property management efficiency.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:44:46','2025-08-02 02:44:46',NULL,NULL,'system'),(56,1,'email','testowner@example.com','Dear {Test Owner},\n\nYour subscription details:\n\nPlan: {Free}\nPrice: ${0.00}\nExpiry Date: {2025-09-01 00:00:00}\nSMS Credits: {100}\n\nThank you for choosing HRMS!\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 02:44:46','2025-08-02 02:44:46',NULL,NULL,'system'),(57,1,'sms','8801700000000','Welcome {Test Owner} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','failed',NULL,'2025-08-02 02:44:56','2025-08-02 02:44:56',NULL,NULL,'system'),(58,32,'email','samiul42@gmail.com','Dear {samiul},\n\nWelcome to HRMS! Your account has been successfully created.\n\nYour login details:\nEmail: {samiul42@gmail.com}\n\nWe are excited to have you on board. If you have any questions, please don\'t hesitate to contact our support team.\n\nBest regards,\nThe HRMS Team','sent','2025-08-02 03:23:13','2025-08-02 03:23:13','2025-08-02 03:23:13',NULL,NULL,'system'),(59,32,'email','samiul42@gmail.com','Dear {samiul},\n\nThank you for joining HRMS! Here\'s your quick setup guide:\n\n1. Complete your profile\n2. Add your properties\n3. Invite tenants\n4. Set up billing\n\nFor detailed instructions, visit our help center.\n\nBest regards,\nThe HRMS Team','sent','2025-08-02 03:23:13','2025-08-02 03:23:13','2025-08-02 03:23:13',NULL,NULL,'system'),(60,32,'email','samiul42@gmail.com','Dear {samiul},\n\nHere are the key features available in your HRMS account:\n\n• Property Management\n• Tenant Management\n• Rent Collection\n• Financial Reports\n• SMS Notifications\n• Document Management\n\nExplore these features to maximize your property management efficiency.\n\nBest regards,\nThe HRMS Team','sent','2025-08-02 03:23:13','2025-08-02 03:23:13','2025-08-02 03:23:13',NULL,NULL,'system'),(61,1,'email','testowner_sms@example.com','Dear {Test Owner SMS},\n\nWelcome to HRMS! Your account has been successfully created.\n\nYour login details:\nEmail: {testowner_sms@example.com}\n\nWe are excited to have you on board. If you have any questions, please don\'t hesitate to contact our support team.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 03:33:53','2025-08-02 03:33:53',NULL,NULL,'system'),(62,1,'email','testowner_sms@example.com','Dear {Test Owner SMS},\n\nThank you for joining HRMS! Here\'s your quick setup guide:\n\n1. Complete your profile\n2. Add your properties\n3. Invite tenants\n4. Set up billing\n\nFor detailed instructions, visit our help center.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 03:33:53','2025-08-02 03:33:53',NULL,NULL,'system'),(63,1,'email','testowner_sms@example.com','Dear {Test Owner SMS},\n\nHere are the key features available in your HRMS account:\n\n• Property Management\n• Tenant Management\n• Rent Collection\n• Financial Reports\n• SMS Notifications\n• Document Management\n\nExplore these features to maximize your property management efficiency.\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 03:33:53','2025-08-02 03:33:53',NULL,NULL,'system'),(64,1,'email','testowner_sms@example.com','Dear {Test Owner SMS},\n\nYour subscription details:\n\nPlan: {Free Plan}\nPrice: ${0.00}\nExpiry Date: {2025-09-01 00:00:00}\nSMS Credits: {100}\n\nThank you for choosing HRMS!\n\nBest regards,\nThe HRMS Team','failed',NULL,'2025-08-02 03:33:53','2025-08-02 03:33:53',NULL,NULL,'system'),(65,1,'sms','8801700000005','Welcome {Test Owner SMS} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','failed',NULL,'2025-08-02 03:34:03','2025-08-02 03:34:03',NULL,NULL,'system'),(66,1,'email','sabbirah7016@gmail.com','Dear {Md sabbir Ahmed},\n\nWelcome to HRMS! Your account has been successfully created.\n\nYour login details:\nEmail: {sabbirah7016@gmail.com}\n\nWe are excited to have you on board. If you have any questions, please don\'t hesitate to contact our support team.\n\nBest regards,\nThe HRMS Team','sent','2025-08-02 03:41:03','2025-08-02 03:41:03','2025-08-02 03:41:03',NULL,NULL,'system'),(67,1,'email','sabbirah7016@gmail.com','Dear {Md sabbir Ahmed},\n\nThank you for joining HRMS! Here\'s your quick setup guide:\n\n1. Complete your profile\n2. Add your properties\n3. Invite tenants\n4. Set up billing\n\nFor detailed instructions, visit our help center.\n\nBest regards,\nThe HRMS Team','sent','2025-08-02 03:41:03','2025-08-02 03:41:03','2025-08-02 03:41:03',NULL,NULL,'system'),(68,1,'email','sabbirah7016@gmail.com','Dear {Md sabbir Ahmed},\n\nHere are the key features available in your HRMS account:\n\n• Property Management\n• Tenant Management\n• Rent Collection\n• Financial Reports\n• SMS Notifications\n• Document Management\n\nExplore these features to maximize your property management efficiency.\n\nBest regards,\nThe HRMS Team','sent','2025-08-02 03:41:03','2025-08-02 03:41:03','2025-08-02 03:41:03',NULL,NULL,'system'),(69,1,'email','sabbirah7016@gmail.com','<h2>Welcome {Md sabbir Ahmed}!</h2><p>Your account has been successfully created.</p>','sent','2025-08-02 05:57:37','2025-08-02 05:57:37','2025-08-02 05:57:37',NULL,NULL,'system'),(70,1,'email','sabbirah7016@gmail.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','sent','2025-08-02 05:57:37','2025-08-02 05:57:37','2025-08-02 05:57:37',NULL,NULL,'system'),(71,1,'email','sabbirah7016@gmail.com','<h2>Features Overview</h2><p>Discover all the features available in HRMS...</p>','sent','2025-08-02 05:57:37','2025-08-02 05:57:37','2025-08-02 05:57:37',NULL,NULL,'system'),(72,1,'email','testowner_sms_1754137516@example.com','<h2>Welcome {Test Owner SMS}!</h2><p>Your account has been successfully created.</p>','failed',NULL,'2025-08-02 06:25:16','2025-08-02 06:25:16',NULL,NULL,'system'),(73,1,'email','testowner_sms_1754137516@example.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','failed',NULL,'2025-08-02 06:25:16','2025-08-02 06:25:16',NULL,NULL,'system'),(74,1,'email','testowner_sms_1754137516@example.com','<h2>Features Overview</h2><p>Discover all the features available in HRMS...</p>','failed',NULL,'2025-08-02 06:25:16','2025-08-02 06:25:16',NULL,NULL,'system'),(75,1,'sms','8801700444157','Welcome {Test Owner SMS} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','failed',NULL,'2025-08-02 06:25:26','2025-08-02 06:25:26',NULL,NULL,'system'),(76,1,'email','testowner_sms_1754137604@example.com','<h2>Welcome {Test Owner SMS}!</h2><p>Your account has been successfully created.</p>','failed',NULL,'2025-08-02 06:26:45','2025-08-02 06:26:45',NULL,NULL,'system'),(77,1,'email','testowner_sms_1754137604@example.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','failed',NULL,'2025-08-02 06:26:45','2025-08-02 06:26:45',NULL,NULL,'system'),(78,1,'email','testowner_sms_1754137604@example.com','<h2>Features Overview</h2><p>Discover all the features available in HRMS...</p>','failed',NULL,'2025-08-02 06:26:45','2025-08-02 06:26:45',NULL,NULL,'system'),(79,1,'sms','8801700821924','Welcome {Test Owner SMS} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','failed',NULL,'2025-08-02 06:26:55','2025-08-02 06:26:55',NULL,NULL,'system'),(80,1,'email','testowner_sms_1754138166@example.com','<h2>Welcome {Test Owner SMS}!</h2><p>Your account has been successfully created.</p>','failed',NULL,'2025-08-02 06:36:06','2025-08-02 06:36:06',NULL,NULL,'system'),(81,1,'email','testowner_sms_1754138166@example.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','failed',NULL,'2025-08-02 06:36:06','2025-08-02 06:36:06',NULL,NULL,'system'),(82,1,'email','testowner_sms_1754138166@example.com','<h2>Features Overview</h2><p>Discover all the features available in HRMS...</p>','failed',NULL,'2025-08-02 06:36:06','2025-08-02 06:36:06',NULL,NULL,'system'),(83,1,'sms','8801700381947','Welcome {Test Owner SMS} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','failed',NULL,'2025-08-02 06:36:06','2025-08-02 06:36:06',NULL,NULL,'system'),(84,1,'email','testowner_sms_1754138232@example.com','<h2>Welcome {Test Owner SMS}!</h2><p>Your account has been successfully created.</p>','failed',NULL,'2025-08-02 06:37:13','2025-08-02 06:37:13',NULL,NULL,'system'),(85,1,'email','testowner_sms_1754138232@example.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','failed',NULL,'2025-08-02 06:37:13','2025-08-02 06:37:13',NULL,NULL,'system'),(86,1,'email','testowner_sms_1754138232@example.com','<h2>Features Overview</h2><p>Discover all the features available in HRMS...</p>','failed',NULL,'2025-08-02 06:37:13','2025-08-02 06:37:13',NULL,NULL,'system'),(87,1,'sms','8801700160243','Welcome {Test Owner SMS} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','failed',NULL,'2025-08-02 06:37:13','2025-08-02 06:37:13',NULL,NULL,'system'),(88,1,'email','testowner_sms_1754145202@example.com','<h2>Welcome {Test Owner SMS}!</h2><p>Your account has been successfully created.</p>','failed',NULL,'2025-08-02 08:33:22','2025-08-02 08:33:22',NULL,NULL,'system'),(89,1,'email','testowner_sms_1754145202@example.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','failed',NULL,'2025-08-02 08:33:22','2025-08-02 08:33:22',NULL,NULL,'system'),(90,1,'email','testowner_sms_1754145202@example.com','<h2>Features Overview</h2><p>Discover all the features available in HRMS...</p>','failed',NULL,'2025-08-02 08:33:22','2025-08-02 08:33:22',NULL,NULL,'system'),(91,1,'sms','8801700757127','Welcome {Test Owner SMS} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','sent','2025-08-02 08:33:23','2025-08-02 08:33:23','2025-08-02 08:33:23',NULL,NULL,'system'),(92,1,'email','testowner_sms_1754145290@example.com','<h2>Welcome {Test Owner SMS}!</h2><p>Your account has been successfully created.</p>','failed',NULL,'2025-08-02 08:34:50','2025-08-02 08:34:50',NULL,NULL,'system'),(93,1,'email','testowner_sms_1754145290@example.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','failed',NULL,'2025-08-02 08:34:50','2025-08-02 08:34:50',NULL,NULL,'system'),(94,1,'email','testowner_sms_1754145290@example.com','<h2>Features Overview</h2><p>Discover all the features available in HRMS...</p>','failed',NULL,'2025-08-02 08:34:50','2025-08-02 08:34:50',NULL,NULL,'system'),(95,1,'sms','8801700676000','Welcome {Test Owner SMS} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','sent','2025-08-02 08:34:51','2025-08-02 08:34:51','2025-08-02 08:34:51',NULL,NULL,'system'),(96,1,'sms','01718262530','Test SMS from HRMS - Correct Parameters','sent','2025-08-02 08:37:05','2025-08-02 08:37:05','2025-08-02 08:37:05',NULL,NULL,'system'),(97,1,'email','samiul42@gmail.com','<h2>Welcome {samiul}!</h2><p>Your account has been successfully created.</p>','sent','2025-08-02 09:06:42','2025-08-02 09:06:42','2025-08-02 09:06:42',NULL,NULL,'system'),(98,1,'email','samiul42@gmail.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','sent','2025-08-02 09:06:42','2025-08-02 09:06:42','2025-08-02 09:06:42',NULL,NULL,'system'),(99,1,'email','samiul42@gmail.com','<h2>Features Overview</h2><p>Discover all the features available in HRMS...</p>','sent','2025-08-02 09:06:42','2025-08-02 09:06:42','2025-08-02 09:06:42',NULL,NULL,'system'),(100,1,'email','testowner_debug_1754148003@example.com','<h2>Welcome {Test Owner Debug}!</h2><p>Your account has been successfully created.</p>','failed',NULL,'2025-08-02 09:20:04','2025-08-02 09:20:04',NULL,NULL,'system'),(101,1,'email','testowner_debug_1754148003@example.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','failed',NULL,'2025-08-02 09:20:04','2025-08-02 09:20:04',NULL,NULL,'system'),(102,1,'email','testowner_debug_1754148003@example.com','<h2>Features Overview</h2><p>Discover all the features available in HRMS...</p>','failed',NULL,'2025-08-02 09:20:04','2025-08-02 09:20:04',NULL,NULL,'system'),(103,1,'sms','8801700412095','Welcome {Test Owner Debug} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','sent','2025-08-02 09:20:05','2025-08-02 09:20:05','2025-08-02 09:20:05',NULL,NULL,'system'),(104,1,'sms','01718262530','Direct SMS Test from HRMS','sent','2025-08-02 09:38:00','2025-08-02 09:38:00','2025-08-02 09:38:00',NULL,NULL,'system'),(105,1,'sms','01718262530','Welcome {Test User} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','sent','2025-08-02 09:38:01','2025-08-02 09:38:01','2025-08-02 09:38:01',NULL,NULL,'system'),(106,1,'sms','01718262530','Welcome {Test User} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','sent','2025-08-02 09:38:02','2025-08-02 09:38:02','2025-08-02 09:38:02',NULL,NULL,'system'),(107,1,'email','testowner_rel_1754149205@example.com','<h2>Welcome {Test Owner Rel}!</h2><p>Your account has been successfully created.</p>','failed',NULL,'2025-08-02 09:40:05','2025-08-02 09:40:05',NULL,NULL,'system'),(108,1,'email','testowner_rel_1754149205@example.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','failed',NULL,'2025-08-02 09:40:05','2025-08-02 09:40:05',NULL,NULL,'system'),(109,1,'email','testowner_rel_1754149205@example.com','<h2>Features Overview</h2><p>Discover all the features available in HRMS...</p>','failed',NULL,'2025-08-02 09:40:05','2025-08-02 09:40:05',NULL,NULL,'system'),(110,1,'sms','8801700149001','Welcome {Test Owner Rel} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','sent','2025-08-02 09:40:06','2025-08-02 09:40:06','2025-08-02 09:40:06',NULL,NULL,'system'),(111,1,'email','testowner_rel_1754149322@example.com','<h2>Welcome {Test Owner Rel}!</h2><p>Your account has been successfully created.</p>','failed',NULL,'2025-08-02 09:42:02','2025-08-02 09:42:02',NULL,NULL,'system'),(112,1,'email','testowner_rel_1754149322@example.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','failed',NULL,'2025-08-02 09:42:02','2025-08-02 09:42:02',NULL,NULL,'system'),(113,1,'email','testowner_rel_1754149322@example.com','<h2>Features Overview</h2><p>Discover all the features available in HRMS...</p>','failed',NULL,'2025-08-02 09:42:02','2025-08-02 09:42:02',NULL,NULL,'system'),(114,1,'sms','8801700546259','Welcome {Test Owner Rel} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','sent','2025-08-02 09:42:03','2025-08-02 09:42:03','2025-08-02 09:42:03',NULL,NULL,'system'),(115,1,'email','samiul42@gmail.com','<h2>Welcome {samiul}!</h2><p>Your account has been successfully created.</p>','sent','2025-08-02 09:43:43','2025-08-02 09:43:43','2025-08-02 09:43:43',NULL,NULL,'system'),(116,1,'email','samiul42@gmail.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','sent','2025-08-02 09:43:43','2025-08-02 09:43:43','2025-08-02 09:43:43',NULL,NULL,'system'),(117,1,'email','samiul42@gmail.com','<h2>Features Overview</h2><p>Discover all the features available in HRMS...</p>','sent','2025-08-02 09:43:43','2025-08-02 09:43:43','2025-08-02 09:43:43',NULL,NULL,'system'),(118,50,'email','samiul42@gmail.com','<h2>Welcome {samiul}!</h2><p>Your account has been successfully created.</p>','sent','2025-08-02 09:50:35','2025-08-02 09:50:35','2025-08-02 09:50:35',NULL,NULL,'system'),(119,50,'email','samiul42@gmail.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','sent','2025-08-02 09:50:35','2025-08-02 09:50:35','2025-08-02 09:50:35',NULL,NULL,'system'),(120,50,'email','samiul42@gmail.com','<h2>Features Overview</h2><p>Discover all the features available in HRMS...</p>','sent','2025-08-02 09:50:35','2025-08-02 09:50:35','2025-08-02 09:50:35',NULL,NULL,'system'),(121,50,'sms','01718262530','Welcome {samiul} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','sent','2025-08-02 09:50:36','2025-08-02 09:50:36','2025-08-02 09:50:36',NULL,NULL,'system'),(122,1,'sms','01718262530','Welcome {Samiul} to HRMS! Your account has been successfully created.','sent','2025-08-02 09:58:18','2025-08-02 09:58:18','2025-08-02 09:58:18',NULL,NULL,'system'),(123,1,'sms','01718262530','Welcome {Samiul} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','sent','2025-08-02 09:58:21','2025-08-02 09:58:21','2025-08-02 09:58:21',NULL,NULL,'system'),(124,1,'sms','01718262530','Test SMS from HRMS - Variable replacement test: Welcome {Samiul}!','sent','2025-08-02 10:01:14','2025-08-02 10:01:14','2025-08-02 10:01:14',NULL,NULL,'system'),(125,1,'sms','01718262530','Welcome {Samiul} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','sent','2025-08-02 10:01:15','2025-08-02 10:01:15','2025-08-02 10:01:15',NULL,NULL,'system'),(126,1,'sms','01718262530','Test SMS from HRMS - Variable replacement test: Welcome {Samiul}!','sent','2025-08-02 10:02:03','2025-08-02 10:02:03','2025-08-02 10:02:03',NULL,NULL,'system'),(127,1,'sms','01718262530','Welcome {Samiul} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','sent','2025-08-02 10:02:04','2025-08-02 10:02:04','2025-08-02 10:02:04',NULL,NULL,'system'),(128,1,'sms','01718262530','Welcome {Samiul} to HRMS! Your account has been successfully created.','sent','2025-08-02 10:38:47','2025-08-02 10:38:47','2025-08-02 10:38:47',NULL,NULL,'system'),(129,1,'sms','01718262530','Welcome {Samiul} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','sent','2025-08-02 10:38:49','2025-08-02 10:38:49','2025-08-02 10:38:49',NULL,NULL,'system'),(130,1,'sms','01718262530','Welcome {Samiul} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','sent','2025-08-02 10:51:28','2025-08-02 10:51:28','2025-08-02 10:51:28',NULL,NULL,'system'),(131,1,'sms','01718262530','Welcome {Samiul} to HRMS! Your account has been successfully created. You can now manage your properties and tenants efficiently.','sent','2025-08-02 10:51:29','2025-08-02 10:51:29','2025-08-02 10:51:29',NULL,NULL,'system'),(132,1,'email','admin@hrms.com','<h2>Welcome {Super Admin}!</h2><p>Your account has been successfully created.</p>','sent','2025-08-03 07:46:22','2025-08-03 07:46:22','2025-08-03 07:46:22',NULL,NULL,'system'),(133,1,'email','admin@hrms.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','sent','2025-08-03 07:46:22','2025-08-03 07:46:22','2025-08-03 07:46:22',NULL,NULL,'system'),(134,1,'email','admin@hrms.com','<h2>Features Overview</h2><p>Discover all the features available in HRMS...</p>','sent','2025-08-03 07:46:22','2025-08-03 07:46:22','2025-08-03 07:46:22',NULL,NULL,'system'),(135,1,'sms','01700000000','Welcome Super Admin! Your HRMS account has been created successfully. You can now access all services.','sent','2025-08-03 07:46:23','2025-08-03 07:46:23','2025-08-03 07:46:23',NULL,NULL,'system'),(136,1,'email','admin@hrms.com','<h2>Welcome {Super Admin}!</h2><p>Your account has been successfully created.</p>','sent','2025-08-03 07:47:53','2025-08-03 07:47:53','2025-08-03 07:47:53',NULL,NULL,'system'),(137,1,'email','admin@hrms.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','sent','2025-08-03 07:47:54','2025-08-03 07:47:54','2025-08-03 07:47:54',NULL,NULL,'system'),(138,1,'email','admin@hrms.com','<h2>Features Overview</h2><p>Discover all the features available in HRMS...</p>','sent','2025-08-03 07:47:54','2025-08-03 07:47:54','2025-08-03 07:47:54',NULL,NULL,'system'),(139,1,'sms','01700000000','Welcome Super Admin! Your HRMS account has been created successfully. You can now access all services.','sent','2025-08-03 07:47:56','2025-08-03 07:47:56','2025-08-03 07:47:56',NULL,NULL,'system'),(140,1,'email','test1754229308@example.com','<h2>Welcome {Test User 1754229308}!</h2><p>Your account has been successfully created.</p>','failed',NULL,'2025-08-03 07:55:18','2025-08-03 07:55:18',NULL,NULL,'system'),(141,1,'email','test1754229308@example.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','failed',NULL,'2025-08-03 07:55:18','2025-08-03 07:55:18',NULL,NULL,'system'),(142,1,'email','test1754229308@example.com','<h2>Features Overview</h2><p>Discover all the features available in HRMS...</p>','failed',NULL,'2025-08-03 07:55:18','2025-08-03 07:55:18',NULL,NULL,'system'),(143,1,'sms','+8801718262530','Welcome Test User 1754229308! Your HRMS account has been created successfully. You can now access all services.','sent','2025-08-03 07:55:19','2025-08-03 07:55:19','2025-08-03 07:55:19',NULL,NULL,'system'),(144,3,'email','samiul42@gmail.com','<h2>Welcome {Md Samiul Alam}!</h2><p>Your account has been successfully created.</p>','sent','2025-08-03 09:14:38','2025-08-03 09:14:38','2025-08-03 09:14:38',NULL,NULL,'system'),(145,3,'email','samiul42@gmail.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','sent','2025-08-03 09:14:38','2025-08-03 09:14:38','2025-08-03 09:14:38',NULL,NULL,'system'),(146,3,'email','samiul42@gmail.com','<h2>Features Overview</h2><p>Discover all the features available in HRMS...</p>','sent','2025-08-03 09:14:38','2025-08-03 09:14:38','2025-08-03 09:14:38',NULL,NULL,'system'),(147,3,'email','samiul42@gmail.com','Dear {Md Samiul Alam},\n\nYour subscription details:\n\nPlan: {Free Plan}\nPrice: ${0.00}\nExpiry Date: {2026-08-03 00:00:00}\nSMS Credits: {0}\n\nThank you for choosing HRMS!\n\nBest regards,\nThe HRMS Team','sent','2025-08-03 09:14:38','2025-08-03 09:14:38','2025-08-03 09:14:38',NULL,NULL,'system'),(148,3,'sms','01718262530','Welcome Md Samiul Alam! Your HRMS account has been created successfully. You can now access all services.','sent','2025-08-03 09:14:39','2025-08-03 09:14:39','2025-08-03 09:14:39',NULL,NULL,'system'),(149,3,'email','samiul42@gmail.com','<h2>Welcome {Md Samiul Alam}!</h2><p>Your account has been successfully created.</p>','sent','2025-08-03 09:49:28','2025-08-03 09:49:28','2025-08-03 09:49:28',NULL,NULL,'system'),(150,3,'email','samiul42@gmail.com','<h2>Account Setup Guide</h2><p>Here\'s how to get started with HRMS...</p>','sent','2025-08-03 09:49:28','2025-08-03 09:49:28','2025-08-03 09:49:28',NULL,NULL,'system'),(151,3,'email','samiul42@gmail.com','Dear Md Samiul Alam,\n\nYour subscription details:\n\nPlan: Free Plan\nPrice: $0.00\nExpiry Date: 2026-08-03 00:00:00\nSMS Credits: {sms_credits}\n\nThank you for choosing HRMS!\n\nBest regards,\nThe HRMS Team','sent','2025-08-03 09:49:28','2025-08-03 09:49:28','2025-08-03 09:49:28',NULL,NULL,'system'),(152,3,'sms','01718262530','Welcome Md Samiul Alam! Your HRMS account has been created successfully. You can now access all services.','sent','2025-08-03 09:49:29','2025-08-03 09:49:29','2025-08-03 09:49:29',NULL,NULL,'system'),(153,3,'email','samiul42@gmail.com','Dear {Md Samiul Alam},\n\nYour subscription has been activated successfully!\n\nPlan: {Free Plan}\nExpiry Date: {Aug 03, 2026}\n\nThank you for choosing HRMS!\n\nBest regards,\nThe HRMS Team','sent','2025-08-03 10:18:57','2025-08-03 10:18:57','2025-08-03 10:18:57',NULL,NULL,'system'),(154,3,'sms','01718262530','Your {Free Plan} subscription is now active. Expires: {Aug 03, 2026}. Thank you!','failed',NULL,'2025-08-03 10:18:57','2025-08-03 10:18:57',NULL,NULL,'system'),(155,62,'email','samiul42@gmail.com','Welcome to HRMS! Your account has been created successfully.','sent','2025-08-03 10:31:03','2025-08-03 10:30:52','2025-08-03 10:31:03',56,'welcome_email','system'),(156,62,'sms','01718262530','Welcome to HRMS! Your account has been created successfully.','sent','2025-08-03 10:30:52','2025-08-03 10:30:52','2025-08-03 10:30:52',56,'welcome_sms','system'),(157,3,'email','samiul42@gmail.com','Welcome to HRMS! Your account has been created successfully.','sent','2025-08-03 10:31:03','2025-08-03 10:31:03','2025-08-03 10:31:03',NULL,NULL,'system');
/*!40000 ALTER TABLE `notification_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otp_settings`
--

DROP TABLE IF EXISTS `otp_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `otp_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `otp_length` int NOT NULL DEFAULT '6',
  `otp_expiry_minutes` int NOT NULL DEFAULT '10',
  `max_attempts` int NOT NULL DEFAULT '3',
  `resend_cooldown_seconds` int NOT NULL DEFAULT '60',
  `require_otp_for_registration` tinyint(1) NOT NULL DEFAULT '1',
  `require_otp_for_login` tinyint(1) NOT NULL DEFAULT '0',
  `require_otp_for_password_reset` tinyint(1) NOT NULL DEFAULT '1',
  `otp_message_template` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otp_settings`
--

LOCK TABLES `otp_settings` WRITE;
/*!40000 ALTER TABLE `otp_settings` DISABLE KEYS */;
INSERT INTO `otp_settings` VALUES (1,0,6,10,3,60,0,0,0,'Your OTP is: {otp}. Valid for {minutes} minutes.','2025-07-21 23:59:50','2025-07-22 01:31:33');
/*!40000 ALTER TABLE `otp_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otps`
--

DROP TABLE IF EXISTS `otps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `otps` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `phone` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `otp` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_used` tinyint(1) NOT NULL DEFAULT '0',
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `otps_phone_type_index` (`phone`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otps`
--

LOCK TABLES `otps` WRITE;
/*!40000 ALTER TABLE `otps` DISABLE KEYS */;
INSERT INTO `otps` VALUES (7,'01713642628','755499','registration',0,'2025-07-21 22:55:38','2025-07-21 22:45:38','2025-07-21 22:45:38'),(2,'8801713642628','177429','registration',1,'2025-07-21 22:51:46','2025-07-21 22:41:46','2025-07-21 22:43:23'),(4,'8801713642628','234042','registration',1,'2025-07-21 22:54:16','2025-07-21 22:44:16','2025-07-21 22:44:16'),(6,'8801713642628','651820','registration',1,'2025-07-21 22:54:31','2025-07-21 22:44:31','2025-07-21 22:44:31'),(8,'017129630','471890','registration',1,'2025-07-22 01:28:48','2025-07-22 01:18:48','2025-07-22 01:19:01'),(9,'017129630','454440','registration',1,'2025-07-22 01:29:40','2025-07-22 01:19:40','2025-07-22 01:19:40'),(10,'017129630','335429','registration',1,'2025-07-22 01:31:04','2025-07-22 01:21:04','2025-07-22 01:21:04');
/*!40000 ALTER TABLE `otps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owner_subscriptions`
--

DROP TABLE IF EXISTS `owner_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `owner_subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` bigint unsigned NOT NULL,
  `plan_id` bigint unsigned NOT NULL,
  `status` enum('active','pending','pending_upgrade','suspended','cancelled','expired') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `auto_renew` tinyint(1) NOT NULL DEFAULT '1',
  `sms_credits` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `owner_subscriptions_owner_id_foreign` (`owner_id`),
  KEY `owner_subscriptions_plan_id_foreign` (`plan_id`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owner_subscriptions`
--

LOCK TABLES `owner_subscriptions` WRITE;
/*!40000 ALTER TABLE `owner_subscriptions` DISABLE KEYS */;
INSERT INTO `owner_subscriptions` VALUES (25,17,2,'active','2025-07-31','2025-08-30',1,200,'2025-07-31 11:58:21','2025-07-31 12:28:09'),(35,28,1,'active','2025-08-02','2026-08-02',1,50,'2025-08-02 03:23:13','2025-08-02 03:25:33'),(34,27,1,'active','2025-08-02','2025-09-01',1,100,'2025-08-02 02:15:34','2025-08-02 02:15:34'),(33,26,1,'active','2025-08-02','2026-08-02',1,0,'2025-08-02 02:11:10','2025-08-02 02:11:10'),(36,29,1,'active','2025-08-02','2025-09-01',1,100,'2025-08-02 03:33:53','2025-08-02 03:33:53'),(37,30,1,'active','2025-08-02','2026-08-02',1,0,'2025-08-02 03:41:03','2025-08-02 03:41:03'),(38,31,1,'active','2025-08-02','2026-08-02',1,0,'2025-08-02 05:11:35','2025-08-02 05:11:35'),(39,32,1,'active','2025-08-02','2026-08-02',1,0,'2025-08-02 05:57:37','2025-08-02 05:57:37'),(40,39,1,'active','2025-08-02','2026-08-02',1,0,'2025-08-02 09:06:42','2025-08-02 09:06:42'),(41,41,1,'active','2025-08-02','2026-08-02',1,0,'2025-08-02 09:36:58','2025-08-02 09:36:58'),(42,44,1,'active','2025-08-02','2026-08-02',1,0,'2025-08-02 09:43:43','2025-08-02 09:43:43'),(43,45,1,'active','2025-08-02','2026-08-02',1,0,'2025-08-02 09:50:36','2025-08-02 09:50:36'),(44,47,1,'active','2025-08-03','2026-08-03',1,0,'2025-08-03 07:42:21','2025-08-03 07:42:21'),(45,48,1,'active','2025-08-03','2026-08-03',1,0,'2025-08-03 07:53:06','2025-08-03 07:53:06'),(46,50,1,'active','2025-08-03','2026-08-03',1,0,'2025-08-03 08:01:21','2025-08-03 08:01:21'),(47,56,1,'active','2025-08-03','2026-08-03',1,0,'2025-08-03 09:14:38','2025-08-03 09:14:38');
/*!40000 ALTER TABLE `owner_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owners`
--

DROP TABLE IF EXISTS `owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `owners` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `is_super_admin` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('active','inactive','suspended') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_verified` tinyint(1) NOT NULL DEFAULT '0',
  `address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` enum('Male','Female','Other') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_pic` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_properties` int unsigned NOT NULL DEFAULT '0',
  `total_tenants` int unsigned NOT NULL DEFAULT '0',
  `owner_uid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `owners_email_unique` (`email`),
  UNIQUE KEY `owners_owner_uid_unique` (`owner_uid`),
  KEY `owners_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owners`
--

LOCK TABLES `owners` WRITE;
/*!40000 ALTER TABLE `owners` DISABLE KEYS */;
INSERT INTO `owners` VALUES (1,3,1,'active','Super Admin','admin@hrms.com','01700000000',0,'Dhaka, Bangladesh','Bangladesh',NULL,NULL,0,0,'OWN-DYZ6EMUW','2025-07-21 23:43:47','2025-07-21 23:43:47',NULL),(56,62,0,'active','Md Samiul Alam','samiul42@gmail.com','01718262530',0,'wert wr','Bangladesh','Male',NULL,0,0,'OWN-WIHDQ4JB','2025-08-03 09:14:38','2025-08-03 09:14:38',NULL),(55,61,0,'active','Test Owner 1754233503','test1754233503@example.com','+8801718262530',0,'Test Address','Bangladesh','Male',NULL,0,0,'OWN-OVN7DRQA','2025-08-03 09:05:03','2025-08-03 09:05:03','2025-08-03 09:05:03');
/*!40000 ALTER TABLE `owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package_limits`
--

DROP TABLE IF EXISTS `package_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `package_limits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` bigint unsigned NOT NULL,
  `limit_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `current_usage` int NOT NULL DEFAULT '0',
  `max_limit` int NOT NULL,
  `reset_date` date NOT NULL,
  `reset_frequency` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `package_limits_owner_id_limit_type_unique` (`owner_id`,`limit_type`),
  KEY `package_limits_owner_id_limit_type_is_active_index` (`owner_id`,`limit_type`,`is_active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_limits`
--

LOCK TABLES `package_limits` WRITE;
/*!40000 ALTER TABLE `package_limits` DISABLE KEYS */;
/*!40000 ALTER TABLE `package_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_methods`
--

DROP TABLE IF EXISTS `payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_methods` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `logo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_fee` decimal(5,2) NOT NULL DEFAULT '0.00',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `settings` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payment_methods_code_unique` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_methods`
--

LOCK TABLES `payment_methods` WRITE;
/*!40000 ALTER TABLE `payment_methods` DISABLE KEYS */;
INSERT INTO `payment_methods` VALUES (1,'bKash','bkash','Mobile banking service by bKash Limited',NULL,1.50,1,'{\"api_key\": \"demo_key\", \"api_secret\": \"demo_secret\", \"gateway_url\": \"https://tokenized.sandbox.bka.sh/v1.2.0-beta\", \"merchant_id\": \"BKASH001\", \"sandbox_mode\": true}','2025-07-28 11:41:34','2025-07-31 11:50:24'),(2,'Nagad','nagad','Digital financial service by Bangladesh Post Office',NULL,1.00,1,'{\"api_key\": \"nagad_api_key_here\", \"gateway_url\": \"https://nagad.com.bd/payment\", \"merchant_id\": \"NAGAD001\"}','2025-07-28 11:41:34','2025-07-31 11:15:08'),(3,'Rocket','rocket','Mobile banking service by Dutch-Bangla Bank',NULL,1.80,1,'{\"api_key\": \"rocket_api_key_here\", \"gateway_url\": \"https://rocket.com.bd/payment\", \"merchant_id\": \"ROCKET001\"}','2025-07-28 11:41:34','2025-07-31 11:15:08'),(4,'Bank Transfer','bank_transfer','Direct bank transfer to our account',NULL,0.00,1,'{\"branch\": \"Dhaka Main Branch\", \"bank_name\": \"Demo Bank\", \"account_number\": \"1234567890\"}','2025-07-28 11:41:34','2025-07-31 11:15:08'),(5,'Cash Payment','cash','Pay at our office location',NULL,0.00,1,'{\"office_hours\": \"9:00 AM - 5:00 PM\", \"office_address\": \"Dhaka, Bangladesh\"}','2025-07-28 11:41:34','2025-07-31 11:15:08');
/*!40000 ALTER TABLE `payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM AUTO_INCREMENT=151 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (1,'App\\Models\\User',4,'api-token','b4dea780bcc5a767170db3167a6beac0b6e27bbf5c185acb349e608cec39bb0b','[\"*\"]','2025-07-22 01:21:43',NULL,'2025-07-22 01:21:27','2025-07-22 01:21:43'),(2,'App\\Models\\User',5,'api-token','d753b1747790b833ef297e68dfd86fe615f219d88c309fb1654750d88bedbd9c','[\"*\"]',NULL,NULL,'2025-07-22 01:32:22','2025-07-22 01:32:22'),(3,'App\\Models\\User',5,'api-token','d2356a429b33b58eab2a0b2d6f2035e0a8a8192b5d1f5b17cfabf0d140e62e56','[\"*\"]','2025-07-22 01:42:12',NULL,'2025-07-22 01:32:43','2025-07-22 01:42:12'),(4,'App\\Models\\User',5,'api-token','ad3b189fcf4f469accf2964fa14ba2f8732206b575b6ba15e04d2e4c2df787c5','[\"*\"]','2025-07-22 01:54:04',NULL,'2025-07-22 01:54:03','2025-07-22 01:54:04'),(5,'App\\Models\\User',5,'api-token','4fad8cccf4cc6bd79ddc263b2e8354fbc0d7be7945f6fc85ee455003708e34e2','[\"*\"]','2025-07-22 05:08:41',NULL,'2025-07-22 02:20:15','2025-07-22 05:08:41'),(6,'App\\Models\\User',5,'api-token','d7557e559144fe09b87781e4519928cdca8f6fd282d5557df398b85c356a0bc8','[\"*\"]','2025-07-22 04:57:35',NULL,'2025-07-22 04:24:22','2025-07-22 04:57:35'),(7,'App\\Models\\User',5,'api-token','90b272e70b9004acc9f1ae380904a65c1954bdb308452272873dc47e8921850c','[\"*\"]','2025-07-22 05:12:44',NULL,'2025-07-22 05:12:41','2025-07-22 05:12:44'),(8,'App\\Models\\User',5,'api-token','f34e46edd2f4600905061b2e5e5929dd2ecb8f0f0597fe26879ae218102b76d2','[\"*\"]','2025-07-22 11:58:54',NULL,'2025-07-22 05:23:09','2025-07-22 11:58:54'),(9,'App\\Models\\User',5,'api-token','2c2167ff772289d1d53ec15482958fc857d02d36df22a3a28c4384ec91d37cc5','[\"*\"]','2025-07-22 10:42:50',NULL,'2025-07-22 05:24:37','2025-07-22 10:42:50'),(10,'App\\Models\\User',6,'auth_token','91e78968cb59d25f25bae9f53a41068c8013a5690fa36a36190cfad322778db4','[\"*\"]','2025-07-22 11:07:43',NULL,'2025-07-22 11:00:53','2025-07-22 11:07:43'),(11,'App\\Models\\User',5,'auth_token','a84c075b06ca70549ab89f60d39d930af0d972f72a846f8c4b90107c501b5f7b','[\"*\"]',NULL,NULL,'2025-07-22 11:16:20','2025-07-22 11:16:20'),(12,'App\\Models\\User',5,'auth_token','b11e556c92179fee751b29393bb80e6f06fadb732e0b21946966b654cfc56a01','[\"*\"]',NULL,NULL,'2025-07-22 11:17:34','2025-07-22 11:17:34'),(13,'App\\Models\\User',5,'auth_token','de47b5102d24a496537a21fcf861944d4010a4b2d6f0a02cd852f748d5040a6e','[\"*\"]',NULL,NULL,'2025-07-22 11:21:44','2025-07-22 11:21:44'),(14,'App\\Models\\User',5,'auth_token','afe12b3864805e7ef3c29a5ea65bb90b5ffa0ea3a35fc62a57a9ced5fb2d57d9','[\"*\"]','2025-07-22 23:47:52',NULL,'2025-07-22 11:25:43','2025-07-22 23:47:52'),(15,'App\\Models\\User',5,'test-token','74652d12c5a384e6330036a507b1389b60194fcf6bc477aed62b3a69c7fe4ba0','[\"*\"]','2025-07-22 11:31:06',NULL,'2025-07-22 11:31:06','2025-07-22 11:31:06'),(16,'App\\Models\\User',5,'test-token','838b969a00949d66a4b8fef339f5db50f034c00a4bb24b1fe6e8d4e318629e0a','[\"*\"]','2025-07-22 11:32:17',NULL,'2025-07-22 11:32:17','2025-07-22 11:32:17'),(17,'App\\Models\\User',6,'auth_token','98732088d61b438396155ab6625b1b36d1508a6a5b323bc1cd5d64da0ccf5ff1','[\"*\"]','2025-07-22 23:42:02',NULL,'2025-07-22 12:01:39','2025-07-22 23:42:02'),(18,'App\\Models\\User',6,'auth_token','b25d1377c1ee82d1050be99cba6fa2874fe42ac99e7e38c71120ac782ad12ef7','[\"*\"]','2025-07-23 02:16:46',NULL,'2025-07-22 23:42:35','2025-07-23 02:16:46'),(19,'App\\Models\\User',6,'auth_token','b45acf43ce7bce6d101a7a22eb75af6b09d79e199087a2a58d0df69601cdc21f','[\"*\"]','2025-07-23 00:03:27',NULL,'2025-07-22 23:48:19','2025-07-23 00:03:27'),(20,'App\\Models\\User',6,'auth_token','2f19d8b6f06a5827578bee75de19edba86e54da9217af2d7d66f0fad12f7c566','[\"*\"]','2025-07-23 01:13:41',NULL,'2025-07-23 00:03:58','2025-07-23 01:13:41'),(21,'App\\Models\\User',6,'auth_token','ec315af8d28bde040e57028d4bc7af1c8fddcb89d0b4aea4b045cbf9d66b83dc','[\"*\"]','2025-07-23 01:20:24',NULL,'2025-07-23 01:14:12','2025-07-23 01:20:24'),(22,'App\\Models\\User',5,'auth_token','b00f75371669a1f120d27e8116b5ab82f2f3533a8e2c1de9fab0719ea0ef8e4e','[\"*\"]','2025-07-23 01:30:38',NULL,'2025-07-23 01:20:42','2025-07-23 01:30:38'),(23,'App\\Models\\User',6,'auth_token','8d02a0fe2e39ba2b1349d9d56c5531fee5fe526afbb46c3a391e1c2c59e5bc8e','[\"*\"]','2025-07-23 01:32:32',NULL,'2025-07-23 01:31:00','2025-07-23 01:32:32'),(24,'App\\Models\\User',5,'test-token','98dab04c8e7d21dfea263eed3c97b96461405839a0d601594b6813a086250bee','[\"*\"]',NULL,NULL,'2025-07-23 01:32:37','2025-07-23 01:32:37'),(25,'App\\Models\\User',5,'auth_token','ea34a6bbcea958170722e5e4052241e1d252cf5fead16db8c7e223e5490a69d8','[\"*\"]','2025-07-23 01:33:27',NULL,'2025-07-23 01:33:22','2025-07-23 01:33:27'),(26,'App\\Models\\User',6,'auth_token','e58aa296cfa5e60fe0a937c8f876db55ba860f9904bfa3add96d985ecc0a2eba','[\"*\"]','2025-07-23 02:23:40',NULL,'2025-07-23 02:17:29','2025-07-23 02:23:40'),(27,'App\\Models\\User',6,'auth_token','886c2d785f4a82c4d27fbbef4f381f9c2af32c332fcc913ea6f28336c23c8d2e','[\"*\"]','2025-07-23 02:24:23',NULL,'2025-07-23 02:24:07','2025-07-23 02:24:23'),(28,'App\\Models\\User',5,'auth_token','0ebd7dacb7c3cb8e5408829a1b84852db328e4e402eb4989daa143999a3b15e4','[\"*\"]','2025-07-23 09:21:02',NULL,'2025-07-23 02:24:43','2025-07-23 09:21:02'),(29,'App\\Models\\User',5,'auth_token','8b27446da89228af6a2dd67aa65e877fa718c1f7365e5fc160d37ea630dd5391','[\"*\"]','2025-07-23 08:20:34',NULL,'2025-07-23 08:14:24','2025-07-23 08:20:34'),(30,'App\\Models\\User',5,'auth_token','aaf16dbfd975457ccc7e220f2094e7d0804c92ca56a2e03f4afb535db930203a','[\"*\"]','2025-07-23 08:41:22',NULL,'2025-07-23 08:35:08','2025-07-23 08:41:22'),(31,'App\\Models\\User',5,'auth_token','95301a889bd3f643fd3c42d54a28a86c2420125511f708352486284c9acaa518','[\"*\"]','2025-07-23 08:56:37',NULL,'2025-07-23 08:43:17','2025-07-23 08:56:37'),(32,'App\\Models\\User',5,'auth_token','bd028f489a96ff61874edcea20a699b548a34e6eccd243174ea8674f0a48ad5e','[\"*\"]','2025-07-23 08:59:45',NULL,'2025-07-23 08:59:40','2025-07-23 08:59:45'),(33,'App\\Models\\User',6,'auth_token','c28be9e0144799d4e853f302a5f8128f8be0a1316ca4a5bc04f8499d09d1378d','[\"*\"]','2025-07-23 09:01:40',NULL,'2025-07-23 09:01:19','2025-07-23 09:01:40'),(34,'App\\Models\\User',6,'auth_token','d30cdb2fd5c59f5c62d83847b054572e5e7eba892ca2010c1e33953537564652','[\"*\"]','2025-07-23 09:03:47',NULL,'2025-07-23 09:03:45','2025-07-23 09:03:47'),(35,'App\\Models\\User',6,'auth_token','ee2faa4ba6e03d6cb0a7725cef7c2d98b8d46e97d827c47d4985e2da132a66af','[\"*\"]','2025-07-23 09:07:44',NULL,'2025-07-23 09:07:39','2025-07-23 09:07:44'),(36,'App\\Models\\User',5,'auth_token','3a1da88af3d6122cd0b7ff4d1dfff70cc9a06d3d2d546db03b6233c0b0bb1f52','[\"*\"]','2025-07-23 09:10:19',NULL,'2025-07-23 09:10:17','2025-07-23 09:10:19'),(37,'App\\Models\\User',5,'auth_token','88b33cec1df35b58f8fbe35327c226d258364f210226925f9a32700b264377b6','[\"*\"]','2025-07-23 09:10:50',NULL,'2025-07-23 09:10:48','2025-07-23 09:10:50'),(38,'App\\Models\\User',5,'auth_token','c275dfc6bd23c78f23c429d3dfe01f8ca8c4d7fa21c8ac88a4e14462e46b68b4','[\"*\"]','2025-07-23 09:13:14',NULL,'2025-07-23 09:13:12','2025-07-23 09:13:14'),(39,'App\\Models\\User',5,'auth_token','241333d0ed98eb136359a5318c983f1fc7cc819c8a72f2613aa12f6a294980fd','[\"*\"]','2025-07-23 09:17:19',NULL,'2025-07-23 09:17:12','2025-07-23 09:17:19'),(40,'App\\Models\\User',5,'auth_token','b0857e575c8640ef33da3116ef2371f7b25acab50e46de0021c7dc41594eda54','[\"*\"]','2025-07-23 09:20:10',NULL,'2025-07-23 09:20:03','2025-07-23 09:20:10'),(41,'App\\Models\\User',5,'auth_token','6501493ceb3a1d95d5d53b69e09e031a880b541fa42e8149f2ca66b14a6465bd','[\"*\"]','2025-07-23 09:25:41',NULL,'2025-07-23 09:23:36','2025-07-23 09:25:41'),(42,'App\\Models\\User',5,'auth_token','83eb1bdc1577b1fc9ccee96990be2803b0e83273d343c4f6724e06c25fab290f','[\"*\"]','2025-07-23 09:26:52',NULL,'2025-07-23 09:26:11','2025-07-23 09:26:52'),(43,'App\\Models\\User',5,'auth_token','b4224c2eea9689cb021dff05a652952869dad1f9d09f7f083fb75838aa7b7231','[\"*\"]','2025-07-23 09:27:41',NULL,'2025-07-23 09:27:21','2025-07-23 09:27:41'),(44,'App\\Models\\User',5,'auth_token','4c7baf46e8d8b63e34a02035c58fd8f85aee8856823639c3b19de85f60e4f72c','[\"*\"]','2025-07-23 09:31:08',NULL,'2025-07-23 09:29:38','2025-07-23 09:31:08'),(45,'App\\Models\\User',5,'auth_token','7740efe4f976ce0511c786a199a6bdb118c1468dddf698f09bace5feab618641','[\"*\"]','2025-07-23 09:34:06',NULL,'2025-07-23 09:31:33','2025-07-23 09:34:06'),(46,'App\\Models\\User',5,'auth_token','d981592e7577f2e900bc84c105e3de5730f490373f75c94663055e1b4765931a','[\"*\"]','2025-07-23 09:36:03',NULL,'2025-07-23 09:34:31','2025-07-23 09:36:03'),(47,'App\\Models\\User',5,'auth_token','696bd58ccadc7c8692be36581c82fbe535b68cc26c5bd994495e772add97bfdf','[\"*\"]','2025-07-23 09:42:20',NULL,'2025-07-23 09:36:24','2025-07-23 09:42:20'),(48,'App\\Models\\User',5,'auth_token','d9c2f51b1b198cf1b28f2cb01591d5db8653e6278c14c793e424edadb1730e9d','[\"*\"]','2025-07-23 09:46:02',NULL,'2025-07-23 09:42:38','2025-07-23 09:46:02'),(49,'App\\Models\\User',5,'auth_token','811ef1aaf462449570e40d2d83c92ae6561b8d0cb5f912759eb2dbd550f65a3d','[\"*\"]','2025-07-23 09:46:27',NULL,'2025-07-23 09:46:18','2025-07-23 09:46:27'),(50,'App\\Models\\User',5,'auth_token','e3524b0c5ecb8fb9270a6c3e5c9ae1e182eaf46f836ea7b5bd8aa7ff251a2087','[\"*\"]','2025-07-23 09:53:14',NULL,'2025-07-23 09:48:36','2025-07-23 09:53:14'),(51,'App\\Models\\User',5,'auth_token','83ca51260c117f8ca00e9de864b91810580356564f95a6cda120585033ac2eb6','[\"*\"]','2025-07-23 09:59:53',NULL,'2025-07-23 09:53:31','2025-07-23 09:59:53'),(52,'App\\Models\\User',5,'auth_token','14a4cdfc01c88a847546e26e82d5f6eb0a56ab0fe45f3dfbeb5e08156d17f80c','[\"*\"]','2025-07-23 10:02:33',NULL,'2025-07-23 10:00:10','2025-07-23 10:02:33'),(53,'App\\Models\\User',5,'auth_token','b0cb9ab1b9c71a4de83fa198818be488069796513b91373cba91cca762748db8','[\"*\"]','2025-07-23 10:04:36',NULL,'2025-07-23 10:02:49','2025-07-23 10:04:36'),(54,'App\\Models\\User',5,'auth_token','e7a6c40b9823c85cd2e47f47ce9bc1d9346c34d4a93a271712a763768a0b14ec','[\"*\"]','2025-07-23 10:04:56',NULL,'2025-07-23 10:04:52','2025-07-23 10:04:56'),(55,'App\\Models\\User',5,'auth_token','35d8e73ee6a11d9bd2b4c9b11a169843799dedb3532406207254cdf5fc91365e','[\"*\"]','2025-07-23 10:07:13',NULL,'2025-07-23 10:07:10','2025-07-23 10:07:13'),(56,'App\\Models\\User',5,'auth_token','f829d57ddba09679dd6e08683b827b64e448b6349df4ed9c1adee06cf618d780','[\"*\"]','2025-07-23 10:17:16',NULL,'2025-07-23 10:15:45','2025-07-23 10:17:16'),(57,'App\\Models\\User',5,'auth_token','947e02185fc30f913606531d74216c59b685a42e12f7d8ca3c899ee6eb629cf2','[\"*\"]','2025-07-23 11:09:21',NULL,'2025-07-23 10:18:25','2025-07-23 11:09:21'),(58,'App\\Models\\User',5,'auth_token','6227c385b6338640b4e714fa62b9c05976a9af0418d8d8fef8e3ada22d53253c','[\"*\"]',NULL,NULL,'2025-07-23 22:14:38','2025-07-23 22:14:38'),(59,'App\\Models\\User',5,'auth_token','05f2f0e62e20c69c053470ee1e924d9fb0be338540a408b062d0956081cea247','[\"*\"]',NULL,NULL,'2025-07-23 22:14:43','2025-07-23 22:14:43'),(60,'App\\Models\\User',5,'auth_token','21aa2beee52a50c6636a00b07b23c79d3e16804166ffc67c175f2532d98d053a','[\"*\"]',NULL,NULL,'2025-07-23 22:14:49','2025-07-23 22:14:49'),(61,'App\\Models\\User',5,'auth_token','5f3c87ed7623b98a64ca9f4aeb9cd6551d872c6d383e62a3e583787dc71b1018','[\"*\"]',NULL,NULL,'2025-07-23 22:15:46','2025-07-23 22:15:46'),(62,'App\\Models\\User',5,'auth_token','82eb4997bad0b1afbc4cff5a4dcf64fc0648677a55f903f82dac20dd9e642464','[\"*\"]',NULL,NULL,'2025-07-23 22:20:09','2025-07-23 22:20:09'),(63,'App\\Models\\User',5,'auth_token','0054a81aa02ba0da03e8791ac27b58703051c5a606db37e6b71e396028fc3239','[\"*\"]',NULL,NULL,'2025-07-23 22:21:27','2025-07-23 22:21:27'),(64,'App\\Models\\User',5,'auth_token','3e5af34e4d046d45e6153ca077f8edc001effccb7de8d8df81232ce17fe31899','[\"*\"]',NULL,NULL,'2025-07-23 22:21:38','2025-07-23 22:21:38'),(65,'App\\Models\\User',5,'auth_token','d9454e68ca77fbd1bfa4698ec9f6415a17cf95fcd8d4fbfa806fa04d3869d7b0','[\"*\"]',NULL,NULL,'2025-07-23 22:21:46','2025-07-23 22:21:46'),(66,'App\\Models\\User',5,'auth_token','242a59897226ab00bf427cd38db85bd4983a6494cd209a640f24541121afef13','[\"*\"]',NULL,NULL,'2025-07-23 22:22:15','2025-07-23 22:22:15'),(67,'App\\Models\\User',5,'auth_token','548e8f7fb8a4f83b024c9621a082ab5073f1eeecf27ee4df2dee337ddb185bac','[\"*\"]',NULL,NULL,'2025-07-23 22:24:23','2025-07-23 22:24:23'),(68,'App\\Models\\User',5,'auth_token','a613b5676ca077a725c3308f2186cbd8c9dca50a3eacf03ce5d6faeba9e950a2','[\"*\"]',NULL,NULL,'2025-07-23 22:24:26','2025-07-23 22:24:26'),(69,'App\\Models\\User',5,'auth_token','6b8ecaebcd3439781bfb3f87e42fa9ca6170599abdebc9366ea231761edb2d88','[\"*\"]',NULL,NULL,'2025-07-23 22:39:24','2025-07-23 22:39:24'),(70,'App\\Models\\User',5,'auth_token','a752f49a4c8596aac4c981b59ddb20a9419b63f7625ed6a87924c3d7f76cca12','[\"*\"]',NULL,NULL,'2025-07-23 22:39:31','2025-07-23 22:39:31'),(71,'App\\Models\\User',5,'auth_token','1c924586e082e8b9717fdb41baf3d52dca09585ef6a01ea6223490559dbce494','[\"*\"]',NULL,NULL,'2025-07-23 22:40:50','2025-07-23 22:40:50'),(72,'App\\Models\\User',5,'auth_token','84877aa9bca440b4769ebb9bfc68cbab8745d39097c6dbb8f00819679eea9e37','[\"*\"]',NULL,NULL,'2025-07-23 22:40:52','2025-07-23 22:40:52'),(73,'App\\Models\\User',5,'auth_token','b7b338a2fffbe3138baa15bf7756e234ec3732ebec9f3435aca445bc34a5101a','[\"*\"]',NULL,NULL,'2025-07-23 22:52:09','2025-07-23 22:52:09'),(74,'App\\Models\\User',5,'auth_token','536ca2bfedee2b9b289cdd546bc40d75be2302bc0c41689f25c1a2f8226ac202','[\"*\"]',NULL,NULL,'2025-07-23 22:52:20','2025-07-23 22:52:20'),(75,'App\\Models\\User',5,'auth_token','cc573527ed6b9b7043e7c7d40c21fd8b72b0efcff23c6a3d3d789847b2bfefc3','[\"*\"]',NULL,NULL,'2025-07-23 22:53:57','2025-07-23 22:53:57'),(76,'App\\Models\\User',5,'auth_token','7ec8614ce2fe01ed2e716eb87af3f31e151539e1804afeaab751da3e4601d069','[\"*\"]',NULL,NULL,'2025-07-23 22:59:53','2025-07-23 22:59:53'),(77,'App\\Models\\User',5,'auth_token','8cc7df35d70193810bbafbfd39fba13e6a272b6c7a70a644fe8d31f83ba545b8','[\"*\"]',NULL,NULL,'2025-07-23 23:01:33','2025-07-23 23:01:33'),(78,'App\\Models\\User',5,'auth_token','ceee58284f24ac514b6c5d9e4b45b437c7c8d8872de1e86d118f261b096e660f','[\"*\"]',NULL,NULL,'2025-07-23 23:04:40','2025-07-23 23:04:40'),(79,'App\\Models\\User',5,'auth_token','c84b09603192a992bd77930b0cae1a1fb4b73c0cd522b5cec9df30676752851d','[\"*\"]','2025-07-23 23:07:42',NULL,'2025-07-23 23:07:41','2025-07-23 23:07:42'),(80,'App\\Models\\User',5,'auth_token','ffb2abb4395c5b417eb2430d77612587cae54b91f6bc6343efb8e16d9a0afde7','[\"*\"]','2025-07-23 23:11:14',NULL,'2025-07-23 23:11:06','2025-07-23 23:11:14'),(81,'App\\Models\\User',5,'auth_token','7a5feeb4f4ffc53b3880bfa8b4b126a17d99ca15e9864537746ac41f5b372990','[\"*\"]','2025-07-23 23:14:12',NULL,'2025-07-23 23:14:05','2025-07-23 23:14:12'),(82,'App\\Models\\User',5,'auth_token','9211513a75dcb0dc2b890904d29ef930484f6dfb65a7bb667a28b1745996008b','[\"*\"]','2025-07-23 23:19:29',NULL,'2025-07-23 23:15:56','2025-07-23 23:19:29'),(83,'App\\Models\\User',5,'auth_token','5a2860c2c8a9803af865d1f281969877a93f9280c11519a5ac736def99312374','[\"*\"]','2025-07-23 23:22:22',NULL,'2025-07-23 23:22:01','2025-07-23 23:22:22'),(84,'App\\Models\\User',5,'auth_token','e4f7c5a2d40c1ab1f23e0852928559c8de116049a8b9e2b53cb96d69dc9e8ed2','[\"*\"]','2025-07-23 23:24:47',NULL,'2025-07-23 23:24:47','2025-07-23 23:24:47'),(85,'App\\Models\\User',5,'auth_token','038a690ff1e0c6669967f890ff534882b44e1ff0100da4805c1e8a6ba4a447f7','[\"*\"]','2025-07-23 23:42:43',NULL,'2025-07-23 23:42:40','2025-07-23 23:42:43'),(86,'App\\Models\\User',5,'auth_token','840d585455252d10190d16dac760041e9a32ee26a828782508314c21173a6948','[\"*\"]','2025-07-23 23:43:23',NULL,'2025-07-23 23:43:21','2025-07-23 23:43:23'),(87,'App\\Models\\User',5,'auth_token','db593dd5ff1761c0da2a4ddc34f00589853a8ef288277301f0c366a13271591b','[\"*\"]','2025-07-24 00:06:53',NULL,'2025-07-23 23:46:53','2025-07-24 00:06:53'),(88,'App\\Models\\User',5,'auth_token','367f4ec71e41b991d351348ad3f548a2f600874abacc035b3716f1ce47902f09','[\"*\"]','2025-07-24 00:10:03',NULL,'2025-07-24 00:10:01','2025-07-24 00:10:03'),(89,'App\\Models\\User',5,'auth_token','064af5a205a20b55dde7c3d0c1d9e45285392da7ac8faa2de864b9dc3ac1939a','[\"*\"]','2025-07-24 00:40:56',NULL,'2025-07-24 00:10:29','2025-07-24 00:40:56'),(90,'App\\Models\\User',5,'auth_token','516681dbbb1e966317ecbcb15731c22e232e145510a7b81ac3d1c7f1e9ae33a4','[\"*\"]','2025-07-24 01:15:43',NULL,'2025-07-24 00:49:14','2025-07-24 01:15:43'),(91,'App\\Models\\User',5,'auth_token','f0c7f0f1088ef32837e9a553e862d09425314765f8ce616f0f5c650cb48f91e4','[\"*\"]','2025-07-24 01:52:48',NULL,'2025-07-24 01:16:10','2025-07-24 01:52:48'),(92,'App\\Models\\User',5,'auth_token','92fbfa562d4fe9263a3e30b1ed9238bfb02f77f81214fd7d87ff7ae61f6625a7','[\"*\"]','2025-07-24 02:37:07',NULL,'2025-07-24 01:55:47','2025-07-24 02:37:07'),(93,'App\\Models\\User',5,'auth_token','d14ff2eff88b52e63fa37f9c3c8c4312b4ba71557dc3009c036cbf366d2d5195','[\"*\"]','2025-07-24 08:00:33',NULL,'2025-07-24 02:39:47','2025-07-24 08:00:33'),(94,'App\\Models\\User',5,'auth_token','68d03c490bc944da4bd13cf8d1f7f6bfa527b6ca80777f2f76a5e5fb3f3654ab','[\"*\"]','2025-07-24 08:20:13',NULL,'2025-07-24 08:07:43','2025-07-24 08:20:13'),(95,'App\\Models\\User',5,'auth_token','19bb9c67cb252e82fc02181ec26ec8c42379b54a3abb58da77f2f766ee1d14eb','[\"*\"]','2025-07-24 08:17:04',NULL,'2025-07-24 08:17:03','2025-07-24 08:17:04'),(96,'App\\Models\\User',5,'auth_token','1617b803ec994342c8d6c9b36fa1874407f38930e5a2ac7bf443ff6307961813','[\"*\"]','2025-07-24 08:20:51',NULL,'2025-07-24 08:20:49','2025-07-24 08:20:51'),(97,'App\\Models\\User',5,'auth_token','66b6fcc4f12fffe0ddb5462582b4b3aa74bdac7841fd3b3fc5a7ae31479752b7','[\"*\"]','2025-07-24 08:33:40',NULL,'2025-07-24 08:23:49','2025-07-24 08:33:40'),(98,'App\\Models\\User',5,'auth_token','5e5fb8cf7bb538e731c832eb8cc2bde841fec7962d9b18c5bd6ac470155fb885','[\"*\"]','2025-07-24 08:35:26',NULL,'2025-07-24 08:35:07','2025-07-24 08:35:26'),(99,'App\\Models\\User',5,'auth_token','11f3e3409d946902d61de86603ac1b59203348189f68ba1836011d64ed36c760','[\"*\"]','2025-07-24 08:55:16',NULL,'2025-07-24 08:37:22','2025-07-24 08:55:16'),(100,'App\\Models\\User',6,'auth_token','5daf240f86d2b5f2a838a84fde6fe23008c4c5966e8f16d05a7194d3629505a6','[\"*\"]','2025-07-24 08:55:27',NULL,'2025-07-24 08:54:01','2025-07-24 08:55:27'),(101,'App\\Models\\User',5,'auth_token','04ad0a12ee49c47e6087992364e15f78f5c868a0579a98eafd15d9f4b0634ebf','[\"*\"]','2025-07-24 08:59:16',NULL,'2025-07-24 08:57:00','2025-07-24 08:59:16'),(102,'App\\Models\\User',5,'auth_token','f66de0e0f7e10c34b894689ee82514bd1802c36126bdd5e3eee1103664679475','[\"*\"]','2025-07-24 08:59:56',NULL,'2025-07-24 08:59:48','2025-07-24 08:59:56'),(103,'App\\Models\\User',5,'auth_token','517180f334ff981e35a3285f65220034b8ab68abc7d864699ce9cec3b84c95db','[\"*\"]','2025-07-24 09:17:17',NULL,'2025-07-24 09:13:31','2025-07-24 09:17:17'),(104,'App\\Models\\User',5,'auth_token','62358c01e8f20d49336a99ea79cd6de3bcce1720f3242c76fd73a55b548b7fa5','[\"*\"]','2025-07-24 09:40:52',NULL,'2025-07-24 09:30:37','2025-07-24 09:40:52'),(105,'App\\Models\\User',5,'auth_token','3aa8c392078dcd6a8895899b2b0aee2489626b9691e8bbbd4648e55ec447a274','[\"*\"]','2025-07-24 09:38:56',NULL,'2025-07-24 09:38:42','2025-07-24 09:38:56'),(106,'App\\Models\\User',5,'auth_token','32dcbfb9a3cc2d0b13568b7e1d165aadfd38c20a73051eb6f46e29e922bdbafe','[\"*\"]','2025-07-24 09:43:30',NULL,'2025-07-24 09:43:13','2025-07-24 09:43:30'),(107,'App\\Models\\User',5,'auth_token','b4c918139fee6f2261283e957834f8d61397faac92b3bcfc04e720d5ddece8d4','[\"*\"]','2025-07-24 09:48:52',NULL,'2025-07-24 09:44:45','2025-07-24 09:48:52'),(108,'App\\Models\\User',5,'auth_token','38bcaa9d98a066f6f422fac2331a2838e824398f9317031c559c69019bc6e766','[\"*\"]','2025-07-24 10:36:21',NULL,'2025-07-24 10:00:54','2025-07-24 10:36:21'),(109,'App\\Models\\User',5,'auth_token','d5ea0e9f910a5d94ffd3d85339bb07ace8d3033337eead69d7d5e7e80c6a2bc1','[\"*\"]','2025-07-24 10:41:20',NULL,'2025-07-24 10:40:33','2025-07-24 10:41:20'),(110,'App\\Models\\User',5,'auth_token','498235949180e7fc9d143615ce697d4d317af6c77952571ce42ebfb4e7a45dcc','[\"*\"]','2025-07-24 10:57:14',NULL,'2025-07-24 10:50:39','2025-07-24 10:57:14'),(111,'App\\Models\\User',5,'auth_token','f7a1ac725667839bff4bdeaca8ed460910287a77e5fdeae07e757526703674fc','[\"*\"]','2025-07-24 11:18:16',NULL,'2025-07-24 10:57:40','2025-07-24 11:18:16'),(112,'App\\Models\\User',5,'auth_token','554c9402488e7287948c75ba73de1b135ca1dd1c98b2fc4aff8338d238215913','[\"*\"]','2025-07-24 11:34:34',NULL,'2025-07-24 11:29:13','2025-07-24 11:34:34'),(113,'App\\Models\\User',5,'auth_token','8e5801687e39e3561a34cdef044bb00d9ba2b57549692494925602fd2dd99f66','[\"*\"]','2025-07-25 10:42:15',NULL,'2025-07-24 11:35:27','2025-07-25 10:42:15'),(114,'App\\Models\\User',5,'auth_token','cc6ca0873735353b2cb369c4b6f8f337cec0e5a3341a38dfffd77be7f6722402','[\"*\"]','2025-07-25 11:19:12',NULL,'2025-07-25 11:10:24','2025-07-25 11:19:12'),(115,'App\\Models\\User',5,'auth_token','7a230438fa5adfeefba1d6a175eba4a62c885a35288aa78ad5e9e3e6d1ae9114','[\"*\"]','2025-07-25 12:38:52',NULL,'2025-07-25 11:21:40','2025-07-25 12:38:52'),(116,'App\\Models\\User',5,'auth_token','897a72f4b7a920635c633133097698ee8cbc78f92c46bb296f8ab7ce8659013b','[\"*\"]','2025-07-25 13:07:58',NULL,'2025-07-25 12:54:23','2025-07-25 13:07:58'),(117,'App\\Models\\User',5,'auth_token','eaa92dd4f5681dd2c879ac3c75cd89cf2bce7f346336561c85b84e8f32c11bfd','[\"*\"]','2025-07-25 13:15:59',NULL,'2025-07-25 13:10:41','2025-07-25 13:15:59'),(118,'App\\Models\\User',5,'auth_token','075eff8a64bea68f91727a81d96a914b451522af3034e7215cf5a9123e5c405b','[\"*\"]','2025-07-25 13:18:04',NULL,'2025-07-25 13:17:38','2025-07-25 13:18:04'),(119,'App\\Models\\User',5,'auth_token','f765cf9159e859b00efd7b1fa816afff8aadc052c21769a1c6b84db4e82c304d','[\"*\"]','2025-07-26 00:15:11',NULL,'2025-07-25 23:01:18','2025-07-26 00:15:11'),(120,'App\\Models\\User',3,'test-token','263aec17379d777288609ed960efb73051ffa5810335790873828251d820bbb3','[\"*\"]','2025-07-25 23:12:18',NULL,'2025-07-25 23:12:18','2025-07-25 23:12:18'),(121,'App\\Models\\User',5,'auth_token','6720d0f40c785a0a33d83b6fa8854ac0ca285f3e19a42fda71abc1946c8a1d9d','[\"*\"]','2025-07-26 00:22:09',NULL,'2025-07-26 00:19:10','2025-07-26 00:22:09'),(122,'App\\Models\\User',5,'auth_token','4d89c283fed8e9ead17d2ad748c6ad5762eebb253d8cf75d64972003dbac4087','[\"*\"]','2025-07-26 00:27:50',NULL,'2025-07-26 00:24:13','2025-07-26 00:27:50'),(123,'App\\Models\\User',5,'auth_token','699eb9e322ecc8c3eb13b99b37319035ee06dbd6fa9b09c8bbe0b3362b0bfa8e','[\"*\"]','2025-07-26 05:59:27',NULL,'2025-07-26 00:31:53','2025-07-26 05:59:27'),(124,'App\\Models\\User',5,'auth_token','006b2f42f43cb7b2bbcde7c07f43289f2edc722c2c55e0bba9638ca7355b2322','[\"*\"]','2025-07-26 08:10:30',NULL,'2025-07-26 07:51:40','2025-07-26 08:10:30'),(125,'App\\Models\\User',5,'auth_token','5e2f02cb218b61e902cdc02e34ae4c657fc3cb602ff553017fc9e546c99f84fd','[\"*\"]','2025-07-26 09:48:05',NULL,'2025-07-26 08:10:54','2025-07-26 09:48:05'),(126,'App\\Models\\User',5,'auth_token','8b2a84e4b448e48d751e47b07fcbb45bcc9d15f524797b15862502c2354f475d','[\"*\"]','2025-07-26 09:49:20',NULL,'2025-07-26 09:49:16','2025-07-26 09:49:20'),(127,'App\\Models\\User',5,'auth_token','388a2520be49b0295244a8a6fb41e762ee9ceb8ef1f966723407b1dd7c455ddb','[\"*\"]','2025-07-26 12:45:01',NULL,'2025-07-26 10:30:22','2025-07-26 12:45:01'),(128,'App\\Models\\User',5,'auth_token','2d37164239a1f0151e2ea35ec802d0c2ca4ff530b46d6e34790d49785de7daf6','[\"*\"]','2025-07-26 13:14:56',NULL,'2025-07-26 12:45:57','2025-07-26 13:14:56'),(129,'App\\Models\\User',5,'auth_token','dcf95a77485263a830bdba143dc8f5e4cd10a81c20d632cef99ca0ac0df65cff','[\"*\"]','2025-07-26 13:20:32',NULL,'2025-07-26 13:18:04','2025-07-26 13:20:32'),(130,'App\\Models\\User',5,'auth_token','90c16013239de1f1b0cfd642cf7cc98c94718210238b77d7d1457ae23bdd5fb4','[\"*\"]','2025-07-26 13:44:23',NULL,'2025-07-26 13:21:16','2025-07-26 13:44:23'),(131,'App\\Models\\User',5,'auth_token','d9f171b406588b3a0900fad0d21bed84aacd8a71a1c8ea12b2e2e92ad953afc9','[\"*\"]','2025-07-27 01:09:36',NULL,'2025-07-26 23:11:29','2025-07-27 01:09:36'),(132,'App\\Models\\User',5,'auth_token','512a8a6e42290448367c6cd4abd9c1adb31d1155cc39d0aee20c1ee6f1651a68','[\"*\"]','2025-07-27 12:39:49',NULL,'2025-07-27 01:10:18','2025-07-27 12:39:49'),(133,'App\\Models\\User',5,'auth_token','af2144c555781c5b7ea63bb1429d9095ac3130b17c69c2a11cb6e4930b1b28a2','[\"*\"]','2025-07-27 07:33:22',NULL,'2025-07-27 07:32:27','2025-07-27 07:33:22'),(134,'App\\Models\\User',5,'auth_token','6a79c89552600fe15d3a0c0f6eb2a0e6d7718d67f7b69cdf680d6d78f5cadd50','[\"*\"]','2025-07-27 07:33:39',NULL,'2025-07-27 07:33:30','2025-07-27 07:33:39'),(135,'App\\Models\\User',5,'auth_token','e23b0fd83cbd947d063141c924e9143ea1205c545d7377fa85f6dbbbb199a8ad','[\"*\"]','2025-07-27 07:36:58',NULL,'2025-07-27 07:34:11','2025-07-27 07:36:58'),(136,'App\\Models\\User',5,'auth_token','edbe8bd9cdaffd36072f4347f5813cfa17e611763e7d47ce61e4f01a6f69cd33','[\"*\"]','2025-07-29 12:55:46',NULL,'2025-07-28 09:15:10','2025-07-29 12:55:46'),(137,'App\\Models\\User',5,'auth_token','307fd7867f2a96cfb2ac2e4384f6ecba8d7aeedb7a662e11ed4d2cee76a14ccf','[\"*\"]','2025-07-28 09:35:20',NULL,'2025-07-28 09:35:15','2025-07-28 09:35:20'),(138,'App\\Models\\User',5,'auth_token','feba4eeda6f5f89060ae5a5f23f42b9e2bec2d9094cf8aef71a4d25f796ad0e2','[\"*\"]','2025-07-28 09:35:53',NULL,'2025-07-28 09:35:25','2025-07-28 09:35:53'),(139,'App\\Models\\User',5,'auth_token','f7ab4c749254185b112dbc3edec60828429b85afcdfba03952ca9e8e828ff5c1','[\"*\"]','2025-07-28 10:19:49',NULL,'2025-07-28 09:36:05','2025-07-28 10:19:49'),(140,'App\\Models\\User',5,'auth_token','fa16fe2d95a5d19367e96344be1e8e8eb48f8c9c2530d60a0b1a5b83ed85c70a','[\"*\"]','2025-07-28 10:21:23',NULL,'2025-07-28 10:19:58','2025-07-28 10:21:23'),(141,'App\\Models\\User',5,'auth_token','23b0c31984e65218d7293676a4cbc34a4bd4a7d9405e89598649f5ea1fa6f34b','[\"*\"]','2025-07-31 01:39:02',NULL,'2025-07-31 01:38:39','2025-07-31 01:39:02'),(142,'App\\Models\\User',3,'test','28624a9082fc78134b168b39b7cabbdc4f17f7214836982494ec2cb7b583c381','[\"*\"]',NULL,NULL,'2025-08-01 12:28:46','2025-08-01 12:28:46'),(143,'App\\Models\\User',3,'test','470134cbcd5dee3512e79457bb63fe54207e99cdfc15758e1eb0b145c10a54f0','[\"*\"]',NULL,NULL,'2025-08-01 12:28:46','2025-08-01 12:28:46'),(144,'App\\Models\\User',3,'test','30602a68ad0676d9394e055135c3c9874d28d5988e2fb9eae6bd500c39f10528','[\"*\"]',NULL,NULL,'2025-08-01 12:28:46','2025-08-01 12:28:46'),(145,'App\\Models\\User',3,'test','2041c151720c38ddf9ec8679b8f860b2121c99246e78209bee341d807bdb462a','[\"*\"]',NULL,NULL,'2025-08-01 12:34:18','2025-08-01 12:34:18'),(146,'App\\Models\\User',3,'test','af8fab001f02a664bf936567f1ffa975cefa248b9d94bc97869e1f89b3debd77','[\"*\"]',NULL,NULL,'2025-08-01 12:34:30','2025-08-01 12:34:30'),(147,'App\\Models\\User',3,'test','ab8eb3807dd109e7ee8548d8fc9eece07638eeb595b3ae80fc1b3d07b47e564b','[\"*\"]',NULL,NULL,'2025-08-01 12:38:11','2025-08-01 12:38:11'),(148,'App\\Models\\User',3,'test','8346537a45d37d9cace1ed034060e24186721a3c6c7e2906edb27fa1c324358d','[\"*\"]',NULL,NULL,'2025-08-01 12:38:25','2025-08-01 12:38:25'),(149,'App\\Models\\User',3,'test','1770e56c99c43c5f934394c9c1fab4cf7e1e728d41e4f43303359c903a225951','[\"*\"]',NULL,NULL,'2025-08-01 12:42:55','2025-08-01 12:42:55'),(150,'App\\Models\\User',3,'test','4ebf63f2e8f83d8434188c16d3cc5a9a60ece0e69f827ed4ae86633ff3322bfc','[\"*\"]',NULL,NULL,'2025-08-01 12:46:40','2025-08-01 12:46:40');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `properties`
--

DROP TABLE IF EXISTS `properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `properties` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` bigint unsigned NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `property_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip_code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_units` int NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `features` json DEFAULT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive','maintenance') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `properties_owner_id_foreign` (`owner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `properties`
--

LOCK TABLES `properties` WRITE;
/*!40000 ALTER TABLE `properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rent_payments`
--

DROP TABLE IF EXISTS `rent_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rent_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` bigint unsigned NOT NULL,
  `tenant_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `invoice_id` bigint unsigned DEFAULT NULL,
  `amount_due` decimal(10,2) NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_number` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` enum('Paid','Partial') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Paid',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rent_payments_owner_id_foreign` (`owner_id`),
  KEY `rent_payments_tenant_id_foreign` (`tenant_id`),
  KEY `rent_payments_unit_id_foreign` (`unit_id`),
  KEY `rent_payments_invoice_id_foreign` (`invoice_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rent_payments`
--

LOCK TABLES `rent_payments` WRITE;
/*!40000 ALTER TABLE `rent_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `rent_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (3,1);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'super_admin','web','2025-07-22 01:20:54','2025-07-22 01:20:54'),(2,'owner','web','2025-07-22 01:20:54','2025-07-22 01:20:54'),(3,'manager','web','2025-07-22 01:20:54','2025-07-22 01:20:54'),(4,'tenant','web','2025-07-22 01:20:54','2025-07-22 01:20:54'),(5,'admin','web','2025-07-28 10:51:43','2025-07-28 10:51:43'),(6,'agent','web','2025-08-01 01:08:03','2025-08-01 01:08:03');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('kSxBkgR1XMwOhVeGh8LWj6O3CMmumClMXyUPZtuh',3,'103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoidTJaaG5KNXFmTTh4dXFQRXVPRWlseGVxczY2MG82MDhFUW1DMGpJeiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTAyOiJodHRwczovL2JhcmltYW5hZ2VyLmNvbS9hZG1pbi9zZXR0aW5ncy9ub3RpZmljYXRpb25zL3RlbXBsYXRlP3RlbXBsYXRlPXRlbmFudF9wYXltZW50X2NvbmZpcm1hdGlvbl9zbXMiO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozO30=',1754223108),('B4bxZTyTw4uCMHC1TqE5f4s033mUsVNcxIedLvF6',3,'103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiTThGaDVQMGttNWxvS3ZyYlJFUk11OVBuR2d1VEQ0cElTYUFNTjhnayI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTI6Imh0dHBzOi8vYmFyaW1hbmFnZXIuY29tL2FkbWluL3NldHRpbmdzL25vdGlmaWNhdGlvbnMiO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozO30=',1754223105),('gFbLrPvArNem3gq6AuYlAX9lVWhFHif9zf7dovvw',3,'103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiM1FuUzA2U2R1WXU3clFrbmNEUDBDUnJSb1J0dWhsOW5lcDdBOFhybSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6ODg6Imh0dHBzOi8vYmFyaW1hbmFnZXIuY29tL2FkbWluL3NldHRpbmdzL25vdGlmaWNhdGlvbnMvdGVtcGxhdGU/dGVtcGxhdGU9b3duZXJfd2VsY29tZV9zbXMiO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozO30=',1754223079),('eHuUON2ZNUYhvATpa47uMNJd8XC3WHj8Ez0gVtaX',3,'103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiWHpWUGVZYkd4Z09EVGhTQnRTU1RKWjdmZmxxNEVBM0F5SjRUSFNnNCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTI6Imh0dHBzOi8vYmFyaW1hbmFnZXIuY29tL2FkbWluL3NldHRpbmdzL25vdGlmaWNhdGlvbnMiO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozO30=',1754223075),('JFEJiZoXB6Rbq9781wjpuysDNpLJL7ZeeKaq9Ihs',NULL,'103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiUEdaWE1tMmQ0MVJqMlBTV1I5UXhLeW1UNWM3MXkwYU1FeEY3SDh0VCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo1MjoiaHR0cHM6Ly9iYXJpbWFuYWdlci5jb20vYWRtaW4vc2V0dGluZ3Mvbm90aWZpY2F0aW9ucyI7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjI5OiJodHRwczovL2JhcmltYW5hZ2VyLmNvbS9sb2dpbiI7fX0=',1754223009),('pd0gZldQyfMbkElgrB6MFXEH4ZLwbofpdjAkenxK',3,'103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiNm5SQWpVT0gyQXNNMEVRNjhRMDVveDNEVEY3N0NiS09rN213QlowcCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHBzOi8vYmFyaW1hbmFnZXIuY29tL2xvZ2luIjt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6Mzt9',1754223028),('bSdpWp0evh3bbExga5jS68RwnflwRnFPE5Z5urdk',3,'103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoieElTT1FoZkFMT0FzZGpqQWcxeDhVcnlsUFNLbnVQeVI3YWpRdEJWWCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzk6Imh0dHBzOi8vYmFyaW1hbmFnZXIuY29tL2FkbWluL2Rhc2hib2FyZCI7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjM7fQ==',1754223029),('Mu6oQBtSsAoUMbkF0uCjzAcOpZbhYaWeiYig6GuT',3,'103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiZXpnMldyZDVBSDRlUTlvdFNvRkcyOFJKUlQwZzBZeWc4OEw0TEFrRiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTI6Imh0dHBzOi8vYmFyaW1hbmFnZXIuY29tL2FkbWluL3NldHRpbmdzL25vdGlmaWNhdGlvbnMiO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozO30=',1754223035),('08kuyAHUH1CQDJtFHwrBfxVRxU6T1fVUim5PFa08',3,'103.98.76.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiZFVVbjdVWW8zVzJNa2FCSTVVRHZLekhRN3B3Z3FkTmJhWXVMdmxWVCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTAyOiJodHRwczovL2JhcmltYW5hZ2VyLmNvbS9hZG1pbi9zZXR0aW5ncy9ub3RpZmljYXRpb25zL3RlbXBsYXRlP3RlbXBsYXRlPW93bmVyX3N1YnNjcmlwdGlvbl9yZW1pbmRlcl9zbXMiO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozO30=',1754223073);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_logs`
--

DROP TABLE IF EXISTS `sms_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('sent','failed','pending') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `provider` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `response` json DEFAULT NULL,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `sent_at` timestamp NULL DEFAULT NULL,
  `owner_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_logs`
--

LOCK TABLES `sms_logs` WRITE;
/*!40000 ALTER TABLE `sms_logs` DISABLE KEYS */;
INSERT INTO `sms_logs` VALUES (1,'8801700000003','Welcome to HRMS! This is a test SMS from Bari Manager system.','sent','bulksms',NULL,NULL,'2025-08-02 01:55:31',23,30,'2025-08-02 01:55:31','2025-08-02 01:55:31'),(2,'8801700000003','Welcome to HRMS! This is a test SMS from Bari Manager system.','sent','bulksms',NULL,NULL,'2025-08-02 01:57:01',23,30,'2025-08-02 01:57:01','2025-08-02 01:57:01'),(3,'8801700000002','Welcome to HRMS! This is a test SMS from Bari Manager system.','sent','bulksms',NULL,NULL,'2025-08-02 02:02:53',25,29,'2025-08-02 02:02:53','2025-08-02 02:02:53'),(4,'8801700000002','Welcome to HRMS! This is a test SMS from Bari Manager system.','sent','bulksms',NULL,NULL,'2025-08-02 02:04:21',25,29,'2025-08-02 02:04:21','2025-08-02 02:04:21'),(5,'8801700000000','Welcome to HRMS! This is a test SMS from Bari Manager system.','sent','bulksms',NULL,NULL,'2025-08-02 02:15:34',27,28,'2025-08-02 02:15:34','2025-08-02 02:15:34');
/*!40000 ALTER TABLE `sms_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_plans`
--

DROP TABLE IF EXISTS `subscription_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `billing_cycle` enum('monthly','yearly','lifetime') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'monthly',
  `duration_days` int NOT NULL DEFAULT '30',
  `properties_limit` int NOT NULL,
  `units_limit` int NOT NULL,
  `tenants_limit` int NOT NULL,
  `sms_notification` tinyint(1) NOT NULL,
  `sms_credit` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_popular` tinyint(1) NOT NULL DEFAULT '0',
  `features` json DEFAULT NULL,
  `features_css` json DEFAULT NULL,
  `unavailable_features` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_plans`
--

LOCK TABLES `subscription_plans` WRITE;
/*!40000 ALTER TABLE `subscription_plans` DISABLE KEYS */;
INSERT INTO `subscription_plans` VALUES (1,'Free Plan',0.00,'lifetime',36500,1,4,10,0,0,1,0,'[\"Basic property management\", \"Up to 1 property\", \"Up to 4 units\", \"Up to 10 tenants\", \"Email notifications only\"]',NULL,NULL,'2025-08-02 03:06:21','2025-08-02 03:06:21'),(2,'Basic Plan',999.00,'yearly',30,2,10,25,1,50,1,1,'[\"Advanced property management\", \"Up to 2 properties\", \"Up to 10 units\", \"Up to 25 tenants\", \"SMS notifications\", \"50 SMS credits/month\"]','[]',NULL,'2025-08-02 03:06:21','2025-08-02 03:19:39'),(5,'Pro Plan',1999.00,'yearly',30,5,30,100,1,200,1,0,'[\"Professional property management\", \"Up to 5 properties\", \"Up to 30 units\", \"Up to 100 tenants\", \"SMS notifications\", \"200 SMS credits/month\", \"Advanced reporting\"]','[]',NULL,'2025-08-02 03:06:21','2025-08-02 03:19:28');
/*!40000 ALTER TABLE `subscription_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `system_settings_key_unique` (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=194 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,'otp_send_limit','5'),(2,'default_building_limit','1'),(3,'default_unit_limit','10'),(4,'seo_meta_title','Bari Manager - Complete Property Management Solution'),(5,'seo_meta_description','Manage your properties, tenants, and rentals with our comprehensive property management system. Features include tenant management and rent collection.'),(6,'seo_meta_keywords','property management, tenant management, rent collection, maintenance tracking, real estate software'),(7,'seo_og_title','Bari Manager - Complete Property Management Solution'),(8,'seo_og_description','Streamline your property management with our comprehensive solution. Manage tenants, collect rent, track maintenance, and more.'),(9,'seo_og_image','https://barimanager.com/images/og-image.jpg'),(10,'seo_twitter_title','Bari Manager - Property Management Made Easy'),(11,'seo_twitter_description','Complete property management solution for landlords and property managers.'),(12,'seo_twitter_image','https://barimanager.com/images/twitter-image.jpg'),(13,'seo_canonical_url','https://barimanager.com'),(16,'seo_schema_org','{\"@context\":\"https://schema.org\",\"@type\":\"SoftwareApplication\",\"name\":\"Bari Manager\",\"description\":\"Complete property management solution\",\"applicationCategory\":\"BusinessApplication\",\"operatingSystem\":\"Web\",\"offers\":{\"@type\":\"Offer\",\"price\":\"0\",\"priceCurrency\":\"USD\"}}'),(17,'seo_breadcrumb_enabled','1'),(18,'seo_sitemap_enabled','1'),(19,'seo_hreflang_enabled','1'),(20,'seo_lazy_loading_enabled','1'),(21,'seo_minify_enabled','0'),(22,'seo_compression_enabled','1'),(23,'seo_robots_txt','User-agent: * Allow: / Disallow: /admin/ Disallow: /api/ Sitemap: https://barimanager.com/sitemap.xml'),(25,'chat_bot_name','Bari Manager Support'),(26,'chat_welcome_message','Hello! 👋 Welcome to Bari Manager. How can I help you today?'),(27,'chat_auto_response_enabled','1'),(28,'chat_agent_transfer_enabled','1'),(29,'chat_notification_sound','1'),(30,'chat_typing_indicator','1'),(31,'chat_position','bottom-right'),(32,'chat_theme_color','purple'),(33,'chat_working_hours','9 AM - 6 PM (GMT+6)'),(34,'chat_offline_message','We are currently offline. Please leave a message and we\'ll get back to you soon.'),(35,'chat_max_file_size','5'),(36,'chat_allowed_file_types','jpg,jpeg,png,pdf,doc,docx'),(37,'chat_enabled','0'),(38,'chat_file_upload_enabled','0'),(39,'sms_api_token','lJp4X9JWUFZ0tB2aivJc0OeC9zSQUhIZTnHRBGyl'),(40,'sms_sender_id','8809617628822'),(41,'sms_test_number','01718262530'),(42,'sms_reminder_days_before','3'),(43,'sms_working_hours_start','09:00'),(44,'sms_working_hours_end','18:00'),(45,'sms_max_retries','3'),(46,'sms_retry_delay','5'),(47,'sms_enabled','1'),(48,'sms_rent_reminder_enabled','0'),(49,'sms_maintenance_update_enabled','0'),(50,'sms_welcome_message_enabled','0'),(51,'sms_payment_confirmation_enabled','0'),(52,'sms_checkout_reminder_enabled','0'),(53,'email_enabled','1'),(54,'mail_host','sg-vnth.clouddns.one'),(55,'mail_port','587'),(56,'mail_username','noreply@barimanager.com'),(57,'mail_password','Samiul28101988!'),(58,'mail_encryption','ssl'),(59,'mail_from_address','noreply@barimanager.com'),(60,'template_account_setup_guide_email','{\"subject\":\"Account Setup Guide\",\"content\":\"<h2>Account Setup Guide<\\/h2><p>Here\'s how to get started with HRMS...<\\/p>\"}'),(107,'template_test_sms','{\"content\":\"Test SMS content\"}'),(108,'template_test_session','{\"content\":\"Test content\"}'),(61,'template_features_overview_email','{\"subject\":\"HRMS Features Overview\",\"content\":\"<h2>Features Overview<\\/h2><p>Discover all the features available in HRMS...<\\/p>\"}'),(97,'sms_provider','smsinbd'),(98,'sms_api_key','lJp4X9JWUFZ0tB2aivJc0OeC9zSQUhIZTnHRBGyl'),(99,'sms_api_secret',''),(100,'sms_monthly_limit','1000'),(101,'sms_monthly_count','25'),(62,'template_subscription_info_email','{\"subject\":\"Welcome to HRMS - Subscription Details\",\"content\":\"Dear {name},\\n\\nYour subscription details:\\n\\nPlan: {plan_name}\\nPrice: ${plan_price}\\nExpiry Date: {expiry_date}\\nSMS Credits: {sms_credits}\\n\\nThank you for choosing HRMS!\\n\\nBest regards,\\nThe HRMS Team\"}'),(63,'template_payment_confirmation_email','{\"subject\":\"Payment Confirmation - HRMS\",\"content\":\"Dear {name},\\n\\nYour payment of \\u09f3{amount} has been received successfully.\\n\\nInvoice Number: {invoice_number}\\nPayment Method: {payment_method}\\nDate: {payment_date}\\n\\nThank you for your business!\\n\\nBest regards,\\nHRMS Team\"}'),(64,'template_welcome_email','{\"subject\":\"Welcome to HRMS!\",\"content\":\"Dear {name},\\n\\nWelcome to HRMS! Your account has been created successfully.\\n\\nYou can now access all our services and manage your properties efficiently.\\n\\nBest regards,\\nHRMS Team\"}'),(109,'test_simple','test_value'),(110,'template_','{\"subject\":null,\"content\":null}'),(127,'template_owner_subscription_activation_sms','{\"content\":\"Dear {name}, subscription activated! Plan: {plan_name}, Expiry: {expiry_date}. - HRMS\"}'),(111,'template_owner_subscription_reminder_sms','{\"content\":\"Dear {name}, your subscription expires on {expiry_date}. Please renew to continue services. - HRMS..\"}'),(65,'template_invoice_notification_email','{\"subject\":\"New Invoice Generated - HRMS\",\"content\":\"Dear {name},\\n\\nA new invoice has been generated for your account.\\n\\nInvoice Number: {invoice_number}\\nAmount: \\u09f3{amount}\\nDue Date: {due_date}\\n\\nPlease log in to your account to view and pay the invoice.\\n\\nBest regards,\\nHRMS Team\"}'),(66,'template_subscription_reminder_email','{\"subject\":\"Subscription Reminder - HRMS\",\"content\":\"Dear {name},\\n\\nYour subscription will expire on {expiry_date}.\\n\\nPlease renew your subscription to continue enjoying our services without interruption.\\n\\nBest regards,\\nHRMS Team\"}'),(67,'template_subscription_activation_email','{\"subject\":\"Subscription Activated - HRMS\",\"content\":\"Dear {name},\\n\\nYour subscription has been activated successfully!\\n\\nPlan: {plan_name}\\nPrice: \\u09f3{plan_price}\\nExpiry Date: {expiry_date}\\nSMS Credits: {sms_credits}\\n\\nBest regards,\\nHRMS Team\"}'),(68,'template_account_verification_email','{\"subject\":\"Verify Your Account - HRMS\",\"content\":\"Dear {{name}},\\n\\nPlease verify your email address by clicking the link below:\\n\\n{{verification_url}}\\n\\nThis link will expire in 24 hours.\\n\\nBest regards,\\nThe HRMS Team\"}'),(69,'template_password_reset_email','{\"subject\":\"Password Reset Request - HRMS\",\"content\":\"Dear {{name}},\\n\\nYou have requested to reset your password. Click the link below to reset it:\\n\\n{{reset_url}}\\n\\nThis link will expire in 60 minutes.\\n\\nIf you didn\'t request this, please ignore this email.\\n\\nBest regards,\\nThe HRMS Team\"}'),(70,'template_security_alert_email','{\"subject\":\"Security Alert - HRMS\",\"content\":\"Dear {{name}},\\n\\nWe detected unusual activity on your account:\\n\\nActivity: {{activity}}\\nTime: {{timestamp}}\\nIP Address: {{ip_address}}\\n\\nIf this wasn\'t you, please contact support immediately.\\n\\nBest regards,\\nThe HRMS Team\"}'),(71,'template_subscription_expiry_reminder_email','{\"subject\":\"Subscription Expiring Soon - HRMS\",\"content\":\"Dear {{name}},\\n\\nYour subscription will expire in {{days_left}} days.\\n\\nPlan: {{plan_name}}\\nExpiry Date: {{expiry_date}}\\n\\nPlease renew your subscription to avoid service interruption.\\n\\nBest regards,\\nThe HRMS Team\"}'),(72,'template_payment_success_email','{\"subject\":\"Payment Successful - HRMS\",\"content\":\"Dear {{name}},\\n\\nYour payment has been processed successfully!\\n\\nPayment Details:\\nAmount: ${{amount}}\\nTransaction ID: {{transaction_id}}\\nPayment Method: {{payment_method}}\\nDate: {{payment_date}}\\n\\nThank you for your payment!\\n\\nBest regards,\\nThe HRMS Team\"}'),(73,'template_invoice_reminder_email','{\"subject\":\"Invoice Reminder - HRMS\",\"content\":\"Dear {{name}},\\n\\nThis is a reminder for your pending invoice:\\n\\nInvoice Number: {{invoice_number}}\\nAmount: ${{amount}}\\nDue Date: {{due_date}}\\n\\nPayment Link: {{payment_url}}\\n\\nPlease make the payment before the due date.\\n\\nBest regards,\\nThe HRMS Team\"}'),(74,'template_welcome_sms','{\"subject\":\"HRMS Notification\",\"content\":\"Welcome {{name}} to HRMS! Your account has been successfully created.\"}'),(75,'template_payment_confirmation_sms','{\"subject\":\"HRMS Notification\",\"content\":\"Payment of ${{amount}} received. Invoice: {{invoice_number}}. Thank you!\"}'),(76,'template_due_date_reminder_sms','{\"subject\":\"Due Date Reminder\",\"content\":\"Invoice {{invoice_number}} for ${{amount}} is due on {{due_date}}. Please pay on time.\"}'),(77,'template_subscription_activation_sms','{\"subject\":\"Subscription Activated\",\"content\":\"Your {{plan_name}} subscription is now active. Expires: {{expiry_date}}. Thank you!\"}'),(78,'template_otp_verification_sms','{\"subject\":\"HRMS Notification\",\"content\":\"Your OTP is {{otp}}. Please use this code to verify your account.\"}'),(79,'template_invoice_reminder_sms','{\"subject\":\"HRMS Notification\",\"content\":\"Invoice {{invoice_number}} for ${{amount}} is due on {{due_date}}. Please pay on time.\"}'),(104,'template_owner_welcome_sms','{\"content\":\"Welcome {name}! Your HRMS account has been created successfully. Welcome to HRMS!\"}'),(106,'test_key','test_value'),(81,'system_welcome_sms','1'),(82,'system_otp_sms','1'),(83,'system_password_reset_sms','1'),(84,'system_security_alert_sms','1'),(85,'owner_welcome_sms','1'),(86,'owner_package_purchase_sms','1'),(87,'owner_payment_confirmation_sms','1'),(88,'owner_invoice_reminder_sms','1'),(89,'owner_subscription_expiry_sms','1'),(90,'owner_subscription_renewal_sms','1'),(91,'tenant_welcome_sms','1'),(92,'tenant_rent_reminder_sms','1'),(93,'tenant_payment_confirmation_sms','1'),(94,'tenant_maintenance_update_sms','1'),(95,'tenant_checkout_reminder_sms','1'),(96,'tenant_lease_expiry_sms','1'),(112,'template_owner_payment_confirmation_sms','{\"content\":\"Dear {name}, payment of \\u09f3{amount} received. Invoice: {invoice_number}. Thank you! - HRMS\"}'),(113,'test_save','test_value'),(114,'template_tenant_welcome_sms','{\"content\":\"Welcome {tenant_name}! Your tenancy at {property_name} has been registered. Welcome to HRMS!\"}'),(115,'template_tenant_payment_confirmation_sms','{\"content\":\"Dear {tenant_name}, rent payment of \\u09f3{amount} received. Property: {property_name}. - HRMS\"}'),(118,'template_test_ajax_sms','{\"content\":\"Test AJAX content\"}'),(116,'template_test_debug','{\"subject\":\"HRMS Notification\",\"content\":\"Test debug content\"}'),(117,'template_owner_invoice_notification_sms','{\"content\":\"Dear {name}, new invoice generated. Amount: \\u09f3{amount}, Due: {due_date}. Invoice: {invoice_number} - HRMS,,\"}'),(119,'template_final_test_sms','{\"content\":\"Final test content\"}'),(120,'template_test_now','{\"subject\":\"HRMS Notification\",\"content\":\"Testing now\"}'),(121,'template_test_working','{\"subject\":\"HRMS Notification\",\"content\":\"Test working content\"}'),(122,'template_test_complete','{\"subject\":\"HRMS Notification\",\"content\":\"Test complete flow\"}'),(128,'company_name','Bari Manager'),(123,'template_test_email','{\"subject\":\"Test Email Subject\",\"content\":\"Test email content with variables name and amount\"}'),(124,'template_final_email_test','{\"subject\":\"Final Email Test\",\"content\":\"This is a test email content for name\"}'),(125,'template_test_both_sms','{\"content\":\"Test SMS content\"}'),(126,'template_test_both_email','{\"subject\":\"Test Subject\",\"content\":\"Test email content\"}'),(129,'company_tagline','Property Management System'),(130,'company_email','info@hrms.com'),(131,'company_phone','+880 1234-567890'),(132,'company_website','https://barimanager.com'),(133,'company_address','Dhaka, Bangladesh'),(134,'company_city','Dhaka'),(135,'company_state','Dhaka'),(136,'company_country','Bangladesh'),(137,'company_postal_code','1000'),(138,'company_facebook',NULL),(139,'company_twitter',NULL),(140,'company_linkedin',NULL),(141,'company_instagram',NULL),(142,'company_registration_number',NULL),(143,'company_tax_id',NULL),(144,'company_established','2024'),(145,'company_description','HRMS is a comprehensive property management system designed to help property owners and managers efficiently manage their properties, tenants, and financial transactions.'),(146,'company_support_email','support@hrms.com'),(147,'company_support_phone','+880 1234-567890'),(148,'company_working_hours','Monday - Friday: 9:00 AM - 6:00 PM'),(149,'company_timezone','Asia/Dhaka'),(150,'hero_title','Welcome to Bari Manager'),(151,'hero_subtitle','Property Management System'),(152,'hero_description','Manage your properties, tenants, and financial transactions efficiently with our comprehensive property management system.'),(153,'hero_button_text','Get Started'),(154,'hero_button_url','https://barimanager.com/register/owner'),(155,'features_title','Why Choose BariManager?'),(156,'features_subtitle','Discover the features that make Bari Manager the perfect solution for property management'),(157,'feature1_title','Property Management'),(158,'feature1_icon','fas fa-building'),(159,'feature1_description','Efficiently manage multiple properties with detailed tracking and reporting.'),(160,'feature2_title','Tenant Management'),(161,'feature2_icon','fas fa-users'),(162,'feature2_description','Manage tenant information, rent collection, and communication efficiently.'),(163,'feature3_title','Financial Tracking'),(164,'feature3_icon','fas fa-chart-line'),(165,'feature3_description','Track income, expenses, and generate detailed financial reports.'),(166,'about_title','About Bari Manager'),(167,'about_subtitle','Your Trusted Property Management Partner'),(168,'about_content','Bari Manager is a comprehensive property management system designed to help property owners and managers efficiently manage their properties, tenants, and financial transactions. Our platform provides powerful tools for tracking rent payments, managing maintenance requests, and generating detailed reports.'),(169,'contact_title','Contact Us'),(170,'contact_description','Get in touch with us for any questions or support. We are here to help you with your property management needs.'),(171,'contact_email','info@barimanager.com'),(172,'contact_phone','+880 1234-567890'),(173,'contact_address','Dhaka, Bangladesh'),(174,'footer_copyright','© 2024 Bari Manager. All rights reserved.'),(175,'footer_description','Bari Manager is your trusted partner for comprehensive property management solutions.'),(176,'system_currency','BDT'),(177,'system_currency_symbol','৳'),(178,'system_currency_position','left'),(179,'system_decimal_places','2'),(180,'system_thousand_separator',','),(181,'system_timezone','Asia/Dhaka'),(182,'system_date_format','Y-m-d'),(183,'system_time_format','H:i'),(184,'system_datetime_format','Y-m-d H:i'),(185,'system_week_start','sunday'),(186,'system_language','en'),(187,'system_pagination','20'),(188,'system_maintenance_mode','0'),(189,'system_debug_mode','0'),(190,'system_email_notifications','1'),(191,'system_sms_notifications','1'),(192,'system_push_notifications','1'),(193,'system_notification_sound','1');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temp_data`
--

DROP TABLE IF EXISTS `temp_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temp_data` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `related_id` bigint unsigned DEFAULT NULL,
  `data` json NOT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `temp_data_user_id_index` (`user_id`),
  KEY `temp_data_key_index` (`key`),
  KEY `temp_data_related_id_index` (`related_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp_data`
--

LOCK TABLES `temp_data` WRITE;
/*!40000 ALTER TABLE `temp_data` DISABLE KEYS */;
INSERT INTO `temp_data` VALUES (1,5,'unit_draft',3,'[{\"id\": 1, \"name\": \"Unit-01\"}, {\"id\": 2, \"name\": \"Unit-02\"}, {\"id\": 3, \"name\": \"Unit-03\"}, {\"id\": 4, \"name\": \"Unit-04\"}, {\"id\": 5, \"name\": \"Unit-05\"}, {\"id\": 6, \"name\": \"Unit-06\"}, {\"id\": 7, \"name\": \"Unit-07\"}, {\"id\": 8, \"name\": \"Unit-08\"}, {\"id\": 9, \"name\": \"Unit-09\"}, {\"id\": 10, \"name\": \"Unit-10\"}, {\"id\": 11, \"name\": \"Unit-11\"}, {\"id\": 12, \"name\": \"Unit-12\"}, {\"id\": 13, \"name\": \"Unit-13\"}, {\"id\": 14, \"name\": \"Unit-14\"}, {\"id\": 15, \"name\": \"Unit-15\"}, {\"id\": 16, \"name\": \"Unit-16\"}, {\"id\": 17, \"name\": \"Unit-17\"}, {\"id\": 18, \"name\": \"Unit-18\"}, {\"id\": 19, \"name\": \"Unit-19\"}, {\"id\": 20, \"name\": \"Unit-20\"}, {\"id\": 21, \"name\": \"Unit-21\"}, {\"id\": 22, \"name\": \"Unit-22\"}, {\"id\": 23, \"name\": \"Unit-23\"}, {\"id\": 24, \"name\": \"Unit-24\"}, {\"id\": 25, \"name\": \"Unit-25\"}, {\"id\": 26, \"name\": \"Unit-26\"}, {\"id\": 27, \"name\": \"Unit-27\"}, {\"id\": 28, \"name\": \"Unit-28\"}, {\"id\": 29, \"name\": \"Unit-29\"}, {\"id\": 30, \"name\": \"Unit-30\"}, {\"id\": 31, \"name\": \"Unit-31\"}, {\"id\": 32, \"name\": \"Unit-32\"}, {\"id\": 33, \"name\": \"Unit-33\"}, {\"id\": 34, \"name\": \"Unit-34\"}, {\"id\": 35, \"name\": \"Unit-35\"}, {\"id\": 36, \"name\": \"Unit-36\"}, {\"id\": 37, \"name\": \"Unit-37\"}, {\"id\": 38, \"name\": \"Unit-38\"}, {\"id\": 39, \"name\": \"Unit-39\"}, {\"id\": 40, \"name\": \"Unit-40\"}]','2025-07-29 12:33:45','2025-07-29 12:03:45','2025-07-29 12:03:45');
/*!40000 ALTER TABLE `temp_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_ledgers`
--

DROP TABLE IF EXISTS `tenant_ledgers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_ledgers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned NOT NULL,
  `owner_id` bigint unsigned NOT NULL,
  `transaction_type` enum('rent_payment','rent_due','security_deposit','deposit_return','utility_bill','utility_payment','maintenance_charge','maintenance_payment','late_fee','late_fee_payment','cleaning_charge','cleaning_payment','cleaning_charges','damage_charges','other_charge','other_payment','invoice_payment','checkout_adjustment','refund_payment','adjustment','checkout_settlement') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_id` bigint unsigned DEFAULT NULL,
  `invoice_number` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `credit_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `balance` decimal(12,2) NOT NULL,
  `description` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `transaction_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `payment_method` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_reference` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` enum('pending','completed','failed','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'completed',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tenant_ledgers_created_by_foreign` (`created_by`),
  KEY `tenant_ledgers_tenant_id_transaction_date_index` (`tenant_id`,`transaction_date`),
  KEY `tenant_ledgers_unit_id_transaction_date_index` (`unit_id`,`transaction_date`),
  KEY `tenant_ledgers_owner_id_transaction_date_index` (`owner_id`,`transaction_date`),
  KEY `tenant_ledgers_transaction_type_transaction_date_index` (`transaction_type`,`transaction_date`),
  KEY `tenant_ledgers_reference_type_reference_id_index` (`reference_type`,`reference_id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_ledgers`
--

LOCK TABLES `tenant_ledgers` WRITE;
/*!40000 ALTER TABLE `tenant_ledgers` DISABLE KEYS */;
/*!40000 ALTER TABLE `tenant_ledgers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_otps`
--

DROP TABLE IF EXISTS `tenant_otps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_otps` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `mobile` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `otp` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` timestamp NOT NULL,
  `is_used` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_otps`
--

LOCK TABLES `tenant_otps` WRITE;
/*!40000 ALTER TABLE `tenant_otps` DISABLE KEYS */;
INSERT INTO `tenant_otps` VALUES (1,'0118171717','766590','2025-07-22 11:10:21',1,'2025-07-22 10:56:51','2025-07-22 11:00:40');
/*!40000 ALTER TABLE `tenant_otps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_rents`
--

DROP TABLE IF EXISTS `tenant_rents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_rents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` bigint unsigned DEFAULT NULL,
  `tenant_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned NOT NULL,
  `start_month` date NOT NULL,
  `due_day` int NOT NULL,
  `advance_amount` decimal(10,2) DEFAULT NULL,
  `frequency` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'monthly',
  `fees` json DEFAULT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tenant_rents_tenant_id_foreign` (`tenant_id`),
  KEY `tenant_rents_unit_id_foreign` (`unit_id`),
  KEY `tenant_rents_owner_id_foreign` (`owner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_rents`
--

LOCK TABLES `tenant_rents` WRITE;
/*!40000 ALTER TABLE `tenant_rents` DISABLE KEYS */;
/*!40000 ALTER TABLE `tenant_rents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenants`
--

DROP TABLE IF EXISTS `tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenants` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` bigint unsigned DEFAULT NULL,
  `building_id` bigint unsigned DEFAULT NULL,
  `first_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` enum('Male','Female','Other') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `alt_mobile` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nid_number` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `country` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupation` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_family_member` int NOT NULL DEFAULT '1',
  `is_driver` tinyint(1) NOT NULL DEFAULT '0',
  `driver_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` enum('active','inactive','checked_out') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `check_in_date` date DEFAULT NULL,
  `check_out_date` date DEFAULT NULL,
  `security_deposit` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cleaning_charges` decimal(10,2) DEFAULT NULL,
  `other_charges` decimal(10,2) DEFAULT NULL,
  `check_out_reason` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `handover_date` date DEFAULT NULL,
  `handover_condition` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `family_types` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `child_qty` int DEFAULT NULL,
  `city` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `college_university` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frequency` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nid_picture` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nid_front_picture` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nid_back_picture` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenants_mobile_unique` (`mobile`),
  UNIQUE KEY `tenants_nid_number_unique` (`nid_number`),
  KEY `tenants_unit_id_foreign` (`unit_id`),
  KEY `tenants_owner_id_foreign` (`owner_id`),
  KEY `tenants_building_id_foreign` (`building_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenants`
--

LOCK TABLES `tenants` WRITE;
/*!40000 ALTER TABLE `tenants` DISABLE KEYS */;
/*!40000 ALTER TABLE `tenants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit_charges`
--

DROP TABLE IF EXISTS `unit_charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unit_charges` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `unit_id` bigint unsigned NOT NULL,
  `label` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unit_charges_unit_id_foreign` (`unit_id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit_charges`
--

LOCK TABLES `unit_charges` WRITE;
/*!40000 ALTER TABLE `unit_charges` DISABLE KEYS */;
/*!40000 ALTER TABLE `unit_charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `units` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `property_id` bigint unsigned NOT NULL,
  `tenant_id` bigint unsigned DEFAULT NULL,
  `status` enum('rented','vacant','maintained') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'vacant',
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rent` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `units_property_id_foreign` (`property_id`),
  KEY `units_tenant_id_foreign` (`tenant_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenant_id` bigint unsigned DEFAULT NULL,
  `owner_id` bigint unsigned DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_phone_unique` (`phone`),
  KEY `users_tenant_id_foreign` (`tenant_id`),
  KEY `users_owner_id_foreign` (`owner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (3,'Super Admin','admin@hrms.com','01700000000','2025-07-21 23:43:47','$2y$12$9DLOq2Rhm0DmOUkJEPH6L.QEYItbv4my2fW9YET7Duf8dXbHMAtU2',NULL,NULL,NULL,'2025-07-21 23:43:47','2025-08-03 07:46:21'),(62,'Md Samiul Alam','samiul42@gmail.com','01718262530',NULL,'$2y$12$IO0EILFo3JaKOkZKCOIt5eZ3h7Xfoj2hYn2gUVmne3YDtDhOELKaW',NULL,56,NULL,'2025-08-03 09:14:38','2025-08-03 09:14:38');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-04  0:58:29
